define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Approvedleave_ButtonActionChain5 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_EmployeeAbsenceEntry',
        uriParams: {
          limit: 499,
          onlyData: true,
          q: "employeeId='"  + $variables.hr_emp_number + "'" + "and submittedFlag = 'S' " + "and approvedFlag= 'A' ",
        },
      });

      $variables.Abs_info_adp.data = response.body.items;
    }
  }

  return Approvedleave_ButtonActionChain5;
});
