define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Approve_ButtonActionChain2 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const leg = await $functions.leg($flow.variables.Hr_adp.data);

      const approveDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#approve_dialog',
        method: 'open',
      });

      if (leg === true ) {
        const approveDialogClose = await Actions.callComponentMethod(context, {
          selector: '#approve_dialog',
          method: 'close',
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'Error',
          message: "No record to approve",
        });
      }
        else{
          if($variables.approval_tab_id ){

          const response4 = await Actions.callRest(context, {
            endpoint: 'getall/get',
          });
          const today = new Date().toISOString().split('T')[0];
          let response3 = await Actions.callRest(context, {
            endpoint: 'approveTimeEntry/post',
            body: $variables.newpost_variabe,
            headers: {
             'Effective-of':  "RangeMode=UPDATE;RangeStartDate=" + $variables.current_row.entryDate + ";RangeEndDate=" + $variables.current_row.entryDate
             },
            responseType: 'post',
          });
          if (response3.ok === true) {
            const response2 = await Actions.callRest(context, {
              endpoint: 'businessObjects/update_EmployeeTimeSheetDataTb',
              uriParams: {
                'EmployeeTimeSheetDataTb_Id': $variables.approval_tab_id,
              },
              body: $variables.approve_variable,
            });

            const approveDialogClose2 = await Actions.callComponentMethod(context, {
              selector: '#approve_dialog',
              method: 'close',
            });
            await Actions.fireNotificationEvent(context, {
              summary: 'Success',
              message: 'Time Sheet Approved Successfully',
              type: 'confirmation',
            });

            await $flow.functions.reloadPage();
          }
          else{
            const approveDialogClose3 = await Actions.callComponentMethod(context, {
              selector: '#approve_dialog',
              method: 'close',
            });

            await Actions.fireNotificationEvent(context, {
              summary: 'Error',
              message: 'Approve was not successful',
            });

          }

          }

        else{const results = await ActionUtils.forEach($flow.variables.Hr_adp.data, async (item, index) => {
  
          const response = await Actions.callRest(context, {
            endpoint: 'businessObjects/update_EmployeeTimeSheetDataTb',
            uriParams: {
              'EmployeeTimeSheetDataTb_Id': $flow.variables.Hr_adp.data[index].employeeTimeSheetId,
            },
            body: $variables.approve_variable,
          });
        }, { mode: 'serial' });

          const approveDialogClose4 = await Actions.callComponentMethod(context, {
            selector: '#approve_dialog',
            method: 'close',
          });

        await Actions.fireNotificationEvent(context, {
          summary: 'Success',
          message: 'Time Sheets Approved Successfully',
          type: 'confirmation',
        });
      }
        }
    }
  }

  return Approve_ButtonActionChain2;
});
