define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class rejectleave_Button extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($variables.current_absence_row.absenceEntryId) {
        const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_EmployeeAbsenceEntry',
          uriParams: {
            'EmployeeAbsenceEntry_Id': $variables.current_absence_row.absenceEntryId,
          },
          body: $variables.reject_absence,
        });

        if (response.ok === true) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Success',
            message: 'Leave Rejected Successfully',
            type: 'confirmation',
          });

          await $flow.functions.reloadPage();
        }
        
      }
      else{
          const results = await ActionUtils.forEach($variables.Abs_info_adp.data, async (item, index) => {

            const response2 = await Actions.callRest(context, {
              endpoint: 'businessObjects/update_EmployeeAbsenceEntry',
              uriParams: {
                'EmployeeAbsenceEntry_Id': $variables.Abs_info_adp.data[index].absenceEntryId,
              },
              body: $variables.reject_absence,
            });
          }, { mode: 'serial' });

          await Actions.fireNotificationEvent(context, {
            summary: 'Success',
            message: 'Leaves Rejeceted successfully',
            type: 'confirmation',
          });

        await $flow.functions.reloadPage();
          
        }
    }
  }

  return rejectleave_Button;
});
