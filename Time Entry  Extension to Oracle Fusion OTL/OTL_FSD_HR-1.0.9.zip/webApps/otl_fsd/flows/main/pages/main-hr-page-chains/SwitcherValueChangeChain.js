define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SwitcherValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      switch ($variables.ojTabBar) {
        case 'oj-tab-bar-2040881373-1-tab-1':
          await Actions.callChain(context, {
            chain: 'Approved_data_ButtonActionChain3',
          });
          break;
          case 'oj-tab-bar-2040881373-1-tab-2':
          await Actions.callChain(context, {
            chain: 'Search_ButtonActionChain1',
          });
          break;
          case 'oj-tab-bar-2040881373-1-tab-3':
          await Actions.callChain(context, {
            chain: 'Absence_ButtonActionChain5',
          });
          break;
          case 'oj-tab-bar-2040881373-1-tab-4':
          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.Abs_info_adp',
  ],
          });
          break;
      }
    }
  }

  return SwitcherValueChangeChain;
});
