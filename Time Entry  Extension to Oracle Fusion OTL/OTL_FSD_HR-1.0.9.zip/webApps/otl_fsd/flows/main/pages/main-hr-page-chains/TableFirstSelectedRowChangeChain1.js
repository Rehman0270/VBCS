define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableFirstSelectedRowChangeChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.rowKey 
     * @param {any} params.rowData 
     */
    async run(context, { rowKey, rowData }) {
  const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.ts_approve_boolean = false;

  $variables.approval_tab_id = rowKey;
  $variables.current_row = rowData;

  $variables.newpost_variabe.AssignmentId = $variables.assign_id_number;
  $variables.newpost_variabe.PersonId = rowData.employeeId;
  $variables.newpost_variabe.ElementTypeId = 300000043959514;

  // Reset previous values
  $variables.newpost_variabe.elementEntryValues = [];

  function time(timeString) {
    return timeString?.split('T')[1]?.split('+')[0]?.slice(0, 5) || "N/A";
  }

  let response = await Actions.callRest(context, {
    endpoint: 'businessObjects/getall_EmployeeTimeSheetDataTb',
    uriParams: {
      q: `employeeTimeSheetId='${rowKey}'`,
      fields: 'endTime,startTime,task_assigned,taskComment,totalTime',
      onlyData: true,
      limit: '1',
    },
  });

  if (response.body.items?.length > 0) {
    const t = response.body.items[0];

    $variables.newpost_variabe.elementEntryValues.push(
      { InputValueId: 300000043955817, InputValueName: "Start Time", ScreenEntryValue: time(t.startTime) },
      { InputValueId: 300000043955855, InputValueName: "End Time", ScreenEntryValue: time(t.endTime) },
      { InputValueId: 300000043955874, InputValueName: "Total Hours", ScreenEntryValue: t.totalTime || 0 },
      { InputValueId: 300000043955893, InputValueName: "Comment", ScreenEntryValue: t.taskComment || "N/A" },
      { InputValueId: 300000043955836, InputValueName: "Task Assigned", ScreenEntryValue: t.task_assigned || "N/A" }
    );

    const length = await $functions.getlength($variables.newpost_variabe.elementEntryValues);
  }
}

  }

  return TableFirstSelectedRowChangeChain1;
});
