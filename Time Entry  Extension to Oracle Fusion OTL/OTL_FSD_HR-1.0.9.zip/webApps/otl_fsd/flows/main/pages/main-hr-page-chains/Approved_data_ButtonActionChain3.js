define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Approved_data_ButtonActionChain3 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.approve_button_boolean = true;

      if ($variables.from_date !== undefined && $variables.to_date !== undefined) {
        const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_EmployeeTimeSheetDataTb',
          uriParams: {
            limit: 499,
            onlyData: true,
            q: "employeeId LIKE '%"+ $variables.hr_emp_number + "%'"+  "and approvedFlag ='" +$variables.approved_value + "'" + "and  entryDate BETWEEN '" + $variables.from_date + "' and '" + $variables.to_date + "'",
          },
        });

        $flow.variables.Hr_adp.data = response.body.items;
      }
      else{
        const response2 = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_EmployeeTimeSheetDataTb',
          uriParams: {
            limit: 499,
            onlyData: true,
            q: "employeeId LIKE '%"+ $variables.hr_emp_number + "%'"+  "and approvedFlag ='" +$variables.approved_value + "'",
          },
        });

        $flow.variables.Hr_adp.data = response2.body.items;

      }
    }
  }

  return Approved_data_ButtonActionChain3;
});
