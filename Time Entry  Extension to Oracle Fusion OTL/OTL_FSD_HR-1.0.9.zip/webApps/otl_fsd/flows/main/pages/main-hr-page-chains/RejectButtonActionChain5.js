define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain2 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      // ---- TODO: Add your code here ---- //

      const leg = await $functions.leg($flow.variables.Hr_adp.data);

      const rejectDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#reject_dialog',
        method: 'open',
      });

      if (leg === true ) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error',
          message: 'No record ',
        });

        const rejectDialogClose = await Actions.callComponentMethod(context, {
          selector: '#reject_dialog',
          method: 'close',
        });
      }
        else{
          if($variables.approval_tab_id ){
          const response2 = await Actions.callRest(context, {
            endpoint: 'businessObjects/update_EmployeeTimeSheetDataTb',
            uriParams: {
              'EmployeeTimeSheetDataTb_Id': $variables.approval_tab_id,
            },
            body: $variables.rejected_variable,
          });

          const rejectDialogClose2 = await Actions.callComponentMethod(context, {
            selector: '#reject_dialog',
            method: 'close',
          });

          await Actions.fireNotificationEvent(context, {
            summary: 'Success',
            message: 'Time Sheet Rejected Successfully',
            type: 'confirmation',
          });

          await $flow.functions.reloadPage();

          }

        else{const results = await ActionUtils.forEach($flow.variables.Hr_adp.data, async (item, index) => {
  
          const response = await Actions.callRest(context, {
            endpoint: 'businessObjects/update_EmployeeTimeSheetDataTb',
            uriParams: {
              'EmployeeTimeSheetDataTb_Id': $flow.variables.Hr_adp.data[index].employeeTimeSheetId,
            },
            body: $variables.rejected_variable,
          });
        }, { mode: 'serial' });

          const rejectDialogClose3 = await Actions.callComponentMethod(context, {
            selector: '#reject_dialog',
            method: 'close',
          });

        await Actions.fireNotificationEvent(context, {
          summary: 'Success',
          message: 'Time Sheet Rejected Successfully',
          type: 'confirmation',
        });

          await $flow.functions.reloadPage();
      }
        }
    }
  }

  return ButtonActionChain2;
});
