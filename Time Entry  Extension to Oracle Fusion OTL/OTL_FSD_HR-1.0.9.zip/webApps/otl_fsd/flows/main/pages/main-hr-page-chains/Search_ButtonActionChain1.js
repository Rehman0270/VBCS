define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Search_ButtonActionChain1 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.approve_button_boolean = false;

      if ($variables.from_date !== undefined && $variables.to_date !== undefined ) {
        const response2 = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_EmployeeTimeSheetDataTb',
          uriParams: {
            limit: 499,
            onlyData: true,
            q: "employeeId LIKE '%"+ $variables.hr_emp_number + "%'"+ " and submitFlag LIKE '%"+  $variables.submitted_value +"%'" + "and (approvedFlag != 'APPROVED' or approvedFlag is NULL)" + "and  entryDate BETWEEN '" + $variables.from_date + "' and '" + $variables.to_date + "'",
          },
        });

        $flow.variables.Hr_adp.data = response2.body.items;
      }
       else{
      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_EmployeeTimeSheetDataTb',
        uriParams: {
          onlyData: true,
          q: "employeeId LIKE '%"+ $variables.hr_emp_number + "%'"+ " and submitFlag LIKE '%"+  $variables.submitted_value +"%'" + "and (approvedFlag != 'APPROVED' or approvedFlag is NULL)",
          limit: 499,
        },
      });

      $flow.variables.Hr_adp.data = response.body.items;
    }
    }
  }

  return Search_ButtonActionChain1;
});
