define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_EmployeeTimeSheetDataTb',
        uriParams: {
          limit: 499,
          onlyData: true,
          fields: 'employeeId',
        },
      });

      const unique = await $functions.unique(response.body.items);

       

      // 1. Get the string from localStorage into a local var
let storedString = localStorage.getItem("selectedEmployeeObject");

if (storedString) {
  try {
    // 2. Parse it into a JS object
    let parsed = JSON.parse(storedString);

    // 3. Assign the parsed object to your VBCS object variable
    $variables.stored = parsed; // if you want to keep it in 'stored' for debugging or reuse
    $variables.selected_employee_number = parsed;

  } catch (e) {
    console.error("JSON parse error:", e);
    $variables.selected_employee_number = {};
  }
}


      $variables.Id_adp.data = unique.idn;    }

      // ---- TODO: Add your code here ---- //

      // ---- CALL FUNCTION ---- //

            
     
    

  }

  return PageVbEnterChain;
});
