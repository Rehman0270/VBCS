define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class approveleave_ButtonActionChain1 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($variables.current_absence_row.absenceEntryId) {
        const response3 = await Actions.callRest(context, {
          endpoint: 'approveabsence/post',
          body: $variables.approve_absence_post,
        });

        if (response3.ok === true) {
          const response = await Actions.callRest(context, {
            endpoint: 'businessObjects/update_EmployeeAbsenceEntry',
            uriParams: {
              'EmployeeAbsenceEntry_Id': $variables.current_absence_row.absenceEntryId,
            },
            body: $variables.update_absence,
          });

          if (response.ok === true) {
            await Actions.fireNotificationEvent(context, {
              summary: 'Success',
              message: 'Leave approved Successfully',
              type: 'confirmation',
            });

            await $flow.functions.reloadPage();
          }
        }
        else{
          await Actions.fireNotificationEvent(context, {
            summary: 'Error',
            message: 'Leave Not approved',
          });

        }
        
      }
      else{

          const results = await ActionUtils.forEach($variables.Abs_info_adp.data, async (item, index) => {
          const response4 = await Actions.callRest(context, {
            endpoint: 'approveabsence/post',
            body: $variables.approve_absence_post[index],
          });

          if (response4.ok === true) {
              const response2 = await Actions.callRest(context, {
                endpoint: 'businessObjects/update_EmployeeAbsenceEntry',
                uriParams: {
                  'EmployeeAbsenceEntry_Id': $variables.Abs_info_adp.data[index].absenceEntryId,
                },
                body: $variables.update_absence,
              });

              await Actions.fireNotificationEvent(context, {
                summary: 'Success',
                message: 'Leaves approved successfully',
                type: 'confirmation',
              });
          }
          else{
            await Actions.fireNotificationEvent(context, {
              summary: 'Error',
              message: 'Leave unapproved ',
              type: 'error',
            });
            
          }
          }, { mode: 'serial' });
          
        }
    }
  }

  return approveleave_ButtonActionChain1;
});
