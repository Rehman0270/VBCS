define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SelectValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.hr_emp_number = $variables.selected_employee_number;

      localStorage.setItem(
        "selectedEmployeeObject",
        JSON.stringify($variables.selected_employee_number)
      );
    }
  }

  return SelectValueItemChangeChain;
});
