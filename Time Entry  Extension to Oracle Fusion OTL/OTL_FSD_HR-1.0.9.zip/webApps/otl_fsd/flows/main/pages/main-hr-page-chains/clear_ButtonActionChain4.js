define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class clear_ButtonActionChain4 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.hr_emp_number',
    '$flow.variables.Hr_adp',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.selected_employee_number',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.ojTabBar',
  ],
      });
    }
  }

  return clear_ButtonActionChain4;
});
