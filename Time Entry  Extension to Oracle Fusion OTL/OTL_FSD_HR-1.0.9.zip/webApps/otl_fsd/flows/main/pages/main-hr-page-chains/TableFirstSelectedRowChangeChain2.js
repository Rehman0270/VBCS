define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableFirstSelectedRowChangeChain2 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.rowKey 
     * @param {any} params.rowData 
     */
    async run(context, { rowKey, rowData }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.abs_approve_boolean = false;

      $variables.current_absence_row = rowData;

      $variables.approve_absence_post.absenceTypeId = $variables.current_absence_row.absenceTypeId;
      $variables.approve_absence_post.comments = $variables.current_absence_row.comments;
      $variables.approve_absence_post.duration = $variables.current_absence_row.duration;
      $variables.approve_absence_post.endDate = $variables.current_absence_row.leaveEndDate;
      $variables.approve_absence_post.startDate = $variables.current_absence_row.leaveStartDate;
      $variables.approve_absence_post.endDateDuration = $variables.current_absence_row.endDateDuration;
      $variables.approve_absence_post.startDateDuration = $variables.current_absence_row.startDateDuration;
      $variables.approve_absence_post.startTime = '10:00';
      $variables.approve_absence_post.endTime = '16:00';

      $variables.approve_absence_post.personId = $variables.current_absence_row.employeeId;

      if ($variables.approve_absence_post.duration >= 8) {
        $variables.approve_absence_post.singleDayFlag = true;
      }
      else{
        $variables.approve_absence_post.singleDayFlag = false;
      }
    }
  }

  return TableFirstSelectedRowChangeChain2;
});
