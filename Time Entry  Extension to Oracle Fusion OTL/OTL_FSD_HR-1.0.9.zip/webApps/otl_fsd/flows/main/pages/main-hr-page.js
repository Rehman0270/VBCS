define([], () => {
  'use strict';

  class PageModule {
    constructor() {
      this.getDateDifference = this.getDateDifference.bind(this);
    }

    getDateDifference(fromDate, toDate) {
      try {
        const from = new Date(fromDate);
        const to = new Date(toDate);

        if (isNaN(from.getTime()) || isNaN(to.getTime())) {
          console.error("Invalid date(s):", fromDate, toDate);
          return null;
        }

        const diffTime = to.getTime() - from.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays;
      } catch (e) {
        console.error("Error computing date difference:", e);
        return null;
      }
    }

    getTodayDate() {
      const today = new Date();
      const yyyy = today.getFullYear();
      const mm = String(today.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
      const dd = String(today.getDate()).padStart(2, '0');

      return `${yyyy}-${mm}-${dd}`;
    }
  };
  
  PageModule.prototype.unique= function(result)
 { 
  let uniqueResult_pn = []; 
  let final_pn= [];
  
if (result && result.length > 0) 
      { for (let i = 0; i < result.length; i++) 
         { 
         if (!uniqueResult_pn[result[i].employeeId])
            {
            final_pn.push({
            employeeId: result[i].employeeId
            
});

            }
         }
     }
return {idn:final_pn} ;
       

 };
 PageModule.prototype.leg = function(arr){
  return arr.length===0;
 };
  PageModule.prototype.getId = function(context){
    return context.data.employeeId;

  };

  PageModule.prototype.convertTo24HourFormat= function(timeString) {
  // Remove the "T" and the timezone part
  let time = timeString.split('T')[1].split('+')[0];
  // Return the time in the 24-hour format
  return time.slice(0, 5);
};
  PageModule.prototype.getlength = function(obj) {
  if (obj && typeof obj === 'object') {
    return Object.keys(obj).length;  // Get the number of keys in the object
  }
  return 0;  // Return 0 if it's not an object or it's null/undefined
};

  return PageModule;
});
 

