define([], () => {
  'use strict';

  class FlowModule {
  }
   FlowModule.prototype.covert_isodate=function(dateInput) {
  // Create a Date object from the input
  const date = new Date(dateInput);

  // Check if the date is valid
  if (isNaN(date)) {
    console.log("Invalid date provided.");
    return null;
  }

  // Extract year, month, and day
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based, so add 1 and pad with leading zero if needed
  const day = String(date.getDate()).padStart(2, '0'); // Pad day with leading zero if needed

  // Return the formatted date as YYYY-MM-DD
  return `${year}-${month}-${day}`;
};
FlowModule.prototype.minimum_date = function(mindate){
  
    const currentDate = new Date(mindate);
    const futureDate = new Date(currentDate);
    futureDate.setDate( currentDate.getDate() +5  );
    const formattedDate = futureDate.getFullYear() + '-' +
                        String(futureDate.getMonth() + 1).padStart(2, '0') + '-' +
                        String(futureDate.getDate()).padStart(2, '0');
  
  // Return the formatted future date
  return formattedDate;
    
  };
  FlowModule.prototype.get_formatteddate= function (fromDate, toDate) {
  // Function to format the date in YYYY-MM-DD format
  const formatDate = (date) => {
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
    const dd = String(date.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  // Parse the input dates (assuming the format is YYYY-MM-DD)
  const fromParsedDate = new Date(fromDate);
  const toParsedDate = new Date(toDate);

  // Format the dates back to YYYY-MM-DD
  const formattedFromDate = formatDate(fromParsedDate);
  const formattedToDate = formatDate(toParsedDate);

  // Return the formatted date range
  return `${formattedFromDate} to ${formattedToDate}`;
};
FlowModule.prototype.get_formatteddate_no_frisat = function (fromDate, toDate) {
  // Function to format the date in YYYY-MM-DD format
  const formatDate = (date) => {
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
    const dd = String(date.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  // Function to get the next valid date excluding Friday and Saturday
  const getNextValidDate = (date) => {
    while (date.getDay() === 5 || date.getDay() === 6) { // 5 = Friday, 6 = Saturday
      date.setDate(date.getDate() + 1); // Skip to the next day
    }
    return date;
  };

  // Parse the input dates (assuming the format is YYYY-MM-DD)
  let fromParsedDate = new Date(fromDate);
  let toParsedDate = new Date(toDate);

  // Adjust the start date to skip Friday and Saturday
  fromParsedDate = getNextValidDate(fromParsedDate);

  // Adjust the end date to skip Friday and Saturday
  toParsedDate = getNextValidDate(toParsedDate);

  // Format the dates back to YYYY-MM-DD
  const formattedFromDate = formatDate(fromParsedDate);
  const formattedToDate = formatDate(toParsedDate);

  // Return the formatted date range
  return `${formattedFromDate} to ${formattedToDate}`;
};
  FlowModule.prototype.reloadPage = function () {
    location.reload();
  };

  return FlowModule;
});
