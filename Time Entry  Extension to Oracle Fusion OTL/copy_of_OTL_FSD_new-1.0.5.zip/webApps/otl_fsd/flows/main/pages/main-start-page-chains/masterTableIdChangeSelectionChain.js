define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class masterTableIdChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.employeeDataTestId
     */
    async run(context, { employeeDataTestId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
    }
  }

  return masterTableIdChangeSelectionChain;
});
