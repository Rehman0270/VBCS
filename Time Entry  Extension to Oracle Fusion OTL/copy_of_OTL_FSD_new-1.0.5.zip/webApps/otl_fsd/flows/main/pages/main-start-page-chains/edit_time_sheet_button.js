define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadEmployeeTimeSheetDataTbChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const editDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#edit_dialog',
        method: 'open',
      });

      await Actions.callChain(context, {
        chain: 'edit_button_load',
      });
    }
  }

  return loadEmployeeTimeSheetDataTbChain;
});
