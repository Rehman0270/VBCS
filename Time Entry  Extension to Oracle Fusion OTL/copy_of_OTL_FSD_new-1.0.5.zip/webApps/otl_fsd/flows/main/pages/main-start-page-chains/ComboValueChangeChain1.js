define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ComboValueChangeChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.callChain(context, {
        chain: 'leave_end_dateComboValueChangeChain1',
      });

      await Actions.callChain(context, {
        chain: 'leave_todate_InputDateValueChangeChain3',
      });
    }
  }

  return ComboValueChangeChain1;
});
