define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class delete_absent_ButtonActionChain8 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($variables.current_absence_data.absenceEntryId) {
        const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/delete_EmployeeAbsenceEntry',
          uriParams: {
            'EmployeeAbsenceEntry_Id': $variables.current_absence_data.absenceEntryId,
          },
        });

        if (response.ok === true) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Success',
            message: 'Absent Record Deleted Successfully',
            type: 'confirmation',
          });
        }

        await $flow.functions.reloadPage();
      }
      else{
        const results = await ActionUtils.forEach($variables.Absence_adp.data, async (item, index) => {

          const response2 = await Actions.callRest(context, {
            endpoint: 'businessObjects/delete_EmployeeAbsenceEntry',
            uriParams: {
              'EmployeeAbsenceEntry_Id': $variables.Absence_adp.data[index].absenceEntryId,
            },
          });

          $variables.response_value = response2.ok;

          await Actions.fireNotificationEvent(context, {
            summary: 'hii',
            message: $variables.response_value,
          });
        }, { mode: 'serial' });

        if ($variables.response_value) {
          await Actions.fireNotificationEvent(context, {
            summary: 'suceess',
            message: 'Absent Records deleted Successfully',
            type: 'confirmation',
          });

          await $flow.functions.reloadPage();

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.response_value',
  ],
          });
        }
        else{
          await Actions.fireNotificationEvent(context, {
            summary: 'Error',
            message: 'No record to delete',
          });
          
        }
        
      }
    }
  }

  return delete_absent_ButtonActionChain8;
});
