define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEployeeDashboardDetailChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.eployeeDashboardId
     */
    async run(context, { eployeeDashboardId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainEployeeDashboardDetailResult = await Actions.navigateToPage(context, {
        page: 'main-eployee-dashboard-detail',
        params: {
          eployeeDashboardId: eployeeDashboardId,
        },
      });
    }
  }

  return navigateToEployeeDashboardDetailChain;
});
