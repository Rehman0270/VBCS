define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class InputTimeValueChangeChain2_ed extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const totaltime = await $functions.totaltime($variables.employeeTimeSheetDataTb1.startTime, $variables.employeeTimeSheetDataTb1.endTime);

      $variables.employeeTimeSheetDataTb1.totalTime = totaltime;
    }
  }

  return InputTimeValueChangeChain2_ed;
});
