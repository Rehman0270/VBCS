define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateTimeExtensionChain3 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainCreateTimeExtensionResult = await Actions.navigateToPage(context, {
        page: 'main-create-time-extension',
        params: {},
      });
    }
  }

  return navigateToCreateTimeExtensionChain3;
});
