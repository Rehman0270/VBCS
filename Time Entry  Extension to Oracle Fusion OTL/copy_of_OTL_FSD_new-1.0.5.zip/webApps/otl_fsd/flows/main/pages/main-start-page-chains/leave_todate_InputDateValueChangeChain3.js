define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class leave_todate_InputDateValueChangeChain3 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      if ($functions.getDateDifference($variables.absence_variable.leaveStartDate,$variables.absence_variable.leaveEndDate ) === 0) {

        $variables.absence_variable.duration = ($variables.absence_variable.startDateDuration*8)/8;
      }

      await Actions.callChain(context, {
        chain: 'leave_end_dateComboValueChangeChain1',
      });
     
    }
  }

  return leave_todate_InputDateValueChangeChain3;
});
