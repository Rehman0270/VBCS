define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditEmployeeDashboardChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.employeeDashboardId
     */
    async run(context, { employeeDashboardId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainEditEmployeeDashboardResult = await Actions.navigateToPage(context, {
        page: 'main-edit-employee-dashboard',
        params: {
          employeeDashboardId: employeeDashboardId,
        },
      });
    }
  }

  return navigateToEditEmployeeDashboardChain;
});
