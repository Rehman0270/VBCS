define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Absence_recordButtonActionChain8 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      if ($flow.variables.from_date !== undefined && $flow.variables.to_date !== undefined) {
        const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_EmployeeAbsenceEntry',
          uriParams: {
            limit: 499,
            onlyData: true,
            q: "employeeId ='"+ $variables.emp_number + "'"+  "and  leaveStartDate BETWEEN '" + $flow.variables.from_date + "' and '" + $flow.variables.to_date + "'",
          },
        });

        $variables.Absence_adp.data = response.body.items;
      }
        else{
      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_EmployeeAbsenceEntry',
        uriParams: {
          limit: 499,
          onlyData: true,
          q: "employeeId='" + $variables.emp_number +"'",
        },
      });

      $variables.Absence_adp.data = response.body.items;
    }
    }
  }

  return Absence_recordButtonActionChain8;
});
