define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditEmployeeDashboardChain2 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.employeeDashboardId
     */
    async run(context, { employeeDashboardId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainEditEmployeeDashboard2Result = await Actions.navigateToPage(context, {
        page: 'main-edit-employee-dashboard2',
        params: {
          employeeDashboardId: employeeDashboardId,
        },
      });
    }
  }

  return navigateToEditEmployeeDashboardChain2;
});
