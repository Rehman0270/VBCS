define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class InputTimeValueChangeChain_create extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.end_date_boolean = false;

      $variables.employeeTimeSheetDataTb.startTime = value;
    }
  }

  return InputTimeValueChangeChain_create;
});
