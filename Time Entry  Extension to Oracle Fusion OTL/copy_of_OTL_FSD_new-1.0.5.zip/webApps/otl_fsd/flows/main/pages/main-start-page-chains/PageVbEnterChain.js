define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions, $chain } = context;

      const response3 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_EmployeeDataTest',
        uriParams: {
          limit: 499,
          onlyData: true,
          q: "employeeName ='"  + $variables.emp_name + "'",
        },
      });

      $variables.emp_number = response3.body.items[0].employeeId;

      await Actions.callChain(context, {
        chain: 'ComboValueChangeChain_empnumber_pass',
        params: {
          value: $variables.emp_number,
        },
      });

      $flow.variables.update_employee_id = $variables.emp_number;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_EventCalendar',
        uriParams: {
          limit: 499,
          onlyData: true,
          q: "calendarprovider ='" + $variables.Leave + "'",
        },
      });

      $variables.Events_date.data = response.body.items;

      const arraydates = await $functions.arraydates($variables.Events_date.data);

      const results = await ActionUtils.forEach(response.body.items, async (item, index) => {

        if (response.body.items[index].attribute1 !== '26-03-2025') {
          $variables.create_button = true;

          await Actions.fireNotificationEvent(context, {
            summary: 'hii',
            message: 'Cannot create a time sheet',
          });
        }
        else{
          $variables.create_button = false;
          
        }
        
      }, { mode: 'serial' });
    }
  }

  return PageVbEnterChain;
});
