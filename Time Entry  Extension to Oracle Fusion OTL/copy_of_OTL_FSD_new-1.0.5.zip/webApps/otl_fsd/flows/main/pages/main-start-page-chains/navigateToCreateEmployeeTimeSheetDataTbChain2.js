define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateEmployeeTimeSheetDataTbChain2 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainCreateEmployeeTimeSheetDataTb2Result = await Actions.navigateToPage(context, {
        page: 'main-create-employee-time-sheet-data-tb2',
        params: {},
      });
    }
  }

  return navigateToCreateEmployeeTimeSheetDataTbChain2;
});
