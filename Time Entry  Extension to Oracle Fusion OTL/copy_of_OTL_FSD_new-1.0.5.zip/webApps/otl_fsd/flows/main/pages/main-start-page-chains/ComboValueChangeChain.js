define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ComboValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (value === 'Regular') {
        $variables.create_form_button = false;

        $variables.create_save_button = false;
      }
      else{
        $variables.create_save_button = true;

        $variables.create_form_button = true;
        
      }
    }
  }

  return ComboValueChangeChain;
});
