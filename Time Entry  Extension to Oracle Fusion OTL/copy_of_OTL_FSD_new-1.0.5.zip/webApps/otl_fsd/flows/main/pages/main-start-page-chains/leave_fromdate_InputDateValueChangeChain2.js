define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class leave_fromdate_InputDateValueChangeChain2 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.absence_variable.leaveStartDate = value;

      await Actions.callChain(context, {
        chain: 'leave_todate_InputDateValueChangeChain3',
      });

      await Actions.callChain(context, {
        chain: 'leave_end_dateComboValueChangeChain1',
      });
    }
  }

  return leave_fromdate_InputDateValueChangeChain2;
});
