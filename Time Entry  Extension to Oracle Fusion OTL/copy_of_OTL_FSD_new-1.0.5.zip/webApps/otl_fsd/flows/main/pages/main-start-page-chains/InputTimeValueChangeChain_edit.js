define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class InputTimeValueChangeChain_edit extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const totaltime = await $functions.totaltime_create($variables.employeeTimeSheetDataTb.startTime, $variables.employeeTimeSheetDataTb.endTime);

      $variables.employeeTimeSheetDataTb.totalTime = totaltime;
    }
  }

  return InputTimeValueChangeChain_edit;
});
