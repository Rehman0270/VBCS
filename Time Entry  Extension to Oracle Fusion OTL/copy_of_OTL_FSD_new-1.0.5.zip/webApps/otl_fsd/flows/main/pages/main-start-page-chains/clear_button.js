define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class clear_button extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.Info_detail_adp.data',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.Absence_adp.data',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.ojTabBar',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.from_date',
    '$flow.variables.to_date',
  ],
      });
    }
  }

  return clear_button;
});
