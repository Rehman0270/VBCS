define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableFirstSelectedRowChangeChain3 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.rowKey 
     * @param {any} params.rowData 
     */
    async run(context, { rowKey, rowData }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.absence_entry_id = rowKey;

      $variables.current_absence_data = rowData;

      await Actions.fireNotificationEvent(context, {
        summary: 'hii',
        message: $variables.current_absence_data.absenceEntryId,
      });
    }
  }

  return TableFirstSelectedRowChangeChain3;
});
