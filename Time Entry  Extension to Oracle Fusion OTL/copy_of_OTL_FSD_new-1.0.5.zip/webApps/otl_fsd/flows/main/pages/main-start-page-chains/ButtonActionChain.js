define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_EmployeeDataTest',
        uriParams: {
          limit: 499,
          onlyData: true,
          q: "employeeId LIKE '%" + $variables.master_table_idSelectedId + "%'",
        },
      });

      $flow.variables.name_employee = response.body.items[0].employeeName;
    }
  }

  return ButtonActionChain;
});
