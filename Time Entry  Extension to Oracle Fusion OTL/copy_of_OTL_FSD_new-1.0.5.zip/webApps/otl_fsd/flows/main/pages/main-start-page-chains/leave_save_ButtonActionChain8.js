define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class leave_save_ButtonActionChain8 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.absence_variable.employeeId = $variables.emp_number;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/create_EmployeeAbsenceEntry',
        body: $variables.absence_variable,
      });

      if (response.ok === true) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Success',
          message: 'Leave created suceesfully',
          type: 'confirmation',
        });
      }

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.absence_variable',
  ],
      });

      const absenceDialogClose = await Actions.callComponentMethod(context, {
        selector: '#absence_dialog',
        method: 'close',
      });

      await $flow.functions.reloadPage();
    }
  }

  return leave_save_ButtonActionChain8;
});
