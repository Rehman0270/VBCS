define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableFirstSelectedRowChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.rowKey 
     * @param {any} params.rowData 
     */
    async run(context, { rowKey, rowData }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.master_table_idSelectedId = rowKey;

      $variables.current_data = rowData;

      if ($variables.current_data.submitFlag !== 'SUBMITTED') {
        $flow.variables.edit_save_button = false;
      }
    }
  }

  return TableFirstSelectedRowChangeChain;
});
