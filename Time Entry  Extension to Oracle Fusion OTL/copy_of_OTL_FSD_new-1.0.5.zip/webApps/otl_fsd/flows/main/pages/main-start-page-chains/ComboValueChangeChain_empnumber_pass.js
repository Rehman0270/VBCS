define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ComboValueChangeChain_empnumber_pass extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.emp_number = value;

      $variables.time_entry_button = false;

      await Actions.callChain(context, {
        chain: 'SearchButton',
      });
    }
  }

  return ComboValueChangeChain_empnumber_pass;
});
