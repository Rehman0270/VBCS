define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable14496291752ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.eployeeDashboardId
     */
    async run(context, { eployeeDashboardId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.oj_table_1449629175_2SelectedId = eployeeDashboardId;
    }
  }

  return ojTable14496291752ChangeSelectionChain;
});
