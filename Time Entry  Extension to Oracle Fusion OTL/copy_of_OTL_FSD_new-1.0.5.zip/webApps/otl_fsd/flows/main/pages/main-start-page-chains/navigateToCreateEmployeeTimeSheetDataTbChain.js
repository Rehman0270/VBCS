define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateEmployeeTimeSheetDataTbChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainCreateEmployeeTimeSheetDataTbResult = await Actions.navigateToPage(context, {
        page: 'main-create-employee-time-sheet-data-tb',
        params: {},
      });
    }
  }

  return navigateToCreateEmployeeTimeSheetDataTbChain;
});
