define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain4 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.Master_data_adp',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.emp_number',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.from_date',
    '$flow.variables.to_date',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.time_entry_button',
  ],
      });
    }
  }

  return ButtonActionChain4;
});
