define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SearchButton extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($variables.emp_number === undefined) {
        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.emp_number',
  ],
        });
      }
      else{
        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.ojTabBar',
  ],
        });

        const response2 = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_EmployeeTimeSheetDataTb',
          uriParams: {
            limit: 499,
            onlyData: true,
            q: "employeeId='"  + $variables.emp_number + "'",
            orderBy: 'creationDate:desc',
          },
        });

        $variables.Info_detail_adp.data = response2.body.items;
        
      }
    }
  }

  return SearchButton;
});
