define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditEmployeeTimeSheetDataTbChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.employeeTimeSheetDataTbId
     */
    async run(context, { employeeTimeSheetDataTbId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainEditEmployeeTimeSheetDataTbResult = await Actions.navigateToPage(context, {
        page: 'main-edit-employee-time-sheet-data-tb',
        params: {
          employeeTimeSheetDataTbId: employeeTimeSheetDataTbId,
        },
      });
    }
  }

  return navigateToEditEmployeeTimeSheetDataTbChain;
});
