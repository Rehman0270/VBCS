define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable14496291751ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.timeExtensionId
     */
    async run(context, { timeExtensionId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.oj_table_1449629175_1SelectedId = timeExtensionId;

      await Actions.fireNotificationEvent(context, {
        summary: 'hiii',
        message: $variables.oj_table_1449629175_1SelectedId,
      });
    }
  }

  return ojTable14496291751ChangeSelectionChain;
});
