define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Unsubmitted_button_chain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.submit_button = false;

      if ($flow.variables.from_date !== undefined && $flow.variables.to_date !== undefined) {
        const response2 = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_EmployeeTimeSheetDataTb',
          uriParams: {
            limit: 499,
            onlyData: true,
            q: "employeeId ='"+ $variables.emp_number + "'"+ " and (submitFlag != 'SUBMITTED' or submitFlag is NULL)" + "and  entryDate BETWEEN '" + $flow.variables.from_date + "' and '" + $flow.variables.to_date + "'",
          },
        });

        $variables.Info_detail_adp.data = response2.body.items;
      }
     else{
      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_EmployeeTimeSheetDataTb',
        uriParams: {
          limit: 499,
          onlyData: true,
          q: "employeeId ='"+ $variables.emp_number + "'"+ " and (submitFlag != 'SUBMITTED' or submitFlag is NULL)",
        },
      });

      $variables.Info_detail_adp.data = response.body.items;
    }
    }
  }

  return Unsubmitted_button_chain;
});
