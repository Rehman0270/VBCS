define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SwitcherValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      switch ($variables.ojTabBar) {
        case 'oj-tab-bar--1449629175-1-tab-3':
          await Actions.callChain(context, {
            chain: 'Absence_recordButtonActionChain8',
          });
          break;
          case 'oj-tab-bar--1449629175-1-tab-2':
          await Actions.callChain(context, {
            chain: 'Unsubmitted_button_chain',
          });
          break;
          case'oj-tab-bar--1449629175-1-tab-1':
          await Actions.callChain(context, {
            chain: 'Submitted_button_chain1',
          });
          break;
        default:
          break;
      }
    }
  }

  return SwitcherValueChangeChain;
});
