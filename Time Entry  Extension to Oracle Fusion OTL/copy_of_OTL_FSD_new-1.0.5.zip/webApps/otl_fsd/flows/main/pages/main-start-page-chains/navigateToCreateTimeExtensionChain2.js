define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateTimeExtensionChain2 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainCreateTimeExtension2Result = await Actions.navigateToPage(context, {
        page: 'main-create-time-extension2',
        params: {},
      });
    }
  }

  return navigateToCreateTimeExtensionChain2;
});
