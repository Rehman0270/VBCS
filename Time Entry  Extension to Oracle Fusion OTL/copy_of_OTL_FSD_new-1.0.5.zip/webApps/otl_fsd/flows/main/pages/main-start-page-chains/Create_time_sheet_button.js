define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Create_time_sheet_button extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const createTSDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#create_TS_dialog',
        method: 'open',
      });

      $variables.employeeTimeSheetDataTb.employeeId = $variables.emp_number;
    }
  }

  return Create_time_sheet_button;
});
