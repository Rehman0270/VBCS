define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createEmployeeTimeSheetDataTbChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $page.variables.createEmployeeTimeSheetDataTbChainInProgress = true;

      try {
        // Validates EmployeeTimeSheetDataTb form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'new-validation-group',
          },
        }, { id: 'validateEmployeeTimeSheetDataTb' });

        if (!validateFormResult) {
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_EmployeeTimeSheetDataTb',
          body: $page.variables.employeeTimeSheetDataTb,
        }, { id: 'createEmployeeTimeSheetDataTb' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new EmployeeTimeSheetDataTb: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Save failed',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        await Actions.fireNotificationEvent(context, {
          summary: 'Employee TimeSheet Data  saved',
          message: 'New Employee Time Sheet Data successfully created',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        const createTSDialogClose = await Actions.callComponentMethod(context, {
          selector: '#create_TS_dialog',
          method: 'close',
        });

        await $flow.functions.reloadPage();
      } finally {
        // Sets the progress variable to false
        $page.variables.createEmployeeTimeSheetDataTbChainInProgress = false;

        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.employeeTimeSheetDataTb',
  ],
        });

        await Actions.fireDataProviderEvent(context, {
          refresh: null,
          target: $variables.Info_detail_adp,
        });
      }
    }
  }

  return createEmployeeTimeSheetDataTbChain;
});
