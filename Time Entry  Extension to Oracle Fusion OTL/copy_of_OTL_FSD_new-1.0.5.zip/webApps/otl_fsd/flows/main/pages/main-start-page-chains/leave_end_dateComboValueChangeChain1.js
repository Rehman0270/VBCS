define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class leave_end_dateComboValueChangeChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.date_diff_number = $page.functions.getDateDifference($variables.absence_variable.leaveStartDate,$variables.absence_variable.leaveEndDate);

      if ($page.functions.getDateDifference($variables.absence_variable.leaveStartDate,$variables.absence_variable.leaveEndDate)>0) {
        $variables.absence_variable.duration = ((Number($variables.absence_variable.startDateDuration) + Number($variables.absence_variable.endDateDuration) + Number($variables.date_diff_number - 1 )) * 8)/8;
      }
    }
  }

  return leave_end_dateComboValueChangeChain1;
});
