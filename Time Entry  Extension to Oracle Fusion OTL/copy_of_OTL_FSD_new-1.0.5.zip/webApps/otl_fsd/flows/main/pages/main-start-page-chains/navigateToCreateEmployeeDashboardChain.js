define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateEmployeeDashboardChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainCreateEmployeeDashboardResult = await Actions.navigateToPage(context, {
        page: 'main-create-employee-dashboard',
        params: {},
      });
    }
  }

  return navigateToCreateEmployeeDashboardChain;
});
