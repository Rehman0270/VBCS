define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain5 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($variables.master_table_idSelectedId ) {
        const response3 = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_EmployeeTimeSheetDataTb',
          uriParams: {
            'EmployeeTimeSheetDataTb_Id': $variables.master_table_idSelectedId,
          },
          body: $variables.submit_variable,
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'Success',
          message: "Time Sheet submittedd successfully",
          type: 'confirmation',
        });

        await $flow.functions.reloadPage();
      } else {
        const results = await ActionUtils.forEach($variables.Info_detail_adp.data, async (item, index) => {

          const submit = await Actions.callRest(context, {
            endpoint: 'businessObjects/update_EmployeeTimeSheetDataTb',
            uriParams: {
              'EmployeeTimeSheetDataTb_Id': $variables.Info_detail_adp.data[index].employeeTimeSheetId,
            },
            body: $variables.submit_variable,
          });
        }, { mode: 'serial' });

        await Actions.fireNotificationEvent(context, {
          summary: 'Success',
          message: 'Time Sheets submittedd successfully',
          type: 'confirmation',
        });

        await $flow.functions.reloadPage();
      }

    }
  }

  return ButtonActionChain5;
});
