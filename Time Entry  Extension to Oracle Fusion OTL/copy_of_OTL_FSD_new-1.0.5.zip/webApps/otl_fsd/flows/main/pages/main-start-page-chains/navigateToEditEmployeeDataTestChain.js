define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditEmployeeDataTestChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.employeeDataTestId
     */
    async run(context, { employeeDataTestId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainEditEmployeeDataTestResult = await Actions.navigateToPage(context, {
        page: 'main-edit-employee-data-test',
        params: {
          employeeDataTestId: employeeDataTestId,
        },
      });
    }
  }

  return navigateToEditEmployeeDataTestChain;
});
