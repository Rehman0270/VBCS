define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class EndTimeValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.employeeTimeSheetDataTb.endTime = value;

      const totaltimeCreate = await $functions.totaltime($variables.employeeTimeSheetDataTb.startTime, $variables.employeeTimeSheetDataTb.endTime);

      $variables.employeeTimeSheetDataTb.totalTime = totaltimeCreate;
    }
  }

  return EndTimeValueChangeChain;
});
