define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class create_cancel_button extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const createTSDialogClose = await Actions.callComponentMethod(context, {
        selector: '#create_TS_dialog',
        method: 'close',
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.employeeTimeSheetDataTb',
  ],
      });
    }
  }

  return create_cancel_button;
});
