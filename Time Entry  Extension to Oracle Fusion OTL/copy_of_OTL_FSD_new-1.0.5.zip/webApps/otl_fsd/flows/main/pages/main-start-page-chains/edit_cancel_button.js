define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class edit_cancel_button extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const editDialogClose = await Actions.callComponentMethod(context, {
        selector: '#edit_dialog',
        method: 'close',
      });
    }
  }

  return edit_cancel_button;
});
