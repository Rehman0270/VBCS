define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadEmployeeTimeSheetDataTbChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.employeeTimeSheetDataTb1.uomCode = 'HOURS';

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_EmployeeTimeSheetDataTb',
        responseType: 'getEmployeeTimeSheetDataTbResponse1',
        uriParams: {
          'EmployeeTimeSheetDataTb_Id': $variables.master_table_idSelectedId,
        },
      }, { id: 'loadEmployeeTimeSheetDataTb' });

      if (!callRestResult.ok) {
        // Create error message
        const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not load data: status ${callRestResult.status}`;
        // Fires a notification event about failed load
        await Actions.fireNotificationEvent(context, {
          summary: 'Could not load data',
          message: errorMessage,
        }, { id: 'fireErrorNotification' });

        return;
      }

      $page.variables.fetchedEmployeeTimeSheetDataTb = callRestResult.body;
      $page.variables.employeeTimeSheetDataTb1 = $page.variables.fetchedEmployeeTimeSheetDataTb;
      $page.variables.employeeTimeSheetDataTbETag = callRestResult.headers.get('ETag');
    }
  }

  return loadEmployeeTimeSheetDataTbChain;
});
