define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditEmployeeTimeSheetDataTbChain2 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.employeeTimeSheetDataTbId
     */
    async run(context, { employeeTimeSheetDataTbId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainEditEmployeeTimeSheetDataTb2Result = await Actions.navigateToPage(context, {
        page: 'main-edit-employee-time-sheet-data-tb2',
        params: {
          employeeTimeSheetDataTbId: employeeTimeSheetDataTbId,
        },
      });
    }
  }

  return navigateToEditEmployeeTimeSheetDataTbChain2;
});
