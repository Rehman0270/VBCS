define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditEmployeeDashboardChain3 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.employeeDashboardId
     */
    async run(context, { employeeDashboardId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainEditEmployeeDashboard3Result = await Actions.navigateToPage(context, {
        page: 'main-edit-employee-dashboard3',
        params: {
          employeeDashboardId: employeeDashboardId,
        },
      });
    }
  }

  return navigateToEditEmployeeDashboardChain3;
});
