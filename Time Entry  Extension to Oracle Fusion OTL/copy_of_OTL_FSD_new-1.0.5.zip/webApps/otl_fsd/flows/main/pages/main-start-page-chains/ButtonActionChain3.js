define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain3 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const covertIsodate = await $flow.functions.covert_isodate($variables.from_date);

      const covertIsodate2 = await $flow.functions.covert_isodate($variables.to_date);

      const formatteddate = await $functions.get_formatteddate(covertIsodate, covertIsodate2);

      await Actions.fireNotificationEvent(context, {
        summary: 'hiii',
        message: formatteddate,
      });

      $variables.patch_emp_dashboard.recurringPeriod = formatteddate;
    }
  }

  return ButtonActionChain3;
});
