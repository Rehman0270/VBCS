define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditTimeExtensionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.timeExtensionId
     */
    async run(context, { timeExtensionId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainEditTimeExtensionResult = await Actions.navigateToPage(context, {
        page: 'main-edit-time-extension',
        params: {
          timeExtensionId: timeExtensionId,
        },
      });
    }
  }

  return navigateToEditTimeExtensionChain;
});
