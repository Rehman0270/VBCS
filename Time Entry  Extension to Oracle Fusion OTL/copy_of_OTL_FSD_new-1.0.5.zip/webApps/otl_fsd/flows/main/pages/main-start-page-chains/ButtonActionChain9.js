define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain9 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_EmployeeAbsenceEntry',
        uriParams: {
          q: "employeeId='" + $variables.emp_number +"'",
          limit: 499,
          onlyData: true,
          orderBy: 'creationDate:desc',
        },
      });

      $variables.Info_detail_adp.data = response.body.items;
    }
  }

  return ButtonActionChain9;
});
