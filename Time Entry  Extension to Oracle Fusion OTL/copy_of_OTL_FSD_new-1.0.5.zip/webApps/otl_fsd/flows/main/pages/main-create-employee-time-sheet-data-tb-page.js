define([], () => {
  'use strict';

  class PageModule {
  }
  PageModule.prototype.totaltime=function(startTime, endTime) {
        console.log("Raw Start Time:", startTime);
        console.log("Raw End Time:", endTime);

        if (!startTime || !endTime) {
            return "00:00:00"; // Handle missing values
        }

        // Prepend a fixed date to make it a valid ISO datetime string
        let start = new Date("1970-01-01" + startTime);
        let end = new Date("1970-01-01" + endTime);

        console.log("Parsed Start Time:", start);
        console.log("Parsed End Time:", end);

        if (isNaN(start) || isNaN(end)) {
            return "Invalid Time Format"; // Handle incorrect format
        }

        // Calculate time difference in hours
        let diff = (end - start) / (1000*60*60);

        // Handle overnight shifts
        if (diff < 0) {
            diff += 24;
        }

        return diff.toFixed(2);
    };
  
  return PageModule;
});
