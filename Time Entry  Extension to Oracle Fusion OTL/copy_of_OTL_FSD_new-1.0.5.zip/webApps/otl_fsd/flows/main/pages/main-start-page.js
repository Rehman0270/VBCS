define([], () => {
  'use strict';

  class PageModule {
    
  }
  PageModule.prototype.get_formatteddate= function (fromDate, toDate) {
  // Function to format the date in YYYY-MM-DD format
  const formatDate = (date) => {
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
    const dd = String(date.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  // Parse the input dates (assuming the format is YYYY-MM-DD)
  const fromParsedDate = new Date(fromDate);
  const toParsedDate = new Date(toDate);

  // Format the dates back to YYYY-MM-DD
  const formattedFromDate = formatDate(fromParsedDate);
  const formattedToDate = formatDate(toParsedDate);

  // Return the formatted date range
  return `${formattedFromDate} to ${formattedToDate}`;
};
PageModule.prototype.totaltime=function(startTime, endTime) {
        console.log("Raw Start Time:", startTime);
        console.log("Raw End Time:", endTime);

        if (!startTime || !endTime) {
            return "00:00:00"; // Handle missing values
        }

        // Prepend a fixed date to make it a valid ISO datetime string
        let start = new Date("1970-01-01" + startTime);
        let end = new Date("1970-01-01" + endTime);

        console.log("Parsed Start Time:", start);
        console.log("Parsed End Time:", end);

        if (isNaN(start) || isNaN(end)) {
            return "Invalid Time Format"; // Handle incorrect format
        }

        // Calculate time difference in hours
        let diff = (end - start) / (1000*60*60);

        // Handle overnight shifts
        if (diff < 0) {
            diff += 24;
        }

        return diff.toFixed(2);
    };
    PageModule.prototype.totaltime_create=function(startTime, endTime) {
        console.log("Raw Start Time:", startTime);
        console.log("Raw End Time:", endTime);

        if (!startTime || !endTime) {
            return "00:00:00"; // Handle missing values
        }

        // Prepend a fixed date to make it a valid ISO datetime string
        let start = new Date("1970-01-01" + startTime);
        let end = new Date("1970-01-01" + endTime);

        console.log("Parsed Start Time:", start);
        console.log("Parsed End Time:", end);

        if (isNaN(start) || isNaN(end)) {
            return "Invalid Time Format"; // Handle incorrect format
        }

        // Calculate time difference in hours
        let diff = (end - start) / (1000*60*60);

        // Handle overnight shifts
        if (diff < 0) {
            diff += 24;
        }

        return diff.toFixed(2);
    };
     PageModule.prototype.getDateDifference= function(fromDate, toDate) {
      try {
        const from1 = new Date(fromDate);
        const to = new Date(toDate);

        if (isNaN(from1.getTime()) || isNaN(to.getTime())) {
          console.error("Invalid date(s):", fromDate, toDate);
          return null;
        }

        const diffTime = to.getTime() - from1.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays;
      } catch (e) {
        console.error("Error computing date difference:", e);
        return null;
      }
    };

    PageModule.prototype.getTodayDate=function() {
      const today = new Date();
      const yyyy = today.getFullYear();
      const mm = String(today.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
      const dd = String(today.getDate()).padStart(2, '0');

      return `${yyyy}-${mm}-${dd}`;
    };
     
     PageModule.prototype.arraydates=  function (dateTimeArray) {
  if (!Array.isArray(dateTimeArray)) {
    console.error("Input must be an array.");
    return [];
  }

  return dateTimeArray.map(function(item) {
    let dateTime = String(item); // convert to string safely
    if (dateTime.includes("T")) {
      return dateTime.split("T")[0];
    } else {
      return dateTime; // or return "" if you want to ignore invalid formats
    }
  });
};

 PageModule.prototype.arraydates1 = function (dateTimeArray) {
  if (!Array.isArray(dateTimeArray)) {
    console.error("Input must be an array.");
    return [];
  }

  return dateTimeArray.map(item => {
    if (!item) return ""; // handle null/undefined
    const dateTimeStr = String(item);
    if (dateTimeStr.includes("T")) {
      return dateTimeStr.split("T")[0];
    } else {
      return ""; // omit or clean invalid formats
    }
  });
};


  return PageModule;
});
