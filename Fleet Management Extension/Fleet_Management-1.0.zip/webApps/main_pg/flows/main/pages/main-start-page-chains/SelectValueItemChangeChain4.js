define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class AssignUser_ComboValueUpdated_AC extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.UserValidation_Var_Assign = false;

      if ($variables.CheckUserName_Var_N.ownershipType === 'OWNED') {
        $variables.ass_end_contractend = '';
      }
      else{

      $variables.ass_start_contract_start = $variables.current_date;

      $variables.ass_end_contractend = $variables.current_date;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleCntLinesTbl',
        uriParams: {
          fields: 'contractStartDate,contractEndDate',
          limit: '1',
          onlyData: true,
          orderBy: 'creationDate:desc',
          q: "plateNumber LIKE '%" + $variables.oj_table_960285095_1SelectedId + "%'",
        },
      });

      $variables.ass_start_contract_start = response.body.items[0].contractStartDate;

      $variables.ass_end_contractend = response.body.items[0].contractEndDate;

      const response2 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleInformationTbl',
        uriParams: {
          fields: 'licenseExpiryDate',
          onlyData: true,
          q: "userName LIKE '%"+ $variables.Assign_Var_New.userName + "%'",
          limit: '1',
          orderBy: 'creationDate:desc',
        },
      });

      if (response2.body.items[0].licenseExpiryDate < $variables.current_date) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Cannot Assign',
          message: "License of current user" + " " + $variables.Assign_Var_New.userName + " " + "has expired",
        });

        $variables.UserValidation_Var_Assign = true;

        $variables.assign_end_date_var = true;
      }
    }
    }
  }

  return AssignUser_ComboValueUpdated_AC;
});
