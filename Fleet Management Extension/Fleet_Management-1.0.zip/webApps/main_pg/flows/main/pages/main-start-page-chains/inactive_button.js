define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class inactive_button extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.fmVehicleInformationTblId
     */
    async run(context, { fmVehicleInformationTblId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const inactivedialogOpen = await Actions.callComponentMethod(context, {
        selector: '#inactivedialog',
        method: 'open',
      });
    }
  }

  return inactive_button;
});
