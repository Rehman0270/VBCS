define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveFmVehicleInformationTblChain extends ActionChain {

    /**
     * Saves FmVehicleInformationTbl record data
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.fmVehicleInformationTblId 
     */
    async run(context, { fmVehicleInformationTblId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Updates form status to Saving.
      $page.variables.fmVehicleInformationTblEditFormStatus = 'saving';

      try {
        // Validates FmVehicleInformationTbl form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'fmVehicleInformationTbl-validation-group-960285095-1',
          },
        }, { id: 'validateFmVehicleInformationTbl' });

        if (!validateFormResult) {
          return;
        }

        const payload = await this.preparePatchPayload(context, {
          updatedRecord: $page.variables.fmVehicleInformationTbl,
          fetchedRecord: $page.variables.fetchedFmVehicleInformationTbl,
        });

        if (payload === undefined) {
          // Return from the action chain when there are no changes to save
          return;
        }

        // Initiates REST call saving FmVehicleInformationTbl data
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_FmVehicleInformationTbl',
          body: payload,
          headers: $page.variables.fmVehicleInformationTblETag ? { 'If-Match': $page.variables.fmVehicleInformationTblETag } : null,
          requestType: 'json',
          uriParams: {
            'FmVehicleInformationTbl_Id': fmVehicleInformationTblId,
          },
        }, { id: 'saveFmVehicleInformationTbl' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not edit FmVehicleInformationTbl: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Save failed',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Fires a notification event about successful save
        await Actions.fireNotificationEvent(context, {
          summary: 'FmVehicleInformationTbl saved',
          message: 'FmVehicleInformationTbl record successfully updated',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        // Calls action chain re-loading FmVehicleInformationTbl data
        await Actions.callChain(context, {
          chain: 'loadFmVehicleInformationTblChain',
          params: {
            fmVehicleInformationTblId: $page.variables.oj_table_960285095_1SelectedId,
          },
        }, { id: 'callLoadFmVehicleInformationTblChain' });
      } finally {
        // Updates form status to Ready.
        $page.variables.fmVehicleInformationTblEditFormStatus = 'ready';
      }
    }

    /**
     * Prepares PATCH endpoint payload, calculates changed fields.
     * @param {any} updatedRecord
     * @param {any} fetchedRecord
     * @return {any} calculated payload
     */
    async preparePatchPayload(context, { updatedRecord, fetchedRecord }) {
      let payload = updatedRecord;
      let hasChanges = true;
      if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
        // filter the object to only those top-level fields that differ from the original fetched record
        payload = Object.fromEntries(Object.entries(payload).filter(([field, value]) =>
          JSON.stringify(value) !== JSON.stringify(fetchedRecord?.[field])
        ));
        hasChanges = Object.keys(payload).length > 0;
      }

      if (!hasChanges) {
        payload = undefined;
      }

      return payload;
    }

  }

  return saveFmVehicleInformationTblChain;
});
