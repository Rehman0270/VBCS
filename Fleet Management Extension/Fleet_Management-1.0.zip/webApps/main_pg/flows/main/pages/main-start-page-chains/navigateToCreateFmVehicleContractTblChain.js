define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateFmVehicleContractTblChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainCreateFmVehicleContractTblResult = await Actions.navigateToPage(context, {
        page: 'main-create-fm-vehicle-contract-tbl',
        params: {},
      });
    }
  }

  return navigateToCreateFmVehicleContractTblChain;
});
