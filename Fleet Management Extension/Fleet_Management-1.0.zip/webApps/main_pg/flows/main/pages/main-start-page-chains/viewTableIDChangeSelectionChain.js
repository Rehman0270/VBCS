define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class viewTableIDChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.fmVehicleInformationTblId 
     * @param {any} params.rowData 
     */
    async run(context, { fmVehicleInformationTblId, rowData }) {
      const { $page, $variables } = context;

      $variables.AssignBoolean_Var = true;

      $page.variables.ViewTableIDSelectedId = fmVehicleInformationTblId;

      $variables.CheckUserName_Var_N = rowData;
     

      if ($variables.CheckUserName_Var_N.vehicleStatus === 'INACTIVE') {
        $variables.AssignBoolean_Var = true;

        $variables.UnAssignBoolean_Var = true;}

       else if ($variables.CheckUserName_Var_N.userName) {
          $variables.UnAssignBoolean_Var = false;

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.AssignBoolean_Var',
  ],
          });
        } 
         else if (!$variables.CheckUserName_Var_N.userName   && $variables.CheckUserName_Var_N.ownershipType === 'OWNED' ) {
          $variables.AssignBoolean_Var = false;

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.UnAssignBoolean_Var',
  ],
          });
        } 
        else if($variables.CheckUserName_Var_N.vehicleStatus === 'ACTIVE') {
          const RES1 = await Actions.callRest(context, {
            endpoint: 'businessObjects/getall_FmVehicleContractTbl',
            uriParams: {
              limit: '1',
              onlyData: true,
              orderBy: 'creationDate:desc',
              q: "plateNumber LIKE '%"  + $variables.oj_table_960285095_1SelectedId + "%'",
            },
          });
            const RES = await Actions.callRest(context, {
              endpoint: 'businessObjects/getall_FmVehicleCntLinesTbl',
              uriParams: {
                limit: '1',
                onlyData: true,
                orderBy: 'creationDate:desc',
                q: "plateNumber LIKE '%"  + $variables.oj_table_960285095_1SelectedId + "%'",
              },
            });

        if (RES1.body.items[0].contractEndDate <= $variables.current_date && RES.body.items[0].contractEndDate <= $variables.current_date)  {

            $variables.AssignBoolean_Var = true;

          await Actions.fireNotificationEvent(context, {
            summary: 'Please Renew the Contract',
            type: 'error',
            message: "Renew the contract of the vehicle"+ " " + fmVehicleInformationTblId + " " +  " to be assigned to a new user",
          });

            await Actions.resetVariables(context, {
              variables: [
    '$page.variables.UnAssignBoolean_Var',
  ],
            });
        }
        else{
          $variables.AssignBoolean_Var = false;

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.UnAssignBoolean_Var',
  ],
          });
          
        }
       
       
        }
    
       
        
        
      
       
    }
    
    
  }

  return viewTableIDChangeSelectionChain;
});
