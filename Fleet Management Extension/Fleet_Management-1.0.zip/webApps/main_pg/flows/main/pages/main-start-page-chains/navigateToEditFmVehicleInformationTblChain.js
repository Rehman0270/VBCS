define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditFmVehicleInformationTblChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.fmVehicleInformationTblId
     */
    async run(context, { fmVehicleInformationTblId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainEditFmVehicleInformationTblResult = await Actions.navigateToPage(context, {
        page: 'main-edit-fm-vehicle-information-tbl',
        params: {
          fmVehicleInformationTblId: fmVehicleInformationTblId,
        },
      });
    }
  }

  return navigateToEditFmVehicleInformationTblChain;
});
