define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class InputDateValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.validateassignDate_Var',
  ],
      });

      $variables.assign_end_date_var = false;

      const covertIsodate = await $flow.functions.covert_isodate(value);

      const minimumDate = await $flow.functions.minimum_date(covertIsodate);

      $variables.assign_enddate = minimumDate;
    }
  }

  return InputDateValueChangeChain;
});
