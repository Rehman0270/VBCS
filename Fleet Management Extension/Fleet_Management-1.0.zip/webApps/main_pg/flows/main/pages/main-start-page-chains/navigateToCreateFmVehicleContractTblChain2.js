define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateFmVehicleContractTblChain2 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainCreateFmVehicleContractTbl2Result = await Actions.navigateToPage(context, {
        page: 'main-create-fm-vehicle-contract-tbl2',
        params: {},
      });
    }
  }

  return navigateToCreateFmVehicleContractTblChain2;
});
