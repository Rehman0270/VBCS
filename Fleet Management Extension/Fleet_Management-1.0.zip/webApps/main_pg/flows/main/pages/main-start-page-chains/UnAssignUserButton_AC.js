define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class UnAssignUserButton_AC extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $current } = context;

      $variables.progresscircle = true;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleUserTbl',
        uriParams: {
          q: "userName LIKE '%"+ $variables.fmVehicleInformationTbl.userName + "%'",
        },
      });

      const response2 = await Actions.callRest(context, {
        endpoint: 'businessObjects/update_FmVehicleUserTbl',
        uriParams: {
          'FmVehicleUserTbl_Id': response.body.items[0].fPersonId,
        },
        body: $variables.Uassign_var_usertb,
      });

      $variables.fmVehicleInformationTbl.assignmentEndDate = $variables.current_date;

      $variables.UnAssign_Var_New.userName = '';
      $variables.UnAssign_Var_New.assignmentEndDate = $variables.fmVehicleInformationTbl.assignmentEndDate;
      $variables.UnAssign_Var_New.assignmentStartDate = $variables.fetchedFmVehicleInformationTbl.assignmentStartDate;
      $variables.UnAssign_Var_New.activity = 'UnAssigned';
      $variables.UnAssign_Var_New.activityComments = $variables.fmVehicleInformationTbl.activityComments;

      const UnAssignUserPatch = await Actions.callRest(context, {
        endpoint: 'businessObjects/update_FmVehicleInformationTbl',
        uriParams: {
          'FmVehicleInformationTbl_Id': $variables.oj_table_960285095_1SelectedId,
        },
        body: $variables.UnAssign_Var_New,
      });

      const response3 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleAssignmentTbl',
        uriParams: {
          limit: '1',
          onlyData: true,
          orderBy: 'creationDate:desc',
          q: "plateNumber LIKE '%" + $variables.oj_table_960285095_1SelectedId + "%'",
        },
      });

      const response4 = await Actions.callRest(context, {
        endpoint: 'businessObjects/update_FmVehicleAssignmentTbl',
        uriParams: {
          'FmVehicleAssignmentTbl_Id': response3.body.items[0].assignmentId,
        },
        body: $variables.ass_purpose,
      });

      if (!UnAssignUserPatch.ok && !response2.ok && !response4.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error While Unassigning An User.',
          message: 'Please Try Again !!!',
          type: 'error',
        });

        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.progresscircle',
  ],
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Unassignment Completed Successfully.',
          message: "Vehicle Number : "+$variables.oj_table_960285095_1SelectedId+ " Has Beeen UnAssigned From The User : "+$variables.fmVehicleInformationTbl.userName,
          type: 'confirmation',
          displayMode: 'transient',
        });

        const unassignParentDialogClose = await Actions.callComponentMethod(context, {
          selector: '#UnassignParentDialog',
          method: 'close',
        });

        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.ass_purpose.assignmentPurpose',
  ],
        });

        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.progresscircle',
  ],
        });
      }

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.GetVehicleInformation_Var_ADP,
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.GetVehicleInformation_Var_ADP',
  ],
      });
    }
  }

  return UnAssignUserButton_AC;
});
