define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain3 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const assignPopUpIDOpen = await Actions.callComponentMethod(context, {
        selector: '#AssignPopUpID',
        method: 'open',
      });
    }
  }

  return ButtonActionChain3;
});
