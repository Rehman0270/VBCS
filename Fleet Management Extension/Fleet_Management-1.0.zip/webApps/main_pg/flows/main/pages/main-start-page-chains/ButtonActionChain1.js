define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain1 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.Assign_Var_New',
  ],
      });

      const assignDiologBoxOpen = await Actions.callComponentMethod(context, {
        selector: '#AssignDiologBox',
        method: 'open',
      });

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleInformationTbl',
        uriParams: {
          limit: '1',
          fields: 'assignmentEndDate',
          onlyData: true,
          orderBy: 'creationDate:desc',
          q: "plateNumber LIKE '%"+$page.variables.oj_table_960285095_1SelectedId+"%'",
        },
      });

      if (response.body.items[0].assignmentEndDate === null && $variables.CheckUserName_Var_N.ownershipType === 'OWNED') {
         $flow.variables.previous_end_date = $variables.current_date;
      }
      

      else if (response.body.items[0].assignmentEndDate === null && $variables.CheckUserName_Var_N.ownershipType === 'LEASED') {
        $flow.variables.previous_end_date = $variables.current_date;
        
      }
      else{
                $flow.variables.previous_end_date =response.body.items[0].assignmentEndDate;
      }
    }
  }

  return ButtonActionChain1;
});
