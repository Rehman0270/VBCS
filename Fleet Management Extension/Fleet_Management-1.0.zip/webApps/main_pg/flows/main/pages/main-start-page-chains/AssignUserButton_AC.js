define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class AssignUserButton_AC extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.progresscircle = true;

      const AssignUserPatch = await Actions.callRest(context, {
        endpoint: 'businessObjects/update_FmVehicleInformationTbl',
        uriParams: {
          'FmVehicleInformationTbl_Id': $variables.oj_table_960285095_1SelectedId,
        },
        body: $variables.Assign_Var_New,
      });

      const response3 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleUserTbl',
        uriParams: {
          q: "userName LIKE '%" + $variables.Assign_Var_New.userName + "%'",
          onlyData: true,
        },
      });

      $variables.Assign_var_usertb.vehicleNumber = $variables.oj_table_960285095_1SelectedId;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/update_FmVehicleUserTbl',
        body: $variables.Assign_var_usertb,
        uriParams: {
          'FmVehicleUserTbl_Id': response3.body.items[0].fPersonId,
        },
      });

      const response4 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleAssignmentTbl',
        uriParams: {
          limit: '1',
          onlyData: true,
          orderBy: 'creationDate:desc',
          q: "plateNumber LIKE '%" + $variables.oj_table_960285095_1SelectedId + "%'",
        },
      });

      const response2 = await Actions.callRest(context, {
        endpoint: 'businessObjects/update_FmVehicleAssignmentTbl',
        uriParams: {
          'FmVehicleAssignmentTbl_Id': response4.body.items[0].assignmentId,
        },
        body: $variables.ass_purpose,
      });

    if (!AssignUserPatch.ok && !response.ok && !response2.ok) {

      await Actions.fireNotificationEvent(context, {
        summary: 'Encountered An Error',
        message: 'Please Check The Input !! And Try Again',
        type: 'error',
      });

        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.progresscircle',
  ],
        });
    } else {

      await Actions.fireNotificationEvent(context, {
        summary: "Vehicle : " +$variables.oj_table_960285095_1SelectedId+ " Has Been  Assigned To Employee : "+$variables.Assign_Var_New.userName,
        type: 'confirmation',
        message: 'The vehicle has been successfully allocated.',
        displayMode: 'transient',
      });

      const assignDiologBoxClose = await Actions.callComponentMethod(context, {
        selector: '#AssignDiologBox',
        method: 'close',
      });

        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.ass_purpose.assignmentPurpose',
  ],
        });

        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.select_employee',
  ],
        });

        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.progresscircle',
  ],
        });
    }

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.fmVehicleUserTblListSDP_idle,
      });

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.GetVehicleInformation_Var_ADP,
      });
    }
  }

  return AssignUserButton_AC;
});
