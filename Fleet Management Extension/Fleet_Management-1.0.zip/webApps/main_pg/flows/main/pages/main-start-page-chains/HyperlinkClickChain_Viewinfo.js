define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class HyperlinkClickChain_Viewinfo extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     * @param {string} params.curr_value 
     */
    async run(context, { key, index, current, curr_value }) {
      const { $page, $flow, $application, $constants, $variables, $current } = context;

      const processingrequestOpen = await Actions.callComponentMethod(context, {
        selector: '#processingrequest',
        method: 'open',
      });

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleInformationTbl',
        uriParams: {
          q: "plateNumber LIKE '%" + $variables.GetVehicleInformation_Var_ADP.data[index].plateNumber + "%'",
          onlyData: true,
          fields: 'plateNumber',
          limit: '1',
        },
      });

      await Actions.callChain(context, {
        chain: 'navigateToFmVehicleInformationTblDetailChain',
        params: {
          fmVehicleInformationTblId: response.body.items[0].plateNumber,
        },
      });

      const processingrequestClose = await Actions.callComponentMethod(context, {
        selector: '#processingrequest',
        method: 'close',
      });

    }
  }

  return HyperlinkClickChain_Viewinfo;
});
