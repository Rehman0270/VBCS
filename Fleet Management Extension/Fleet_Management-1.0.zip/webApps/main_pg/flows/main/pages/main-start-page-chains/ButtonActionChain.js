define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.OwnerShip_Input_Var',
    '$page.variables.PlateNumber_Input_Var',
    '$page.variables.VehicleStatus_Input_Var',
    '$page.variables.AssignmentStatus_Input_Var',
    '$page.variables.Branch_Input_Var',
    '$page.variables.ass_status_checkbox',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.userName_Input_Var',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.selected_employee',
  ],
      });

      await Actions.fireDataProviderEvent(context, {
        target: $variables.GetVehicleInformation_Var_ADP,
        refresh: null,
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.GetVehicleInformation_Var_ADP',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.ass_purpose',
    '$page.variables.Uassign_var_usertb',
    '$page.variables.UnAssign_Var_New',
    '$page.variables.Assign_Var_New',
    '$page.variables.UnAssignBoolean_Var',
  ],
      });
    }
  }

  return ButtonActionChain;
});
