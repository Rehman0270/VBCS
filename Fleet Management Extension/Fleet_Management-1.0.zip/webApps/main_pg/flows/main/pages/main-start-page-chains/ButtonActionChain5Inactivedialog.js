define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain5Inactivedialog extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const inactivedialogClose = await Actions.callComponentMethod(context, {
        selector: '#inactivedialog',
        method: 'close',
      });
    }
  }

  return ButtonActionChain5Inactivedialog;
});
