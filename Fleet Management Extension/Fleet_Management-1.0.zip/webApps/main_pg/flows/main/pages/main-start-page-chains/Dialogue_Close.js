define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Dialogue_Close extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const assignDiologBoxClose = await Actions.callComponentMethod(context, {
        selector: '#AssignDiologBox',
        method: 'close',
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.select_employee',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.ass_purpose.assignmentPurpose',
  ],
      });
    }
  }

  return Dialogue_Close;
});
