define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain5 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const unassignParentDialogClose = await Actions.callComponentMethod(context, {
        selector: '#UnassignParentDialog',
        method: 'close',
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.ass_purpose.assignmentPurpose',
  ],
      });
    }
  }

  return ButtonActionChain5;
});
