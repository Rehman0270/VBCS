define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Search_Button_ActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $functions.showGifAndBlurPage();

      const FilteredResult = await $functions.checkStrings($variables.PlateNumber_Input_Var, $variables.OwnerShip_Input_Var, $variables.VehicleStatus_Input_Var, $variables.Branch_Input_Var, $variables.userName_Input_Var, $variables.unassign_check_box);

      const GetRestVehicleInformation_Response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleInformationTbl',
        uriParams: {
          q: FilteredResult,
          onlyData: true,
          limit: 499,
          orderBy: 'creationDate:desc',
        },
      });

      await $functions.hidegifandshowpage();

      $variables.GetVehicleInformation_Var_ADP.data = GetRestVehicleInformation_Response.body.items;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.AssignBoolean_Var',
  ],
      });
    }
  }

  return Search_Button_ActionChain;
});
