define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Reactivebutton extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.progresscircle = true;

      $variables.act_var.activityComments = $variables.act_inac_comments;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/update_FmVehicleInformationTbl',
        uriParams: {
          'FmVehicleInformationTbl_Id': $variables.oj_table_960285095_1SelectedId,
        },
        body: $variables.act_var,
      });

      if (response.ok === true) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Re-active',
          type: 'confirmation',
          message: "Vehicle "+" " + $variables.oj_table_960285095_1SelectedId+"has been marked as back in service.",
        });

        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.progresscircle',
  ],
        });
      }

      const inactivedialogClose = await Actions.callComponentMethod(context, {
        selector: '#inactivedialog',
        method: 'close',
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.act_inac_comments',
  ],
      });
    }
  }

  return Reactivebutton;
});
