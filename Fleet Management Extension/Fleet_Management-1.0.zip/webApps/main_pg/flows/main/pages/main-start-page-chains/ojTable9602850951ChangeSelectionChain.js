define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable9602850951ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.fmVehicleInformationTblId
     */
    async run(context, { fmVehicleInformationTblId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.oj_table_960285095_1SelectedId = fmVehicleInformationTblId;
    }
  }

  return ojTable9602850951ChangeSelectionChain;
});
