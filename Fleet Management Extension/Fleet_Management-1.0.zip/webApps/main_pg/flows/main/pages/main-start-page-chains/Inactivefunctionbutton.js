define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Inactivefunctionbutton extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.progresscircle = true;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleInformationTbl',
        uriParams: {
          onlyData: true,
          fields: 'assignmentStartDate',
          q: "plateNumber LIKE '%" + $variables.oj_table_960285095_1SelectedId + "%'",
          orderBy: 'creationDate:desc',
        },
      });

      if (response.body.items[0].assignmentStartDate === null) {
        $variables.today_date.assignmentStartDate = '';
        $variables.today_date.assignmentEndDate = '';
      }

      else{ $variables.today_date.assignmentStartDate = $variables.fetchedFmVehicleInformationTbl.assignmentStartDate;
      $variables.today_date.activityComments = $variables.act_inac_comments;
                  $variables.today_date.assignmentEndDate = $variables.fetchedFmVehicleInformationTbl.assignmentEndDate;

      }
      const response2 = await Actions.callRest(context, {
        endpoint: 'businessObjects/update_FmVehicleInformationTbl',
        uriParams: {
          'FmVehicleInformationTbl_Id': $variables.oj_table_960285095_1SelectedId,
        },
        body: $variables.today_date,
      });

      if ($variables.CheckUserName_Var_N.ownershipType === 'LEASED') {
        const response3 = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_FmVehicleContractTbl',
          uriParams: {
            q: "plateNumber LIKE '%" + $variables.oj_table_960285095_1SelectedId + "%'",
          },
        });

        const response4 = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_FmVehicleContractTbl',
          uriParams: {
            'FmVehicleContractTbl_Id': response3.body.items[0].contractNumber,
          },
          body: $variables.today_contract_date,
        });

        const response6 = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_FmVehicleCntLinesTbl',
          uriParams: {
            q: "plateNumber LIKE '%" + $variables.oj_table_960285095_1SelectedId + "%'",
            limit: '1',
            orderBy: 'creationDate:desc',
            onlyData: true,
          },
        });

        const response5 = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_FmVehicleCntLinesTbl',
          uriParams: {
            'FmVehicleCntLinesTbl_Id': response6.body.items[0].contractLineId,
          },
          body: $variables.cnt_enddate_var,
        });

        if (response2.ok === true && response4.ok === true) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Success',
            type: 'confirmation',
            message: $variables.oj_table_960285095_1SelectedId + " " +  "is successfully Inactive",
          });

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.progresscircle',
  ],
          });
        }
        else{
          await Actions.fireNotificationEvent(context, {
            message: 'Error ',
            summary: 'Vehice not inactive',
            type: 'error',
          });

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.progresscircle',
  ],
          });
          
        }
      }
      else if ($variables.CheckUserName_Var_N.ownershipType === 'OWNED'){
        if (response2.ok === true) {
                    await Actions.fireNotificationEvent(context, {
                      summary: 'Success',
                      type: 'confirmation',
                      message: "Vehicle "+$variables.oj_table_960285095_1SelectedId + " " +  "has been marked as out of service.",
                    });

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.progresscircle',
  ],
          });
        }
        else{
          await Actions.fireNotificationEvent(context, {
            summary: 'Vehice not Inactive',
            message: 'Error',
            type: 'error',
          });

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.progresscircle',
  ],
          });
          
        }
      
      }

      const inactivedialogClose = await Actions.callComponentMethod(context, {
        selector: '#inactivedialog',
        method: 'close',
      });

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.GetVehicleInformation_Var_ADP,
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.act_inac_comments',
  ],
      });
    }
  }

  return Inactivefunctionbutton;
});
