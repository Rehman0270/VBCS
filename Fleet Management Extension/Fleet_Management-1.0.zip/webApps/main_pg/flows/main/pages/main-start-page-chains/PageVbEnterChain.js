define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.AssignBoolean_Var = true;

      const GetRestPlateNumber_Response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleInformationTbl',
        uriParams: {
          fields: 'plateNumber,branch',
          limit: 499,
        },
      });

      const unique = await $functions.unique(GetRestPlateNumber_Response.body.items);

      $variables.GetPlateNumber_Var_ADP.data = unique.platn;

      $variables.Get_branch_adp.data = unique.branch;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleUserTbl',
        uriParams: {
          limit: 499,
          onlyData: true,
          q: "userStatus LIKE '%"+ "IDLE" + "%'",
        },
      });

      $variables.Get_vehuser_ADP.data = response.body.items;

      const response2 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleUserTbl',
        uriParams: {
          fields: 'userName',
          limit: 499,
        },
      });

      const unique2 = await $functions.unique(response2.body.items);

      $variables.Username_var_ADP.data = unique2.usern;
    }
  }

  return PageVbEnterChain;
});
