define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToFmVehicleInformationTblDetailChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.fmVehicleInformationTblId
     */
    async run(context, { fmVehicleInformationTblId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainFmVehicleInformationTblDetailResult = await Actions.navigateToPage(context, {
        page: 'main-fm-vehicle-information-tbl-detail',
        params: {
          fmVehicleInformationTblId: fmVehicleInformationTblId,
        },
      });
    }
  }

  return navigateToFmVehicleInformationTblDetailChain;
});
