define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadFmVehicleInformationTblChain extends ActionChain {

    /**
     * Loads FmVehicleInformationTbl record data
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.fmVehicleInformationTblId 
     */
    async run(context, { fmVehicleInformationTblId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Updates form status to Loading.
      $page.variables.fmVehicleInformationTblEditFormStatus = 'loading';

      try {
        // Tests the REST call can be initiated
        if (true && fmVehicleInformationTblId !== undefined) {
          // Initiates REST call loading FmVehicleInformationTbl data
          const callRestResult = await Actions.callRest(context, {
            endpoint: 'businessObjects/get_FmVehicleInformationTbl',
            uriParams: {
              'FmVehicleInformationTbl_Id': fmVehicleInformationTblId,
            },
            responseType: 'getFmVehicleInformationTblResponse',
          }, { id: 'loadFmVehicleInformationTbl' });

          if (!callRestResult.ok) {

            return;
          }

          // Assigns data loaded by the REST call to the FmVehicleInformationTbl variable
          $page.variables.fetchedFmVehicleInformationTbl = callRestResult.body;

          // Assigns data loaded by the REST call to the FmVehicleInformationTbl variable
          $page.variables.fmVehicleInformationTblETag = callRestResult.headers.get('ETag');

          // Assigns data loaded by the REST call to the FmVehicleInformationTbl editable record variable
          $page.variables.fmVehicleInformationTbl = $page.variables.fetchedFmVehicleInformationTbl;
        }
      } finally {
        // Updates form status to Ready.
        $page.variables.fmVehicleInformationTblEditFormStatus = 'ready';
      }
    }
  }

  return loadFmVehicleInformationTblChain;
});
