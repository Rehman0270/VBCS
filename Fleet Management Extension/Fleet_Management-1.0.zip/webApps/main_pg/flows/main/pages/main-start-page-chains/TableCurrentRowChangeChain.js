define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableCurrentRowChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.currentRow 
     */
    async run(context, { currentRow }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.CheckUserName_Var = currentRow.userName;
    }
  }

  return TableCurrentRowChangeChain;
});
