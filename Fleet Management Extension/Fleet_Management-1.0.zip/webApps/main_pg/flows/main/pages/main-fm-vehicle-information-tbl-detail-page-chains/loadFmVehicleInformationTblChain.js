define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadFmVehicleInformationTblChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_FmVehicleInformationTbl',
        responseType: 'getFmVehicleInformationTblResponse',
        uriParams: {
          'FmVehicleInformationTbl_Id': $variables.fmVehicleInformationTblId,
        },
      }, { id: 'loadFmVehicleInformationTbl' });

      if (!callRestResult.ok) {
        await Actions.fireNotificationEvent(context, {
          message: 'Could not load data: status ' + callRestResult.status,
          displayMode: 'persist',
          type: 'error',
          summary: 'Could not load data',
        }, { id: 'fireErrorNotification' });

        return;
      }

      $page.variables.fmVehicleInformationTbl = callRestResult.body;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleContractTbl',
        uriParams: {
          fields: 'vendor,contractStatus',
          limit: '1',
          onlyData: true,
          orderBy: 'creationDate:desc',
          q: "plateNumber LIKE '%"  + $variables.fmVehicleInformationTblId + "%'",
        },
      });

      $variables.vendor_contract.vendor = response.body.items[0].vendor;

      $variables.vendor_contract.contractStatus = response.body.items[0].contractStatus;
    }
  }

  return loadFmVehicleInformationTblChain;
});
