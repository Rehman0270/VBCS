define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleCntLinesTbl',
        uriParams: {
          fields: 'contractStatus',
          limit: '1',
          orderBy: 'creationDate:desc',
          q: "plateNumber LIKE '%"  + $variables.fmVehicleInformationTblId + "%'",
          onlyData: true,
        },
      });

      $variables.cnt_status.contractStatus = response.body.items[0].contractStatus;
    }
  }

  return PageVbEnterChain;
});
