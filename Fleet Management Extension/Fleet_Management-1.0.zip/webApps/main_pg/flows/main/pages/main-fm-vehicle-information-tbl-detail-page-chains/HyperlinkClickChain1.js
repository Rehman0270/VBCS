define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class HyperlinkClickChain1 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $flow.variables.Update_CurrentPlate_Var = $variables.fmVehicleInformationTbl.plateNumber;
      $flow.variables.Update_CurrentCNTnumber_Var = $variables.fmVehicleInformationTbl.leaseContractId;
      $flow.variables.Update_CurrentChassis_Var = $variables.fmVehicleInformationTbl.chassisNumber;

      const contractHistoryDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#ContractHistory_Dialog',
        method: 'open',
      });
    }
  }

  return HyperlinkClickChain1;
});
