define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateFmVehicleContractTblChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $variables, $application, $flow } = context;

      const UpdateContractResponseNew = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_FmVehicleContractTbl',
        uriParams: {
          'FmVehicleContractTbl_Id': $variables.fmVehicleInformationTbl.leaseContractId,
          fields: 'plateNumber,ownershipType,chassisNumber,contractNumber,creationDate',
        },
      });

      const Amend_Contract_Var_ADP = UpdateContractResponseNew.body;

      const navigateToPageMainCreateFmVehicleContractTblResult = await Actions.navigateToPage(context, {
        page: 'main-create-fm-vehicle-contract-tbl',
        params: {},
      });
    }
  }

  return navigateToCreateFmVehicleContractTblChain;
});
