define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToCreateFmVehicleCntLinesTblChain4 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const navigateToPageMainCreateFmVehicleCntLinesTbl3Result = await Actions.navigateToPage(context, {
        page: 'main-create-fm-vehicle-cnt-lines-tbl3',
        params: {},
      });
    }
  }

  return navigateToCreateFmVehicleCntLinesTblChain4;
});
