define([], () => {
  'use strict';

  class PageModule {
  }
  PageModule.prototype.unique= function(result)
 { 
  let uniqueResult_pt = []; 
  let final_pt= [];
  
if (result && result.length > 0) 
      { for (let i = 0; i < result.length; i++) 
         { 
         if (!uniqueResult_pt[result[i].plateType])
            {
            final_pt.push({
            plateType: result[i].plateType
            
});
uniqueResult_pt[result[i].plateType] = 1;
}
         }
      }
      return {
             platet:final_pt
      };
 };
  return PageModule;
});
