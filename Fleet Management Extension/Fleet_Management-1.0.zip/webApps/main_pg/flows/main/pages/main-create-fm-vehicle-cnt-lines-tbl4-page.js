define([], () => {
  'use strict';

  class PageModule {
  }
  PageModule.prototype.minus145 = function () {
    var currentDate = new Date();
    
    // Set time to 00:00:00 to ignore the time part
    currentDate.setHours(0, 0, 0, 0);

    return currentDate;
}

// ------

// PageModule.prototype.calculateEndDate = function (startDate) {
//     var startDateObj = new Date(startDate);

//     // Set the time to 00:00:00 to ensure we're working with just the date part
//     startDateObj.setHours(0, 0, 0, 0);

//     // Create the assignment end date as the day after the start date (adjust as needed)
//     var endDateObj = new Date(startDateObj);
//     endDateObj.setDate(startDateObj.getDate() + 1);  // This ensures end date is on or after the start date

//     return endDateObj;
// }

// PageModule.prototype.calculateEndDate = function (startDate) {
//     // Split the start date string (MM/DD/YYYY)
//     var dateParts = startDate.split('/');  // This splits the date into [MM, DD, YYYY]
    
//     // Create a new Date object: new Date(year, month, day)
//     // Month is 0-based, so we subtract 1 from the month
//     var startDateObj = new Date(dateParts[2], dateParts[0] - 1, dateParts[1]);
    
//     // Set the time to 00:00:00 to ignore the time part
//     startDateObj.setHours(0, 0, 0, 0);

//     // Create the assignment end date as the day after the start date
//     var endDateObj = new Date(startDateObj);
//     endDateObj.setDate(startDateObj.getDate() + 1);  // End date is one day after the start date

//     return endDateObj;
// }


// PageModule.prototype.calculateEndDate = function (startDate) {
//     // Split the start date string (MM/DD/YYYY)
//     var dateParts = startDate.split('/');  // This splits the date into [MM, DD, YYYY]
    
//     // Create a new Date object: new Date(year, month, day)
//     // Month is 0-based, so we subtract 1 from the month
//     var startDateObj = new Date(dateParts[2], dateParts[0] - 1, dateParts[1]);
    
//     // Set the time to 00:00:00 to ignore the time part
//     startDateObj.setHours(0, 0, 0, 0);

//     // Create the assignment end date as the day after the start date
//     var endDateObj = new Date(startDateObj);
//     endDateObj.setDate(startDateObj.getDate() + 1);  // End date is one day after the start date

//     // Format the end date as MM/DD/YYYY
//     var month = (endDateObj.getMonth() + 1).toString().padStart(2, '0');  // Months are 0-based, so add 1
//     var day = endDateObj.getDate().toString().padStart(2, '0');
//     var year = endDateObj.getFullYear();

//     // Return the formatted date
//     return month + '/' + day + '/' + year;
// }


// PageModule.prototype.calculateEndDate = function (startDate) {
//     // Split the start date string (MM/DD/YYYY)
//     var dateParts = startDate.split('/');  // This splits the date into [MM, DD, YYYY]

//     // Check if the dateParts array is valid
//     if (dateParts.length !== 3) {
//         throw new Error("Invalid start date format. Expected MM/DD/YYYY.");
//     }

//     // Ensure each part is a valid number
//     var month = parseInt(dateParts[0], 10);
//     var day = parseInt(dateParts[1], 10);
//     var year = parseInt(dateParts[2], 10);

//     // Check if the date is valid
//     if (isNaN(month) || isNaN(day) || isNaN(year) || month < 1 || month > 12 || day < 1 || day > 31) {
//         throw new Error("Invalid date values in the start date.");
//     }

//     // Create a new Date object: new Date(year, month - 1, day)
//     // Month is 0-based, so we subtract 1 from the month
//     var startDateObj = new Date(year, month - 1, day);
    
//     // If the startDateObj is invalid (i.e., "Invalid Date"), return an error
//     if (isNaN(startDateObj)) {
//         throw new Error("Invalid Date object created from start date.");
//     }

//     // Set the time to 00:00:00 to ignore the time part
//     startDateObj.setHours(0, 0, 0, 0);

//     // Create the assignment end date as the day after the start date
//     var endDateObj = new Date(startDateObj);
//     endDateObj.setDate(startDateObj.getDate() + 1);  // End date is one day after the start date

//     // Return the Date object (not the formatted string)
//     return endDateObj;
// }

// PageModule.prototype.calculateEndDate = function (startDate) {
//     // Split the start date string (YYYY-MM-DD)
//     var dateParts = startDate.split('-');  // This splits the date into [YYYY, MM, DD]
    
//     // Check if the dateParts array is valid
//     if (dateParts.length !== 3) {
//         throw new Error("Invalid start date format. Expected YYYY-MM-DD.");
//     }

//     // Ensure each part is a valid number
//     var year = parseInt(dateParts[0], 10);
//     var month = parseInt(dateParts[1], 10) - 1; // Months are 0-based, so subtract 1 from month
//     var day = parseInt(dateParts[2], 10);

//     // Check if the date is valid
//     if (isNaN(month) || isNaN(day) || isNaN(year) || month < 0 || month > 11 || day < 1 || day > 31) {
//         throw new Error("Invalid date values in the start date.");
//     }

//     // Create a new Date object: new Date(year, month, day)
//     var startDateObj = new Date(year, month, day);
    
//     // If the startDateObj is invalid (i.e., "Invalid Date"), return an error
//     if (isNaN(startDateObj)) {
//         throw new Error("Invalid Date object created from start date.");
//     }

//     // Set the time to 00:00:00 to ignore the time part
//     startDateObj.setHours(0, 0, 0, 0);

//     // Create the assignment end date as the day after the start date
//     var endDateObj = new Date(startDateObj);
//     endDateObj.setDate(startDateObj.getDate() + 1);  // End date is one day after the start date

//     // Return the Date object (not the formatted string)
//     return endDateObj;
// }

PageModule.prototype.calculateEndDate = function (startDate) {
    // Split the start date string (YYYY-MM-DD)
    var dateParts = startDate.split('-');  // This splits the date into [YYYY, MM, DD]
    
    // Check if the dateParts array is valid
    if (dateParts.length !== 3) {
        throw new Error("Invalid start date format. Expected YYYY-MM-DD.");
    }

    // Ensure each part is a valid number
    var year = parseInt(dateParts[0], 10);
    var month = parseInt(dateParts[1], 10) - 1; // Months are 0-based, so subtract 1 from month
    var day = parseInt(dateParts[2], 10);

    // Check if the date is valid
    if (isNaN(month) || isNaN(day) || isNaN(year) || month < 0 || month > 11 || day < 1 || day > 31) {
        throw new Error("Invalid date values in the start date.");
    }

    // Create a new Date object: new Date(year, month, day)
    var startDateObj = new Date(year, month, day);
    
    // If the startDateObj is invalid (i.e., "Invalid Date"), return an error
    if (isNaN(startDateObj)) {
        throw new Error("Invalid Date object created from start date.");
    }

    // Set the time to 00:00:00 to ignore the time part
    startDateObj.setHours(0, 0, 0, 0);

    // Create the assignment end date as the day after the start date
    var endDateObj = new Date(startDateObj);
    endDateObj.setDate(startDateObj.getDate() );  // End date is one day after the start date

    // Format the date as MM/DD/YYYY
    let month1 = endDateObj.getMonth() + 1;  // Month is 0-based, so add 1
    let day1 = endDateObj.getDate();
    let year1 = endDateObj.getFullYear();

    // Return the formatted date in MM/DD/YYYY format
    return month1 + '/' + day1 + '/' + year1;
}


PageModule.prototype.updateContractEndDate = function (event) {
    var startDate = event.detail.value;  // Get the start date from the event
    if (startDate) {
        // Call the calculateEndDate function
        var endDate = PageModule.prototype.calculateEndDate(startDate);

        // Update the contractEndDate value
        this.$variables.fmVehicleCntLinesTbl.contractEndDate = endDate;
    }
};



// -----
  return PageModule;
});
