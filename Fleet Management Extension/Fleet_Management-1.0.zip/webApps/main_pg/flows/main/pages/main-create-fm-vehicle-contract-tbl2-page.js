define([
  "require",  "knockout", "ojs/ojbootstrap", "ojs/ojconverterutils-i18n", "ojs/ojknockout", "ojs/ojdatetimepicker", "ojs/ojselectcombobox", "ojs/ojlabel"
], (require, exports, ko, Bootstrap, ojconverterutils_i18n_1) => {
  'use strict';

  class PageModule {
  }
  PageModule.prototype.min_date = function(mindate){
  
    const currentDate = new Date(mindate);
    const futureDate = new Date(currentDate);
    
    futureDate.setDate( currentDate.getDate() + 1 );
    const formattedDate = futureDate.getFullYear()  + '-' +
                        String(futureDate.getMonth() + 1  ).padStart(2, '0') + '-' +
                        String(futureDate.getDate()).padStart(2, '0');
  
  // Return the formatted future date
  return formattedDate;
    
  };
  PageModule.prototype.covert_iso=function(dateInput) {
  // Create a Date object from the input
  const date = new Date(dateInput);

  // Check if the date is valid
  if (isNaN(date)) {
    console.log("Invalid date provided.");
    return null;
  }

  // Extract year, month, and day
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based, so add 1 and pad with leading zero if needed
  const day = String(date.getDate()).padStart(2, '0'); // Pad day with leading zero if needed

  // Return the formatted date as YYYY-MM-DD
  return `${year}-${month}-${day}`;
};

PageModule.prototype.add_lease= function (dateInput, monthsToAdd) {
  // Convert input date to the correct format (YYYY-MM-DD)
  const dateParts = dateInput.split('/');
  const formattedDate = `${dateParts[2]}-${String(dateParts[0]).padStart(2, '0')}-${String(dateParts[1]).padStart(2, '0')}`;

  // Create a Date object from the formatted input date
  const currentDate = new Date(formattedDate);

  // Check if the date is valid
  if (isNaN(currentDate)) {
    console.log("Invalid date provided.");
    return null;
  }

  // Add the specified number of months
  currentDate.setMonth(currentDate.getMonth() + monthsToAdd);

  // Extract year, month, and day from the new date
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, '0'); // Months are 0-based, so add 1
  const day = String(currentDate.getDate()).padStart(2, '0');

  // Return the formatted future date as YYYY-MM-DD
  return `${year}-${month}-${day}`;
};
 PageModule.prototype.trial= function(dateInput, monthsToAdd) {
  // Create a Date object from the input date string (assumes YYYY-MM-DD format)
 const currentDate = new Date(dateInput);

  // Check if the date is valid
  if (isNaN(currentDate)) {
    console.log("Invalid date provided.");
    return null;
  }

  // Store original day
  const originalDay = currentDate.getDate();

  // Add the specified number of months
  currentDate.setMonth(currentDate.getMonth() + monthsToAdd);

  // Check if the new date overflowed (e.g. Feb 31 → Mar 2)
  if (currentDate.getDate() < originalDay) {
    // Already adjusted to last valid day, now subtract 1 more day
    currentDate.setDate(currentDate.getDate() - 1);
  } else {
    // Subtract one day from the calculated date
    currentDate.setDate(currentDate.getDate() - 1);
  }

  // Extract year, month, and day from the adjusted date
  const year = currentDate.getFullYear();
  const month = String(currentDate.getMonth() + 1).padStart(2, '0'); // Months are 0-based
  const day = String(currentDate.getDate()).padStart(2, '0');

  // Return the formatted future date as YYYY-MM-DD
  return `${year}-${month}-${day}`;
};


  return PageModule;
  
});
