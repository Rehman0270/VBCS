define([], () => {
  'use strict';
 


  class PageModule {
    
  }
  PageModule.prototype.checkStrings = function(param1, param2, param3, param4, param6, param5) {
    const queryParts = [];
    const queryStrings = {
        plateNumber1: 'plateNumber=',
        ownershipType1: 'ownershipType=',
        vehicleStatus1: 'vehicleStatus=',
        branchStatus1: 'branch=',
        userName1: 'userName',
        userName2: 'userName='
    };

    // Array to hold the params and their corresponding query string keys
    const params = [
        { param: param1, queryKey: queryStrings.plateNumber1 },
        { param: param2, queryKey: queryStrings.ownershipType1 },
        { param: param3, queryKey: queryStrings.vehicleStatus1 },
        { param: param4, queryKey: queryStrings.branchStatus1 },
        { param: param6, queryKey: queryStrings.userName2 }
    ];

    // Loop through each parameter and add the query part if it's not null or undefined
    params.forEach(({ param, queryKey }, index) => {
        if (param !== null && param !== undefined) {  // Check for null or undefined
            const condition = `${queryKey}'${param}'`;
            // If it's not the first query part, add ' AND '
            if (queryParts.length > 0) {
                queryParts.push(' AND ');
            }
            queryParts.push(condition);
        }
    });

    // Handling the special condition for param5 
    if (param5 === 'Assigned') {
        // If userName is assigned (not null/undefined/empty)
        const condition = `${queryStrings.userName1} IS NOT NULL`;
        if (queryParts.length > 0) {
            queryParts.push(' AND ');
        }
        queryParts.push(condition);
    } else if (param5 === 'UnAssigned') {
        // If userName is unassigned (null or empty)
        const condition = `${queryStrings.userName1} IS NULL`;
        if (queryParts.length > 0) {
            queryParts.push(' AND ');
        }
        queryParts.push(condition);
    }

    // If no valid parameters are provided, return null
    if (queryParts.length === 0) {
        return null;
    }

    // Join the query parts and return the final query string
    return queryParts.join(' ');
};


// ----------Disabling Dates -----------------------
PageModule.prototype.dis_assign_reactive = function (){
    let button = document.getElementById('assignid');

// Then, disable the button
button.disabled = true;
  };

PageModule.prototype.user_exists=function (array, value){

  for (let i = 0; i < array.length; i++) {
    if (array[i] === value) {
      return true;
    }
  }
  return false;

};
PageModule.prototype.user_present= function (array, value) {
    return array.includes(value);
};




   PageModule.prototype.addition_date = function (mindate){
    let currentDate = new Date(mindate);
    let pastDate = new Date();
    // Decrease the number of days -- 10 days in this example
    pastDate.setDate( currentDate.getDate()+1);
    return pastDate;
  };

  // 

 PageModule.prototype.minus1 = function () {
    let currentDate = new Date();
    
    // Set time to 00:00:00 to ignore the time part
    currentDate.setHours(0, 0, 0, 0);

    return currentDate;
};

// ------------------AssignEndDate Func


PageModule.prototype.calculateEndDate123 = function (startDate) {
    // Split the start date string (YYYY-MM-DD)
    let dateParts = startDate.split('-');  // This splits the date into [YYYY, MM, DD]
    
    // Check if the dateParts array is valid
    if (dateParts.length !== 3) {
        throw new Error("Invalid start date format. Expected YYYY-MM-DD.");
    }

    // Ensure each part is a valid number
    let year = parseInt(dateParts[0], 10);
    let month = parseInt(dateParts[1], 10) - 1; // Months are 0-based, so subtract 1 from month
    let day = parseInt(dateParts[2], 10);

    // Check if the date is valid
    if (isNaN(month) || isNaN(day) || isNaN(year) || month < 0 || month > 11 || day < 1 || day > 31) {
        throw new Error("Invalid date values in the start date.");
    }

    // Create a new Date object: new Date(year, month, day)
    let startDateObj = new Date(year, month, day);
    
    // If the startDateObj is invalid (i.e., "Invalid Date"), return an error
    if (isNaN(startDateObj)) {
        throw new Error("Invalid Date object created from start date.");
    }

    // Set the time to 00:00:00 to ignore the time part
    startDateObj.setHours(0, 0, 0, 0);

    // Create the assignment end date as the day after the start date
    let endDateObj = new Date(startDateObj);
    endDateObj.setDate(startDateObj.getDate() );  // End date is one day after the start date

    // Format the date as MM/DD/YYYY
    let month1 = endDateObj.getMonth() + 1;  // Month is 0-based, so add 1
    let day1 = endDateObj.getDate();
    let year1 = endDateObj.getFullYear();

    // Return the formatted date in MM/DD/YYYY format
    return month1 + '/' + day1 + '/' + year1;
};


PageModule.prototype.disablerowid= function(rowId) {
    // Get the table element by its ID
    let table = document.getElementById('ViewTableID'); // Replace 'yourTableId' with your actual table ID

    if (table) {
        // Find the row using the provided rowId
        let row = document.getElementById(rowId); // The row with this ID should be the target
        
        if (row) {
            // Disable all input elements within this row
            let inputs = row.querySelectorAll('input, select, textarea, button');
            inputs.forEach(function(input) {
                input.disabled = true; // Disable each element
            });

            // Optionally, you can also change the row's visual style to indicate it's disabled
            row.style.backgroundColor = "#f0f0f0"; // Light gray background (optional)
            row.style.opacity = 0.5; // Optional: change opacity to visually show that it's disabled
        } else {
            console.error('Row with ID ' + rowId + ' not found.');
        }
    } else {
        console.error('Table not found.');
    }
};
  
PageModule.prototype.unique= function(result)
 { 
  let uniqueResult_pn = []; 
  let final_pn= [];
  let uniqueResult_un = []; 
  let final_un= [];
  let uniqueResult_b = []; 
  let final_b= [];
if (result && result.length > 0) 
      { for (let i = 0; i < result.length; i++) 
         { 
         if (!uniqueResult_pn[result[i].plateNumber])
            {
            final_pn.push({
            plateNumber: result[i].plateNumber
            
});
uniqueResult_pn[result[i].plateNumber] = 1;
}
         if (!uniqueResult_un[result[i].userName])
            {
            final_un.push({
            userName: result[i].userName
            
});
uniqueResult_un[result[i].userName] = 1;
}
           if (!uniqueResult_b[result[i].branch])
            {
            final_b.push({
            branch: result[i].branch
            
});
uniqueResult_b[result[i].branch] = 1;
}
}
}
return {platn:final_pn,
       usern: final_un,
      branch:final_b
};
 };

 PageModule.prototype.multiple_lov= function(data)
 {
   let final=[];
   if (data && data.length > 0) 
      { for (let element = 0; element < data.length; element++) 
         { 
    final.push(
      {
        "mod_username" :`${element.userName} (${element.userStatus})` ,
        "fPersonId" : element.fPersonId
      }
    );
   }
  }
    return final;
 };
  
  PageModule.prototype.getname = function(context){
    return context.data.userName;

  };

  PageModule.prototype.showGifAndBlurPage= function() {
    // Get the body element
    var body = document.body;

    // Get the container for the GIF (make sure the container ID is correct)
    var gifOverlay = document.getElementById('gifOverlay');
    
    // Show the GIF overlay
    gifOverlay.style.display = 'flex';
    
   
     
};

    
    // Optionally: Add a listener to hide the GIF and remove blur when clicked
     PageModule.prototype.hidegifandshowpage= function() {
            var body = document.body;

    // Get the container for the GIF (make sure the container ID is correct)
        var gifOverlay = document.getElementById('gifOverlay');
        // Hide the GIF overlay
        gifOverlay.style.display = 'none';
        
        // Remove the blur effect from the body
        body.style.filter = '';
        
        // Enable all content again
        body.style.pointerEvents = '';
 
};

  // --------------------------------------------------------------
  return PageModule;
});
