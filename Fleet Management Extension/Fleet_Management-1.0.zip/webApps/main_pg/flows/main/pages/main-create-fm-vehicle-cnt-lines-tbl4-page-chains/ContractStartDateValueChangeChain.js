define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ContractStartDateValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.SelectedContractStartDate_VAR',
  ],
      });

      $variables.renew_cnt_end_date = false;

      const covertIsodate = await $flow.functions.covert_isodate(value);

      const trial = await $flow.functions.trial(covertIsodate, $variables.numberdate);

      $variables.fmVehicleCntLinesTbl.contractEndDate = trial;
    }
  }

  return ContractStartDateValueChangeChain;
});
