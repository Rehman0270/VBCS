define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {
       
    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.renew_cont_start_date = $variables.current_date;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleCntLinesTbl',
        uriParams: {
          fields: 'contractEndDate',
          limit: '1',
          onlyData: true,
          q: "plateNumber LIKE '%" + $variables.fmVehicleCntLinesTbl.plateNumber + "%'",
          orderBy: 'creationDate:desc',
        },
      });

      $variables.renew_cont_start_date = response.body.items[0].contractEndDate;
    }
     
  }

  return PageVbEnterChain;
});
