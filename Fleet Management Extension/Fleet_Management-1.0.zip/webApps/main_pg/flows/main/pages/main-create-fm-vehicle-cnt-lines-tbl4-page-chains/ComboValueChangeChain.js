define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ComboValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.lease_period = false;

      $variables.numberdate = $variables.fmVehicleCntLinesTbl.contractStatus;

      $variables.fmVehicleCntLinesTbl.contractStartDate = $variables.renew_cont_start_date;

      await Actions.callChain(context, {
        chain: 'ContractStartDateValueChangeChain',
        params: {
          value: $variables.fmVehicleCntLinesTbl.contractStartDate,
        },
      });
    }
  }

  return ComboValueChangeChain;
});
