define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createFmVehicleCntLinesTblChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $page.variables.createFmVehicleCntLinesTblChainInProgress = true;

      try {
        // Validates FmVehicleCntLinesTbl form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        }, { id: 'validateFmVehicleCntLinesTbl' });

        if (!validateFormResult) {
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_FmVehicleCntLinesTbl',
          body: $page.variables.fmVehicleCntLinesTbl,
        }, { id: 'createFmVehicleCntLinesTbl' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new FmVehicleCntLinesTbl: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Contract Renewal Request Failed',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        await Actions.fireNotificationEvent(context, {
          summary: "Contract of Vehicle  Number : "+ ""+ $flow.variables.Update_CurrentPlate_Var + "  Successfully Renewed",
          message: 'Contract Has Been Renewed Successfully',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });
      } finally {
        // Sets the progress variable to false
        $page.variables.createFmVehicleCntLinesTblChainInProgress = false;
      }
    }
  }

  return createFmVehicleCntLinesTblChain;
});
