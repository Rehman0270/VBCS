define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadFmVehicleInformationTblChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const callRestResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/get_FmVehicleInformationTbl',
        responseType: 'getFmVehicleInformationTblResponse',
        uriParams: {
          'FmVehicleInformationTbl_Id': $page.variables.fmVehicleInformationTblId,
        },
      }, { id: 'loadFmVehicleInformationTbl' });

      if (!callRestResult.ok) {
        // Create error message
        const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not load data: status ${callRestResult.status}`;
        // Fires a notification event about failed load
        await Actions.fireNotificationEvent(context, {
          summary: 'Could not load data',
          message: errorMessage,
        }, { id: 'fireErrorNotification' });

        return;
      }

      $page.variables.fetchedFmVehicleInformationTbl = callRestResult.body;
      $page.variables.fmVehicleInformationTbl = $page.variables.fetchedFmVehicleInformationTbl;
      $page.variables.fmVehicleInformationTblETag = callRestResult.headers.get('ETag');
    }
  }

  return loadFmVehicleInformationTblChain;
});
