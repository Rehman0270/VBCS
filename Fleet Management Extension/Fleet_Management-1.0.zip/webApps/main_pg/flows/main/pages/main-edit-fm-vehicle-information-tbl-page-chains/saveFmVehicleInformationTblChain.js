define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveFmVehicleInformationTblChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $page.variables.saveFmVehicleInformationTblChainInProgress = true;

      try {
        // Validates FmVehicleInformationTbl form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        });

        if (!validateFormResult) {
          return;
        }

        const payload = await this.preparePatchPayload(context, {
          updatedRecord: $page.variables.fmVehicleInformationTbl,
          fetchedRecord: $page.variables.fetchedFmVehicleInformationTbl,
        });

        if (payload === undefined) {
          // Return from the action chain when there are no changes to save
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_FmVehicleInformationTbl',
          body: payload,
          uriParams: {
            'FmVehicleInformationTbl_Id': $page.variables.fmVehicleInformationTblId,
          },
        }, { id: 'saveFmVehicleInformationTbl' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not update FmVehicleInformationTbl: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Save failed',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        await Actions.fireNotificationEvent(context, {
          summary: 'Vehicle Information Updated',
          message: "Information of vehicle number  " + " "+ $variables.fmVehicleInformationTblId + " " +  " has been  successfully updated",
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        const toMainStart2 = await Actions.navigateToPage(context, {
          page: 'main-start',
        });
      } finally {

        const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_FmVehicleContractTbl',
          uriParams: {
            limit: '1',
            onlyData: true,
            q: "plateNumber LIKE '%"  + $variables.fmVehicleInformationTblId + "%'",
          },
        });

        const response2 = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_FmVehicleContractTbl',
          uriParams: {
            'FmVehicleContractTbl_Id': response.body.items[0].contractNumber,
          },
          body: $variables.vendor_contract,
        });
        // Sets the progress variable to false
        $page.variables.saveFmVehicleInformationTblChainInProgress = false;

        const toMainStart = await Actions.navigateToPage(context, {
          page: 'main-start',
        });
      }
    }

    /**
     * Prepares PATCH endpoint payload, calculates changed fields.
     * @param {any} updatedRecord
     * @param {any} fetchedRecord
     * @return {any} calculated payload
     */
    async preparePatchPayload(context, { updatedRecord, fetchedRecord }) {
      const { $variables } = context;
      let payload = updatedRecord;
      let hasChanges = true;
      if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
        // filter the object to only those top-level fields that differ from the original fetched record
        payload = Object.fromEntries(Object.entries(payload).filter(([field, value]) =>
          JSON.stringify(value) !== JSON.stringify(fetchedRecord?.[field])
        ));
        hasChanges = Object.keys(payload).length > 0;
      }

      if (!hasChanges) {
        payload = undefined;
      }

      return payload;
    }

    /**
     * @param {Object} context
     */
    async callRestFunction(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
    }

  }

  return saveFmVehicleInformationTblChain;
});
