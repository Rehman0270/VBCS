define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleInformationTbl',
        uriParams: {
          fields: 'plateType',
          limit: 499,
        },
      });

      const unique = await $functions.unique(response.body.items);

      $variables.Get_Platetype_ADP.data = unique.platet;

      const response2 = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleContractTbl',
        uriParams: {
          fields: 'vendor',
          limit: '1',
          onlyData: true,
          q: "plateNumber LIKE '%"+ $variables.fmVehicleInformationTblId+ "%'",
        },
      });

      $variables.vendor_contract.vendor = response2.body.items[0].vendor;
    }
  }

  return PageVbEnterChain;
});
