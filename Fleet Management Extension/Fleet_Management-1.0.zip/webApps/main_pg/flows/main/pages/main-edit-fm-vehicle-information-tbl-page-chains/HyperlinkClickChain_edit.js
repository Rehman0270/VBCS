define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class HyperlinkClickChain_edit extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $flow.variables.Update_CurrentChassis_Var = $variables.fmVehicleInformationTbl.chassisNumber;
      $flow.variables.Update_CurrentPlate_Var = $variables.fmVehicleInformationTbl.plateNumber;
      $flow.variables.Update_CurrentCNTnumber_Var = $variables.fmVehicleInformationTbl.leaseContractId;
    }
  }

  return HyperlinkClickChain_edit;
});
