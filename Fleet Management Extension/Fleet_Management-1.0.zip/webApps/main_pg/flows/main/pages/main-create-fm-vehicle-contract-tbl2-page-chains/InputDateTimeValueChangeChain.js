define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class InputDateTimeValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.create_contract_startdate = false;

      $variables.numberdate = $variables.fmVehicleContractTbl.contractStatus;

      const covertIso = await $functions.covert_iso(value, $variables.fmVehicleContractTbl.contractStatus);

      const trial = await $functions.trial(covertIso, $variables.numberdate);

      $variables.contract_min_date.contractEndDate = trial;

      $variables.fmVehicleContractTbl.contractEndDate = trial;
    }
  }

  return InputDateTimeValueChangeChain;
});
