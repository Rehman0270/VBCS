define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createFmVehicleContractTblChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $page.variables.createFmVehicleContractTblChainInProgress = true;

      try {
        // Validates FmVehicleContractTbl form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        }, { id: 'validateFmVehicleContractTbl' });

        if (!validateFormResult) {
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_FmVehicleContractTbl',
          body: $variables.fmVehicleContractTbl,
        }, { id: 'createFmVehicleContractTbl' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new FmVehicleContractTbl: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Contract Submission Has Been Failed .',
            message: 'Error: The plate number already exists. Please try a different one.',
          }, { id: 'fireErrorNotification' });

          return;
        }

        await Actions.fireNotificationEvent(context, {
          summary: "Registration Successful for Vehicle Number : "+$variables.fmVehicleContractTbl.plateNumber,
          message: 'Contract Has Been Submitted !!!',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        const toMainEditFmVehicleInformationTbl = await Actions.navigateToPage(context, {
          page: 'main-edit-fm-vehicle-information-tbl',
          params: {
            fmVehicleInformationTblId: $variables.fmVehicleContractTbl.plateNumber,
          },
        });
      } finally {
        // Sets the progress variable to false
        $page.variables.createFmVehicleContractTblChainInProgress = false;
      }
    }
  }

  return createFmVehicleContractTblChain;
});
