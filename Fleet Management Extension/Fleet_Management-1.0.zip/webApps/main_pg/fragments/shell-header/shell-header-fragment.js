define([], () => {
  'use strict';

  class FragmentModule {
  }
    FragmentModule.prototype.expired_users = function(data)
 {
   let final=[];
    
   if (data && data.length > 0) 
      { for (let element = 0; element < data.length; element++) 
         { if( data[element] && data[element].licenseExpiryDate && data[element].userName){
             const currentDate = new Date();
             const expiryDate = new Date(data[element].licenseExpiryDate);
             expiryDate.setHours(0, 0, 0, 0);
             currentDate.setHours(0, 0, 0, 0);
          if( expiryDate < currentDate ){
    final.push(
      {
        userName: data[element].userName,
        licenseExpiryDate: data[element].licenseExpiryDate
      }
    );
          }
   }
  }
      }
    return {final_usern: final} ;
 };
  
  
  return FragmentModule;
});
