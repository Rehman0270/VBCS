define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class IconClickChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $fragment, $application, $constants, $variables, $functions } = context;

      const iconDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#icon-dialog',
        method: 'open',
      });

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_FmVehicleInformationTbl',
        uriParams: {
          onlyData: true,
          fields: 'userName,licenseExpiryDate',
          limit: 499,
        },
      });

      const expiredUsers = await $functions.expired_users(response.body.items);

      $variables.Expired_users.data = expiredUsers.final_usern;
    }
  }

  return IconClickChain;
});
