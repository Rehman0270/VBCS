define([], () => {
  'use strict';

  class PageModule {
    // Function to show response
    showResponse(response) {
      this.typeResponse(response, "chatBox");
    }

    // Typing animation function
    typeResponse(text, elementId) {
      let i = 0;
      const element = document.getElementById(elementId);
      element.innerHTML = "";
      const interval = setInterval(() => {
        if (i < text.length) {
          element.innerHTML = text.substring(0, i + 1);
          i++;
          element.scrollTop = element.scrollHeight;
        } else {
          clearInterval(interval);
        }
      }, 30);
    }
  }

  return PageModule;
});
