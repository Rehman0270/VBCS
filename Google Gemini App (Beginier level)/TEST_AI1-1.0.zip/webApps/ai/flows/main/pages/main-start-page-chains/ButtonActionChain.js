define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.question_disable = true;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.responce',
  ],
      });

      if ($variables.request !== '') {

        let response = await Actions.callRest(context, {
          endpoint: 'POST_Geminai/postGemini2_0FlashGenerateContent',
          body: {
         "contents": [
  {
           "parts": [
    {
             "text": + '"'+ $variables.request +'"'
            }
   ]
          }
 ]
        },
        });

        $variables.responce = response.body.candidates[0].content.parts[0].text;
      }

      $variables.question_disable = false;
    }
  }

  return ButtonActionChain;
});
