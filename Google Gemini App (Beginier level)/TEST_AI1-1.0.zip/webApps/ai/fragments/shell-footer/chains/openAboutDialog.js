define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class openAboutDialog extends ActionChain {

    /**
     * Opens About Dialog
     * @param {Object} context
     */
    async run(context) {
      const { $application } = context;

      await Actions.openUrl(context, {
        url: 'www.linkedin.com/in/rehman27',
      });
    }
  }

  return openAboutDialog;
});
