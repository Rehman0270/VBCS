define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const results = await ActionUtils.forEach([
        $variables.uploadDataADP.data,
      ], async (item, index) => {

        $variables.var_create_BOrec = $variables.uploadDataADP.data;

        // Clean the payload (Remove \r from both keys and values)
        $variables.RESTpayload = cleanObject(item[index]);

        const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_BaEmp',
          body: $variables.RESTpayload,
        });

        await Actions.fireNotificationEvent(context, {
          summary: JSON.stringify($variables.RESTpayload),
        });

        await Actions.fireNotificationEvent(context, {
          summary: JSON.stringify(response),
          type: 'info',
        });
      }, { mode: 'serial' });
    }
  }

  // Function to remove \r from keys and values
  function cleanObject(obj) {
    return Object.fromEntries(
      Object.entries(obj).map(([key, value]) => [
        key.replace(/\r/g, ''),  // Remove \r from key
        typeof value === 'string' ? value.replace(/\r/g, '') : value // Remove \r from value
      ])
    );
  }

  return ButtonActionChain;
});
