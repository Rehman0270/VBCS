define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'Tech_master_ATP/postTech_master_fss',
        body: $variables.ATPVAR,
      });

      await Actions.fireNotificationEvent(context, {
        summary: 'Notification',
        message: 'Submitted Successfully ',
        type: 'confirmation',
      });

      await Actions.resetVariables(context, {
        variables: [
    '$variables.ATPVAR',
  ],
      });

      await Actions.navigateBack(context, {
      });
    }
  }

  return ButtonActionChain;
});
