define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

;
      const response = await Actions.callRest(context, {
        endpoint: 'tech_master_ATPGET/getTech_master_fss',
      });

      $variables.TechMasterATPGETVAR.data = response.body.items;

      const unique = await $functions.unique(response.body.items);

          $variables.UNIQUEtechName.data = unique.technician_name;
            $variables.UNIQUEtechNumber.data = unique.technician_no;
            $variables.UNIQUEEmployeename.data = unique.employee_name;
            $variables.UNIQUEEmployeEnumber.data = unique.employee_no;

    //  await Actions.fireNotificationEvent(context, {
      //  summary: JSON.stringify($variables.UNIQUEtechNumber.data),
     // });

    }
  }

  return PageVbEnterChain;
});
