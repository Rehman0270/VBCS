define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'Get_FusionSuppliers/getFscmRestApiResources11_13_18_05Suppliers',
      });

      $variables.FusionSupplierVAR.data = response.body.items;

      // await Actions.fireNotificationEvent(context, {
      //   summary: JSON.stringify($variables.FusionSupplierVAR),
      // });
    }
  }

  return PageVbEnterChain;
});
