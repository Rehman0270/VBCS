define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await Actions.fireDataProviderEvent(context, {
        target: $variables.TechMasterATPGETVAR,
        refresh: null,
      });

      const checkStrings = await $functions.checkStrings($variables.TECH_NAME_SEARCH_VAR, $variables.TECH_NUMBER_SEARCH_VAR, $variables.EMPLOYEE_NAME_SEARCH_VAR, $variables.EMPLOYEE_NUMBER_SEARCH_VAR);

      const response = await Actions.callRest(context, {
        endpoint: 'tech_master_ATPGET/getTech_master_fss',
        uriParams: {
          q: checkStrings,
        },
      });

      $variables.TechMasterATPGETVAR.data = response.body.items;

      await Actions.resetVariables(context, {
        variables: [
    '$variables.EMPLOYEE_NAME_SEARCH_VAR',
    '$variables.EMPLOYEE_NUMBER_SEARCH_VAR',
    '$variables.TECH_NAME_SEARCH_VAR',
    '$variables.TECH_NUMBER_SEARCH_VAR',
  ],
      });
    }
  }

  return ButtonActionChain1;
});
