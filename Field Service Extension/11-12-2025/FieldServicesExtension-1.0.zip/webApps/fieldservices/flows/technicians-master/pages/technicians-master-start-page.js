define([], () => {
  'use strict';

  class PageModule {}

  // ------------------------------------------
  // UNIQUE FUNCTION
  // ------------------------------------------
  PageModule.prototype.unique = function (result) {
    let uniqueTechName = [];
    let finalTechName = [];

    let uniqueTechNo = [];
    let finalTechNo = [];

    let uniqueEmpName = [];
    let finalEmpName = [];

    let uniqueEmpNo = [];
    let finalEmpNo = [];

    if (result && result.length > 0) {
      for (let i = 0; i < result.length; i++) {

        // technician_name
        if (!uniqueTechName[result[i].technician_name]) {
          finalTechName.push({
            technician_name: result[i].technician_name
          });
          uniqueTechName[result[i].technician_name] = 1;
        }

        // technician_no
        if (!uniqueTechNo[result[i].technician_no]) {
          finalTechNo.push({
            technician_no: result[i].technician_no
          });
          uniqueTechNo[result[i].technician_no] = 1;
        }

        // employee_name
        if (!uniqueEmpName[result[i].employee_name]) {
          finalEmpName.push({
            employee_name: result[i].employee_name
          });
          uniqueEmpName[result[i].employee_name] = 1;
        }

        // employee_no
        if (!uniqueEmpNo[result[i].employee_no]) {
          finalEmpNo.push({
            employee_no: result[i].employee_no
          });
          uniqueEmpNo[result[i].employee_no] = 1;
        }
      }
    }

    return {
      technician_name: finalTechName,
      technician_no: finalTechNo,
      employee_name: finalEmpName,
      employee_no: finalEmpNo
    };
  };

  // ------------------------------------------
  // CHECK STRINGS FUNCTION (4 PARAMETERS)
  // ------------------------------------------
  PageModule.prototype.checkStrings = function (
    technician_name,
    technician_no,
    employee_name,
    employee_no
  ) {
    // If all parameters are null → return empty JSON
    if (
      technician_name === null &&
      technician_no === null &&
      employee_name === null &&
      employee_no === null
    ) {
      return '{}';
    }

    const params = [
      { key: 'technician_name', value: technician_name },
      { key: 'technician_no', value: technician_no },
      { key: 'employee_name', value: employee_name },
      { key: 'employee_no', value: employee_no }
    ];

    const queryObject = {};

    // Include only valid (non-null / non-undefined) fields
    params.forEach(({ key, value }) => {
      if (value !== null && value !== undefined) {
        queryObject[key] = value;
      }
    });

    return JSON.stringify(queryObject);
  };

  return PageModule;
});
