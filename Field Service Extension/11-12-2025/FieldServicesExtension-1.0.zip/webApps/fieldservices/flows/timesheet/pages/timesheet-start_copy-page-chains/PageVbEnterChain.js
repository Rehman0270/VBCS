define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {string} params.TimeSheetDate_Search_Var
     */
    async run(context, { event, TimeSheetDate_Search_Var }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

     const response = await Actions.callRest(context, {
     endpoint: 'Get_Time_SheetRecords/getTime_sheet_fs',
      });

 $variables.Get_All_Time_Sheet_Records_ADP.data = response.body.items;

      $variables.Employee_Name_Search_Var = $application.variables.Emp_Name;

      const empD = $variables.Get_All_Time_Sheet_Records_ADP.data.find(item =>
        item.employee_name.toLowerCase() === $application.variables.Emp_Name.toLowerCase()
      );


      if (empD) {
        $variables.Employee_No_Search_Va = empD.employee_no;

        //await Actions.fireNotificationEvent(context, {
        //  summary: $variables.EMPNUM_VAR,
        //});

      }

      const checkEmployeeFilters = await $functions.checkEmployeeFilters($variables.Employee_Name_Search_Var, $variables.Employee_No_Search_Va, TimeSheetDate_Search_Var);

      const response2 = await Actions.callRest(context, {
        endpoint: 'Get_Time_SheetRecords/getTime_sheet_fs',
        uriParams: {
          q: checkEmployeeFilters,
        },
      });

      $variables.Get_All_Time_Sheet_Records_ADP.data = response2.body.items;
  
    }
  }

  return PageVbEnterChain;
});
