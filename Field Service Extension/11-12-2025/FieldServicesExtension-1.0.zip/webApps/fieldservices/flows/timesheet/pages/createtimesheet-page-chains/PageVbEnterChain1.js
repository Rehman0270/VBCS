define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'service_request_sc/getService_request_fs',
      });

      $variables.Get_SR_RecordsAll_VAR_ADP.data = response.body.items;

      const response2 = await Actions.callRest(context, {
        endpoint: 'tech_master_ATPGET/getTech_master_fss',
      });

     const uniqueEmployees = await $functions.uniqueEmployees(response2.body.items);

     // await Actions.fireNotificationEvent(context, {
     //   summary: JSON.stringify(uniqueEmployees),
    //  });

      $variables.Get_TM_All_Records.data = uniqueEmployees;
    }
  }

  return PageVbEnterChain1;
});
