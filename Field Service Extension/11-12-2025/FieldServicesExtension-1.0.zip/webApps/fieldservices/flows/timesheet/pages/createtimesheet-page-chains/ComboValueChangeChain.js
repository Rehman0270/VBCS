define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ComboValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     */
    async run(context, { event, previousValue, value, updatedFrom }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const empD = $variables.Get_TM_All_Records.data.find(item =>
        item.employee_name.toLowerCase() === value.toLowerCase()
      );


      if (empD) {
        $variables.EMPNUM_VAR = empD.employee_no;

        //await Actions.fireNotificationEvent(context, {
        //  summary: $variables.EMPNUM_VAR,
        //});

      }
    }
  }

  return ComboValueChangeChain;
});
