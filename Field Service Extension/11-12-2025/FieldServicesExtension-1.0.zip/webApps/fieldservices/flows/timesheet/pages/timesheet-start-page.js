define([], () => {
  'use strict';

  class PageModule {
  }

  // ========== UNIQUE EMPLOYEES FUNCTION ==========
  PageModule.prototype.uniqueEmployees = function (result) {
    let unique_employee_name = {};
    let final_employee_name = [];

    let unique_employee_no = {};
    let final_employee_no = [];

    if (result && result.length > 0) {
      for (let i = 0; i < result.length; i++) {
        const item = result[i];

        // Unique Employee Name
        if (item.employee_name && !unique_employee_name[item.employee_name]) {
          final_employee_name.push({ employeeName: item.employee_name });
          unique_employee_name[item.employee_name] = true;
        }

        // Unique Employee No
        if (item.employee_no && !unique_employee_no[item.employee_no]) {
          final_employee_no.push({ employeeNumber: item.employee_no });
          unique_employee_no[item.employee_no] = true;
        }
      }
    }

    return {
      employee_name: final_employee_name,
      employee_no: final_employee_no
    };
  };

  // ========== CHECK FILTER FUNCTION ==========
  PageModule.prototype.checkEmployeeFilters = function (employee_name, employee_no) {

  // Treat "" as null for both fields
  const clean_name = employee_name && employee_name.trim() !== "" ? employee_name : null;
  const clean_no = employee_no && employee_no.trim() !== "" ? employee_no : null;

  // If both are empty/null → return empty JSON
  if (clean_name === null && clean_no === null) {
    return '{}';
  }

  const params = [
    { key: 'employee_name', value: clean_name },
    { key: 'employee_no', value: clean_no }
  ];

  const queryObject = {};

  params.forEach(({ key, value }) => {
    if (value !== null) {
      queryObject[key] = value;
    }
  });

  return JSON.stringify(queryObject);
};

  return PageModule;
});
