define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils'
], function (
  ActionChain,
  Actions,
  ActionUtils
) {
  'use strict';

  class ButtonActionChain extends ActionChain {

    async run(context, params) {
      const { $variables } = context;

      let dp = $variables.Get_All_Time_Sheet_Records_ADP;

      let newRow = {
        DATE: "",
        SR: "",
        PROJECT: "",
        TIMEIN: "",
        TIMEOUT: "",
        TOTALTIME: ""
      };

      // Add row at top
      dp.data.unshift(newRow);

      // Refresh table
      dp.refresh();

      return;
    }
  }

  return ButtonActionChain;
});
