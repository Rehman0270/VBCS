define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils'
], function (
  ActionChain,
  Actions,
  ActionUtils
) {
  'use strict';

  class RemoveRowChain extends ActionChain {

    async run(context, params) {
      const { $page, $variables } = context;

      try {
        const dp = $variables.Get_All_Time_Sheet_Records_ADP;
        if (!dp || !Array.isArray(dp.data)) {
          console.error('ADP not found or dp.data is not an array', dp);
          return;
        }

        let index = -1;

        // 1) If action was invoked from inside a row, use params.$current.data
        const currentRowObj = params && params.$current && params.$current.data;
        if (currentRowObj) {
          // Find the index of that exact object in the ADP array.
          index = dp.data.findIndex(r => r === currentRowObj);

          // If strict equality fails (different object references), try matching by a key (ID/SR/etc)
          if (index === -1) {
            // try with common keys — adjust the keys you actually use
            const keyCandidates = ['ID', 'id', 'SR', 'sr'];
            for (let key of keyCandidates) {
              if (currentRowObj[key] !== undefined) {
                index = dp.data.findIndex(r => r && r[key] !== undefined && r[key] === currentRowObj[key]);
                if (index !== -1) break;
              }
            }
          }
        }

        // 2) If still not found, try the selected row index variable (for an external Remove button)
        if (index === -1) {
          // Make sure you have a page variable called "selectedRowIndex" that the table selection writes to.
          // You can create it under Page -> Variables -> new variable: name = selectedRowIndex, type = number
          // And bind the Table's selection/currentRow to that variable.
          const selIdx = $page && $page.variables && $page.variables.selectedRowIndex;
          if (typeof selIdx === 'number' && selIdx >= 0) {
            index = selIdx;
          }
        }

        // 3) final safety check
        if (index === -1 || index < 0 || index >= dp.data.length) {
          console.warn('Row to delete not found. index:', index, 'dp.length:', dp.data.length);
          return;
        }

        // remove row
        dp.data.splice(index, 1);

        // If you want to clear selectedRowIndex when deleting selected row:
        if ($page && $page.variables && $page.variables.selectedRowIndex !== undefined) {
          $page.variables.selectedRowIndex = -1;
        }

        dp.refresh();
        console.log('Row removed at index', index);
      } catch (err) {
        console.error('Error removing row', err);
      }

      return;
    }
  }

  return RemoveRowChain;
});
