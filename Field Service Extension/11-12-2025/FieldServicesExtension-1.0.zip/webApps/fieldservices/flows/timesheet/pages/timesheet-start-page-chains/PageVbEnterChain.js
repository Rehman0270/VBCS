define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

     const response = await Actions.callRest(context, {
     endpoint: 'Get_Time_SheetRecords/getTime_sheet_fs',
      });

 $variables.Get_All_Time_Sheet_Records_ADP.data = response.body.items;

      const uniqueEmployees = await $functions.uniqueEmployees(response.body.items);

      $variables.Employee_Name_LOV = uniqueEmployees.employee_name;
      $variables.Employee_N0_LOV = uniqueEmployees.employee_no;
  
    }
  }

  return PageVbEnterChain;
});
