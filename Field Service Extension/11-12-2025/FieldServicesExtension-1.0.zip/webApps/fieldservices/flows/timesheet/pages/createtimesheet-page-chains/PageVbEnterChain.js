define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils'
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      if (response1.body && response1.body.items) {
        $variables.Get_SR_RecordsAll_VAR_ADP.data = response1.body.items;
      }

      // 2️⃣ Second API Call
      // ⭐ CALL JS FUNCTION HERE ⭐
      const uniqueData = $functions.uniqueEmployees(response2.body.items);

      if (response2.body && response2.body.items) {
