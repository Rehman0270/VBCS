define([], () => {
  'use strict';

  class PageModule {
  }
 PageModule.prototype.uniqueEmployees = function (result) {
  let seen = {};
  let uniqueRows = [];

  if (Array.isArray(result)) {
    result.forEach(item => {
      // Only accept rows with a valid employee_name
      if (item.employee_name && item.employee_name.trim() !== "") {
        
        // Use employee_name + employee_no combination as key
        let key = item.employee_name + "_" + item.employee_no;

        if (!seen[key]) {
          uniqueRows.push(item);   // Push full object (all columns)
          seen[key] = true;
        }
      }
    });
  }

  return uniqueRows;  // <-- Return full rows for ADP
};

  
  return PageModule;
});
