define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

     // $variables.Create_TimeSheetEntry_Var.employee_name = $variables.EMPLOYEE_NAME_VAR;
     // $variables.Create_TimeSheetEntry_Var.employee_no = $variables.EMPNUM_VAR;
     //  $variables.Create_TimeSheetEntry_Var.timesheetdate=$variables.DATE_VAR;
     //   $variables.Create_TimeSheetEntry_Var.SR_No=$variables.SR_VAR;
     //   $variables.Create_TimeSheetEntry_Var.project

    }
  }

  return ButtonActionChain1;
});
