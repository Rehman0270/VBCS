define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain1 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const checkEmployeeFilters = await $functions.checkEmployeeFilters($variables.Employee_Name_Search_Var, $variables.Employee_No_Search_Va);

      const response = await Actions.callRest(context, {
        endpoint: 'Get_Time_SheetRecords/getTime_sheet_fs',
        uriParams: {
          q: checkEmployeeFilters,
          limit: '9000',
        },
      });

      $variables.Get_All_Time_Sheet_Records_ADP.data = response.body.items;

      await Actions.resetVariables(context, {
        variables: [
    '$variables.Employee_Name_Search_Var',
    '$variables.Employee_No_Search_Va',
  ],
      });
    }
  }

  return ButtonActionChain1;
});
