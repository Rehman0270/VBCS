define([], () => {
  'use strict';

  class PageModule {
  }

  PageModule.prototype.uniqueRequestNumbers = function (result) {
  let unique_request_no = {};
  let final_request_no = [];

  if (Array.isArray(result) && result.length > 0) {
    result.forEach(item => {
      if (item.request_no && !unique_request_no[item.request_no]) {
        final_request_no.push({ requestNumber: item.request_no });
        unique_request_no[item.request_no] = true;
      }
    });
  }

  return {
    request_number: final_request_no
  };
};
PageModule.prototype.checkRequestFilters = function (request_no, request_date) {

  // Clean values (empty strings become null)
  const cleanReqNo = request_no && request_no.trim() !== "" ? request_no : null;
  const cleanReqDate = request_date && request_date.trim() !== "" ? request_date : null;

  // If both are empty/null → return empty JSON
  if (cleanReqNo === null && cleanReqDate === null) {
    return '{}';
  }

  const params = [
    { key: 'request_no', value: cleanReqNo },
    { key: 'request_date', value: cleanReqDate }
  ];

  const queryObject = {};

  params.forEach(({ key, value }) => {
    if (value !== null) {
      queryObject[key] = value;
    }
  });

  return JSON.stringify(queryObject);
};

  return PageModule;
});
