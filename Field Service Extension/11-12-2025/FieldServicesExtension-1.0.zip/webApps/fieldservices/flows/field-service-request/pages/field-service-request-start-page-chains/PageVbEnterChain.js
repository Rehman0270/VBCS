define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'service_request_sc/getService_request_fs',
      });

      $variables.Get_SR_ALL_RECORDS_ADP_VAR.data = response.body.items;

      const uniqueRequestNumbers = await $functions.uniqueRequestNumbers(response.body.items);

      $variables.Request_Numbers_LOV = uniqueRequestNumbers.request_number;
    }
  }

  return PageVbEnterChain;
});
