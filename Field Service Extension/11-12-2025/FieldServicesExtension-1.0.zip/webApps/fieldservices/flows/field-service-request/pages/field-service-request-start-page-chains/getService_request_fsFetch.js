define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getService_request_fsFetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const checkStrings = await $functions.checkStrings($variables.var_request_no, $variables.var_request_date);

      if (checkStrings === 'null' || checkStrings == null) {

        const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: 'service_request_sc/getService_request_fs',
          responseType: 'getService_request_fs',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
        });
            return callRestEndpoint1;
      } else {
                const callRestEndpoint1 = await Actions.callRest(context, {
                  endpoint: 'service_request_sc/getService_request_fs',
                  responseType: 'getService_request_fs',
                  hookHandler: configuration.hookHandler,
                  requestType: 'json',
                  uriParams: {
                    q: checkStrings,
                  },
                });
            return callRestEndpoint1;
      }

  
    }
  }

  return getService_request_fsFetch;
});
