define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createPostServiceRequestFsChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // Sets the progress variable to true
      $variables.createPostServiceRequestFsChainInProgress = true;

      try {
        // Validates postService_request_fs form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'validation-group',
          },
        }, { id: 'validatePostServiceRequestFs' });

        if (!validateFormResult) {
          return;
        }

        const callRestResult = await Actions.callRest(context, {
          endpoint: 'CreateServiceRequestFS/postService_request_fs',
          body: $variables.postServiceRequestFs,
        }, { id: 'createPostServiceRequestFs' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = `Could not create new postService_request_fs: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Save failed',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        await Actions.fireNotificationEvent(context, {
          summary: 'postService_request_fs saved',
          message: 'postService_request_fs record successfully created',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        await Actions.navigateBack(context, {}, { id: 'navigateBack' });
      } finally {
        // Sets the progress variable to false
        $variables.createPostServiceRequestFsChainInProgress = false;
      }
    }
  }

  return createPostServiceRequestFsChain;
});
