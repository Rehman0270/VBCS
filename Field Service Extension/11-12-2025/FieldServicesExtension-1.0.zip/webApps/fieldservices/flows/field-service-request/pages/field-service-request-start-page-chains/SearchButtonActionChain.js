define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SearchButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const checkRequestFilters = await $functions.checkRequestFilters($variables.var_request_no, $variables.var_request_date);

      const response = await Actions.callRest(context, {
        endpoint: 'service_request_sc/getService_request_fs',
        uriParams: {
          q: checkRequestFilters,
        },
      });

      $variables.Get_SR_ALL_RECORDS_ADP_VAR.data = response.body.items;

      await Actions.resetVariables(context, {
        variables: [
    '$variables.var_request_no',
    '$variables.var_request_date',
  ],
      });
    }
  }

  return SearchButtonActionChain;
});
