define([], () => {
  'use strict';

  class PageModule {

    addofficeline(context) {
      const lines = context.$page.variables.Var_office;

      if (!Array.isArray(lines)) {
        console.error("var_floor is not an array");
        return;
      }

      const newRow = {
      
 lnum:null,
      service_type: null,
      service_discription: null,
      technician_id: null,
      customer: null,
      amount:null ,
    project: null,
      status: "OPEN",
      timespent: null,
      supplier_inv_no: null,
      customer_inv_no: null,
      supplier_inv_status: null,
      customer_inv_status: null
        
      };

      lines.push(newRow);
    }
    deleteLineoffice(context, index) {
      const lines = context.$page.variables.Var_office;

      if (!Array.isArray(lines) || index < 0 || index >= lines.length) {
        console.error("Invalid index or Var_LineEntries is not an array");
        return;
      }

      lines.splice(index, 1);
      context.$page.variables.Var_office = [...lines];

      lines.forEach((line, i) => {
        line.propertyDetailId = i + 1;
      });
    }
  }
  
  return PageModule;
});
