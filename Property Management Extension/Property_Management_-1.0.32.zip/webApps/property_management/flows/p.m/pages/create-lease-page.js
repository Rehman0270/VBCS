define([], function() {
  'use strict';

  class PageModule {
     addLineRevenue(context) {
      const lines = context.$page.variables.Var_LineEntries;

      if (!Array.isArray(lines)) {
      //  console.error("Var_LineEntries is not an array");
        return;
      }

      const newRow = {
        line_number: lines.length + 1,
        location_type: "",
        location_code: "",
        usage_type: "",
        primary_checkbox: "",
        estimated_occupancy_date: "",
        rent_start_date: "",
        rent_end_date: "",
        fee_element_type: "",
        fee_element: "",
        fee: "",
        tax_classifiaction_code: "",
        fee_basis: "",
        billing_cycle: "",
        payment_term: "",
        contract_number:"",
        lseq_num:""
      };

      lines.push(newRow);
    }

    deleteLineRevenue(context, index) {
      const lines = context.$page.variables.Var_LineEntries;

      if (!Array.isArray(lines) || index < 0 || index >= lines.length) {
      //  console.error("Invalid index or Var_LineEntries is not an array");
        return;
      }

      lines.splice(index, 1);
      context.$page.variables.Var_LineEntries = [...lines];

      lines.forEach((line, i) => {
        line.line_number = i + 1;
      });
    }

    addLineExpense(context) {
      const lines = context.$page.variables.Var_LineEntries;

      if (!Array.isArray(lines)) {
      //  console.error("Var_LineEntries is not an array");
        return;
      }

      const newRow = {
        location_type: "",
        location_code: "",
        usage_type: "",
        primary_checkbox: "",
        estimated_occupancy_date: "",
        rent_start_date: "",
        rent_end_date: "",
        fee_element_type: "",
        fee_element: "",
        fee: "",
        tax_classifiaction_code: "",
        fee_basis: "",
        billing_cycle: "",
        payment_term: "",
        contract_number:"",
        lseq_num:""
      };

      lines.push(newRow);
    }

    deleteLineExpense(context, index) {
      const lines = context.$page.variables.Var_LineEntries;

      if (!Array.isArray(lines) || index < 0 || index >= lines.length) {
      //  console.error("Invalid index or Var_LineEntries is not an array");
        return;
      }

      lines.splice(index, 1);
      context.$page.variables.Var_LineEntries = [...lines];

      lines.forEach((line, i) => {
        line.line_number = i + 1;
      });
    }

    getUnique(arrayData, field) {
      if (!Array.isArray(arrayData) || typeof field !== 'string') return [];

      const seen = new Set();
      const result = [];

      arrayData.forEach(item => {
        const value = item[field];
        if (value !== undefined && !seen.has(value)) {
          seen.add(value);
          result.push({ [field]: value });  // key is dynamically set to field name
        }
      });

      return result;
    }

    generatecontract_number(prefix = 'CON') {
      const now = new Date();

      const year = now.getFullYear(); // e.g., 2025
      const month = ('0' + (now.getMonth() + 1)).slice(-2); // ensures 2 digits
      const day = ('0' + now.getDate()).slice(-2); // ensures 2 digits

      const randomPart = Math.floor(1000 + Math.random() * 9000); // 4-digit random number

      return prefix + '-' + year + month + day + '-' + randomPart;
    }

    getCurrentISODate() {
      return new Date().toISOString();
    }

    convertToISO(dateString) {
      const date = new Date(dateString);
      return isNaN(date) ? null : date.toISOString();
    }

  }

  return PageModule;
});