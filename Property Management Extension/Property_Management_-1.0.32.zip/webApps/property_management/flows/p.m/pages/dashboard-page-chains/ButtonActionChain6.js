define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain6 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show
      $variables.v_expence_btn_disable = true;

      $variables.v_generate_expence_name = 'Integration in progress. Please wait...';

      const response = await Actions.callRest(context, {
        endpoint: 'oICpostApAr/postIcApiIntegrationV1FlowsRestPM_LEASECONTRACTUPLRMN1_0LeaseContract',
        body: {
          Type: 'EXPENCE',
        },
        responseType: 'any',
      });

      await Actions.fireNotificationEvent(context, {
        summary: JSON.stringify(response.body),
        type: 'confirmation',
      });

      $variables.v_expence_btn_disable = false;
 document.getElementById("loadingSpinner").style.display = 'none'; // Hide
      $variables.v_generate_expence_name = 'Generate Expence';
    }
  }

  return ButtonActionChain6;
});
 