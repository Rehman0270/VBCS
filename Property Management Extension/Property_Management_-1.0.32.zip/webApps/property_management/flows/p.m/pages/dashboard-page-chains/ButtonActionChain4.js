define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain4 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show
      const toMainManage = await Actions.navigateToPage(context, {
        page: 'manage-lease',
      });
       document.getElementById("loadingSpinner").style.display = 'none'; // Hide
    }
  }

  return ButtonActionChain4;
});
