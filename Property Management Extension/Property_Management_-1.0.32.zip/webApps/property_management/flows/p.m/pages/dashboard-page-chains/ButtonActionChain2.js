define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain2 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show
      const toPropertyPage = await Actions.navigateToPage(context, {
        page: 'create-property',

         
      });
       document.getElementById("loadingSpinner").style.display = 'none'; // Hide
    }
  }

  return ButtonActionChain2;
});
