define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain5 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show
      const toMainStart = await Actions.navigateToPage(context, {
        page: 'create-lease',
      });

      $flow.variables.ManageLeaseFlag = 'N';
       document.getElementById("loadingSpinner").style.display = 'none'; // Hide
    }
  }

  return ButtonActionChain5;
});
