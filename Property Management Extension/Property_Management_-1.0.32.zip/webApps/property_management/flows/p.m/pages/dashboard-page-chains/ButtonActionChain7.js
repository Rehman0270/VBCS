define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain7 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.v_generate_rev_name = 'Integration in progress. Please wait...';
document.getElementById("loadingSpinner").style.display = 'flex'; // Show
      $variables.v_revenue_btn_disable = true;

      const response = await Actions.callRest(context, {
        endpoint: 'oICpostApAr/postIcApiIntegrationV1FlowsRestPM_LEASECONTRACTUPLRMN1_0LeaseContract',
        body: {
          Type: 'REVENUE',
        },
        responseBodyFormat: 'json',
        responseType: 'any',
      });

      await Actions.fireNotificationEvent(context, {
        summary: JSON.stringify(response.body),
        type: 'confirmation',
      });

      $variables.v_revenue_btn_disable = false;
 document.getElementById("loadingSpinner").style.display = 'none'; // Hide
      $variables.v_generate_rev_name = 'Generate Revenue';
    }
  }

  return ButtonActionChain7;
});
 