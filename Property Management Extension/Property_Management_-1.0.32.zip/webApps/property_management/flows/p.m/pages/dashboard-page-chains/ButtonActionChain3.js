define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain3 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show
      const toPropManage = await Actions.navigateToPage(context, {
        page: 'manage-property',
      });
       document.getElementById("loadingSpinner").style.display = 'none'; // Hide
    }
  }

  return ButtonActionChain3;
});
