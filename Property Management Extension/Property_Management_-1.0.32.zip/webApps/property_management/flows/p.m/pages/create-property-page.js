define([], () => {
  'use strict';

  class PageModule {
    addLineRevenue(context) {
      const lines = context.$page.variables.Var_floor;

      if (!Array.isArray(lines)) {
        console.error("var_floor is not an array");
        return;
      }

      const newRow = {
      
        floor: "",
        alias: "",
        locationCode: "",
        rentable: 0,
        common: 0 ,
        fromDate: "",
        toDate: "",
        occupancy: "",
        employeeAssignable: "",
        costCenterAssignable: "",
        customerAssignable: "",
        propertyCode:0
        
      };

      lines.push(newRow);
    }

    deleteLineRevenue(context, index) {
      const lines = context.$page.variables.Var_floor;

      if (!Array.isArray(lines) || index < 0 || index >= lines.length) {
        console.error("Invalid index or Var_floor is not an array");
        return;
      }

      lines.splice(index, 1);
      context.$page.variables.Var_floor = [...lines];

      lines.forEach((line, i) => {
        line.propertyLineId = i + 1;
      });
    }

     deleteLineExpense(context, index) {
      const lines = context.$page.variables.Var_floor;

      if (!Array.isArray(lines) || index < 0 || index >= lines.length) {
        console.error("Invalid index or Var_LineEntries is not an array");
        return;
      }

      lines.splice(index, 1);
      context.$page.variables.Var_floor = [...lines];

      lines.forEach((line, i) => {
        line.propertyLineId = i + 1;
      });
    }

    addofficeline(context) {
      const lines = context.$page.variables.Var_office;

      if (!Array.isArray(lines)) {
        console.error("var_floor is not an array");
        return;
      }

      const newRow = {
      
        office: "",
        alias: "",
        locationCode: "",
        rentable: 0,
        fromDate: "",
        toDate: "",
        occupancy: "",
        assignable: 0,
        propertyCode: 0
        
      };

      lines.push(newRow);
    }
    deleteLineoffice(context, index) {
      const lines = context.$page.variables.Var_office;

      if (!Array.isArray(lines) || index < 0 || index >= lines.length) {
        console.error("Invalid index or Var_LineEntries is not an array");
        return;
      }

      lines.splice(index, 1);
      context.$page.variables.Var_office = [...lines];

      lines.forEach((line, i) => {
        line.propertyDetailId = i + 1;
      });
    }
    getCurrentISODate() {
      return new Date().toISOString();
    }

    convertToISO(dateString) {
      const date = new Date(dateString);
      return isNaN(date) ? null : date.toISOString();
    }

  }
  return PageModule;
});
