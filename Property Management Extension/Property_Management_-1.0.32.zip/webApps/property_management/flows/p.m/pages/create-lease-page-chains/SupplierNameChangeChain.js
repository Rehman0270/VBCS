define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SupplierNameChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;


      if ($flow.variables.propertyManagementHeadersORDS.fusion_flag !== 'Y') {
        if ($flow.variables.propertyManagementHeadersORDS.lease_class === 'Expense' && $flow.variables.propertyManagementHeadersORDS.name !== null) {
  
          const response = await Actions.callRest(context, {
            endpoint: 'SuppliersLOV/getFscmRestApiResources11_13_18_05SuppliersLOV',
            responseType: 'SupplierLOVType',
            uriParams: {
              q: 'SupplierName='+$flow.variables.propertyManagementHeadersORDS.name,
            },
          });
  
          if (response.body.items[0].SupplierNumber !== null) {
  
           $flow.variables.propertyManagementHeadersORDS.customer_number = Number(response.body.items[0].SupplierNumber);
            $variables.temp_supplier_id = response.body.items[0].SupplierId;
          }
          
        } else if ($flow.variables.propertyManagementHeadersORDS.lease_class === 'Revenue' && $flow.variables.propertyManagementHeadersORDS.name !== null) {
        
          const response = await Actions.callRest(context, {
            endpoint: 'CustomerLOV/getFscmRestApiResources11_13_18_05ShippingCustomersLOV',
            responseType: 'getFscmRestApiResources11_13_18_05ShippingCustomersLOV',
             uriParams: {
              q: 'Customer='+$flow.variables.propertyManagementHeadersORDS.name,
            },
          });
        
          if (response.body.items[0].CustomerNumber !== null) {
  
           $flow.variables.propertyManagementHeadersORDS.customer_number = Number(response.body.items[0].CustomerNumber);
         $variables.temp_supplier_id = null;
          }
        }
      }
    }
  }

  return SupplierNameChangeChain;
});
