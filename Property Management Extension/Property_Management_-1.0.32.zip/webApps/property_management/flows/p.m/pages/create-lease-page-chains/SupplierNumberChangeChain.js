define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SupplierNumberChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      if ($flow.variables.propertyManagementHeadersORDS.fusion_flag !== 'Y') {
         if ( $flow.variables.propertyManagementHeadersORDS.lease_class === 'Expense' && $flow.variables.propertyManagementHeadersORDS.customer_number !== null) {
            const response = await Actions.callRest(context, {
              endpoint: 'SuppliersLOV/getFscmRestApiResources11_13_18_05SuppliersLOV',
              responseType: 'SupplierLOVType',
              uriParams: {
                q: 'SupplierNumber='+$flow.variables.propertyManagementHeadersORDS.customer_number,
              },
            });
  
   if (response.body.items[0].SupplierName !== null) {
  
          $flow.variables.propertyManagementHeadersORDS.name = response.body.items[0].SupplierName;
                $variables.temp_supplier_id = response.body.items[0].SupplierId;
   }
        } else if ( $flow.variables.propertyManagementHeadersORDS.lease_class === 'Revenue' && $flow.variables.propertyManagementHeadersORDS.customer_number !== null) {
        
          const response = await Actions.callRest(context, {
            endpoint: 'CustomerLOV/getFscmRestApiResources11_13_18_05ShippingCustomersLOV',
            responseType: 'getFscmRestApiResources11_13_18_05ShippingCustomersLOV',
            uriParams: {
              q: 'CustomerNumber='+$flow.variables.propertyManagementHeadersORDS.customer_number,
            },
          });
        
       if (response.body.items[0].Customer !== null) {  
  
          $flow.variables.propertyManagementHeadersORDS.name = response.body.items[0].Customer;
           $variables.temp_supplier_id = null;
        }}
      }
    }
  }

  return SupplierNumberChangeChain;
});
