define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Contractnumber_PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_PropertyManagementHe',
        uriParams: {
          fields: 'contractNumber',
          limit: '1',
          onlyData: true,
          orderBy: 'contractNumber:desc',
        },
      });

      if (response.body.count >= 1) {

        $variables.temp_contract_number = response.body.items[0].contractNumber;

        $variables.temp_contract_number_plus_one = Number(response.body.items[0].contractNumber) + 1;
      } else {
      
        $variables.temp_contract_number = 1000000;
      
        $variables.temp_contract_number_plus_one = $variables.temp_contract_number + 1;
      }
    }
  }

  return Contractnumber_PageVbEnterChain;
});
