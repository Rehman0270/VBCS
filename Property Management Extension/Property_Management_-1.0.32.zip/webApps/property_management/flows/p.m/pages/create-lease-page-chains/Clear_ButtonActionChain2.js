define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Clear_ButtonActionChain2 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.PROPERTY_MANAGEMENT_HEAD',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.propertyType_var',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.Var_LineEntries',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.current_he',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.Var_LineEntries',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.propertyManagementHeadersORDS',
  ],
      });

      $flow.variables.ManageLeaseFlag = 'N';
    }
  }

  return Clear_ButtonActionChain2;
});
