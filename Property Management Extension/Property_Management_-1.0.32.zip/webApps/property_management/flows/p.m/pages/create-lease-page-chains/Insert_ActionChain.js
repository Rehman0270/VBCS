define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';
 
  class Insert_ActionChain extends ActionChain {
 
    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $current } = context;
       if ($flow.variables.ManageLeaseFlag === 'N' || $flow.variables.ManageLeaseFlag === null) {

        $flow.variables.propertyManagementHeadersORDS.contract_number = $variables.temp_contract_number_plus_one/*$page.functions.generateContractNumber()*/ ;
        $flow.variables.propertyManagementHeadersORDS.rent_fee_period = $page.functions.convertToISO($flow.variables.propertyManagementHeadersORDS.rent_fee_period);
        $flow.variables.propertyManagementHeadersORDS.termination_date = $page.functions.convertToISO($flow.variables.propertyManagementHeadersORDS.termination_date);
        $flow.variables.propertyManagementHeadersORDS.commencement_date = $page.functions.convertToISO($flow.variables.propertyManagementHeadersORDS.commencement_date);
        $flow.variables.propertyManagementHeadersORDS.creation_date =  $page.functions.getCurrentISODate();
    
        const response2 = await Actions.callRest(context, {
          endpoint: 'CreateLeaseHeader/postProperty_management_headers',
          body: $flow.variables.propertyManagementHeadersORDS,
        });

if (response2.ok){
        await Actions.fireNotificationEvent(context, {
          summary: 'Header insert Success',
          type: 'confirmation',
        });
      $flow.variables.propertyManagementHeadersORDS.hseq_num = response2.body.hseq_num;  
 
    const results = await ActionUtils.forEach($flow.variables.Var_LineEntries, async (item, index) => {
      $flow.variables.Var_LineEntries[index].contract_number = $flow.variables.propertyManagementHeadersORDS.contract_number;

      $flow.variables.Var_LineEntries[index].hseq_num = $flow.variables.propertyManagementHeadersORDS.hseq_num ;
      $flow.variables.Var_LineEntries[index].estimated_occupancy_date = $page.functions.convertToISO($flow.variables.Var_LineEntries[index].estimated_occupancy_date);
      $flow.variables.Var_LineEntries[index].rent_start_date = $page.functions.convertToISO($flow.variables.Var_LineEntries[index].rent_start_date);
      $flow.variables.Var_LineEntries[index].rent_end_date = $page.functions.convertToISO($flow.variables.Var_LineEntries[index].rent_end_date);

            const result = await Actions.callRest(context, {
              endpoint: 'CreateLeaseLines/postProperty_management_lines',
                body: $flow.variables.Var_LineEntries[index],
            });

            $flow.variables.Var_LineEntries[index] = result.body;
            delete $flow.variables.Var_LineEntries[index].links;
 
    
    }, { mode: 'serial' });

          $flow.variables.ManageLeaseFlag = 'Y';

      $variables.Property_manage_LINE.contract_number = $flow.variables.propertyManagementHeadersORDS.contract_number;
        }
        else {
           await Actions.fireNotificationEvent(context, {
          summary: 'Error while saving'
         });}
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error while saving',
        });
      
    
    }
    }
  }
 
  return Insert_ActionChain;
});