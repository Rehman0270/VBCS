define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class DeleteLineActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.Indx 
     */
    async run(context, { Indx }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show
      await Actions.fireNotificationEvent(context, {
        summary: 'Test',
        message: 'Record Has Been Deleted',
        type: 'confirmation',
        displayMode: 'transient',
      });
      await $flow.functions.deleteLineExpensee(context, Indx);
 document.getElementById("loadingSpinner").style.display = 'none'; // Hide
    }
  }

  return DeleteLineActionChain;
});
