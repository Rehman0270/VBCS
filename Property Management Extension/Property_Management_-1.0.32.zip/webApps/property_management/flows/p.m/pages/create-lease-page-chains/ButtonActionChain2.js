define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain2 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const saveCloseDialogBoxClose = await Actions.callComponentMethod(context, {
        selector: '#save_close_dialog_box',
        method: 'close',
      });
    }
  }

  return ButtonActionChain2;
});
