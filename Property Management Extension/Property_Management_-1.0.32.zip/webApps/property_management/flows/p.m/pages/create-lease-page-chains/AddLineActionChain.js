define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class AddLineActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show
      await $flow.functions.addLineExpense(context);
       document.getElementById("loadingSpinner").style.display = 'none'; // Hide
    }
  }

  return AddLineActionChain;
});
