define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getFscmRestApiResources11_13_18_05SuppliersLOVFetch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const callRestEndpoint1 = await Actions.callRest(context, {
        endpoint: 'SuppliersLOV/getFscmRestApiResources11_13_18_05SuppliersLOV',
        uriParams: {
          q: "SupplierName LIKE '%" + ($flow.variables.propertyManagementHeadersORDS.name ? $flow.variables.propertyManagementHeadersORDS.name : "") + "%'",
        },
        responseType: 'getFscmRestApiResources1113185SuppliersLOVResponse',
        hookHandler: configuration.hookHandler,
        requestType: 'json',
      });

      return callRestEndpoint1;
    }
  }

  return getFscmRestApiResources11_13_18_05SuppliersLOVFetch;
});
