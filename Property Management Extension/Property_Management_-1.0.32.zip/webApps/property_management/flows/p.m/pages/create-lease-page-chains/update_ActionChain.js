define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';
 
  class update_ActionChain extends ActionChain {
 
    /**
     * @par
     * am {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
             if ($flow.variables.ManageLeaseFlag === 'Y') {

        if ($flow.variables.propertyManagementHeadersORDS.hseq_num !== null) {
 $flow.variables.propertyManagementHeadersORDS.rent_fee_period = $page.functions.convertToISO($flow.variables.propertyManagementHeadersORDS.rent_fee_period);
        $flow.variables.propertyManagementHeadersORDS.termination_date = $page.functions.convertToISO($flow.variables.propertyManagementHeadersORDS.termination_date);
        $flow.variables.propertyManagementHeadersORDS.commencement_date = $page.functions.convertToISO($flow.variables.propertyManagementHeadersORDS.commencement_date);

          const response = await Actions.callRest(context, {
            endpoint: 'UpdateLeaseHeader/putProperty_management_headersHseq_no',
            uriParams: {
              'Hseq_no': $flow.variables.propertyManagementHeadersORDS.hseq_num,
            },
            body: $flow.variables.propertyManagementHeadersORDS,
          });
 
          if (response.ok === true) {
 
            await Actions.fireNotificationEvent(context, {
              summary: 'header updated',
              type: 'confirmation',
            });
          }
        }
        const results = await ActionUtils.forEach($flow.variables.Var_LineEntries, async (item, index) => {

      $flow.variables.Var_LineEntries[index].estimated_occupancy_date = $page.functions.convertToISO($flow.variables.Var_LineEntries[index].estimated_occupancy_date);
      $flow.variables.Var_LineEntries[index].rent_start_date = $page.functions.convertToISO($flow.variables.Var_LineEntries[index].rent_start_date);
      $flow.variables.Var_LineEntries[index].rent_end_date = $page.functions.convertToISO($flow.variables.Var_LineEntries[index].rent_end_date);
 $flow.variables.Var_LineEntries[index].contract_number =  $flow.variables.propertyManagementHeadersORDS.contract_number;

      $flow.variables.Var_LineEntries[index].hseq_num =  $flow.variables.propertyManagementHeadersORDS.hseq_num ;

         if ($flow.variables.Var_LineEntries[index].lseq_num === null) {

      $flow.variables.Var_LineEntries[index].contract_number = $flow.variables.propertyManagementHeadersORDS.contract_number;

      $flow.variables.Var_LineEntries[index].hseq_num = $flow.variables.propertyManagementHeadersORDS.hseq_num ;
      $flow.variables.Var_LineEntries[index].estimated_occupancy_date = $page.functions.convertToISO($flow.variables.Var_LineEntries[index].estimated_occupancy_date);
      $flow.variables.Var_LineEntries[index].rent_start_date = $page.functions.convertToISO($flow.variables.Var_LineEntries[index].rent_start_date);
      $flow.variables.Var_LineEntries[index].rent_end_date = $page.functions.convertToISO($flow.variables.Var_LineEntries[index].rent_end_date);

            const result = await Actions.callRest(context, {
              endpoint: 'CreateLeaseLines/postProperty_management_lines',
                body: $flow.variables.Var_LineEntries[index],
            });
             $flow.variables.Var_LineEntries[index] = result.body;
            delete $flow.variables.Var_LineEntries[index].links;
          } else  if ($flow.variables.Var_LineEntries[index].lseq_num !== undefined) {

            const response3 = await Actions.callRest(context, {
              endpoint: 'UpdateLeaseLines/putProperty_management_linesLseq_no',
              uriParams: {
                'lseq_no':  $flow.variables.Var_LineEntries[index].lseq_num,
              },
             body: $flow.variables.Var_LineEntries[index],
            });
          }  
        }, { mode: 'serial' });
      } else {
         await Actions.fireNotificationEvent(context, {
            summary: 'error while updatingi',
          });
      }
    }
  }
 
  return update_ActionChain;
});
 