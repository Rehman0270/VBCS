define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SaveButtonActionChain extends ActionChain {

    /**
     * IN USE IMP
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $flow.variables.Lease_save_btn_disable = true;
      $flow.variables.Lease_save_btn_Label = 'Saving';
document.getElementById("loadingSpinner").style.display = 'flex'; // Show
      if ($flow.variables.ManageLeaseFlag === 'N' || $flow.variables.ManageLeaseFlag === null) {
        await Actions.callChain(context, {
          chain: 'Insert_ActionChain',
        });
      } else if ($flow.variables.ManageLeaseFlag === 'Y') {
        await Actions.callChain(context, {
          chain: 'update_ActionChain',
        });
      }
       else  {
        await Actions.fireNotificationEvent(context, {
          type: 'error',
          summary: 'Error while saving',
        });
      }

      $flow.variables.Lease_save_btn_disable = false;
      $flow.variables.Lease_save_btn_Label = 'Save';
      document.getElementById("loadingSpinner").style.display = 'none'; // Hide
    }
  }

  return SaveButtonActionChain;
});
