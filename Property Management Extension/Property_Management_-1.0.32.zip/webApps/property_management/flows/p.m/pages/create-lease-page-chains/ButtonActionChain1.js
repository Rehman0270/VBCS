define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain1 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show

      await Actions.callChain(context, {
        chain: 'Clear_ButtonActionChain2',
      });

      await Actions.navigateBack(context, {
      });
       document.getElementById("loadingSpinner").style.display = 'none'; // Hide
    }
  }

  return ButtonActionChain1;
});
