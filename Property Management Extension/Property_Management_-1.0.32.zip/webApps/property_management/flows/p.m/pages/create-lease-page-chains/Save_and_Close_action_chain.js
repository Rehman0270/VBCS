define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Save_and_Close_action_chain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.callChain(context, {
        chain: 'SaveButtonActionChain',
      });

      await Actions.callChain(context, {
        chain: 'Clear_ButtonActionChain2',
      });

      const toMainDashboard = await Actions.navigateToPage(context, {
        page: 'dashboard',
      });
    }
  }

  return Save_and_Close_action_chain;
});
