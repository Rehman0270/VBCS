define([], () => {
  'use strict';

  class PageModule {
    calculatelineAmount(lines) {
 
      let totalAmount = 0;
      let totalTaxAmount = 0;

      let taxRate = null;
        lines.fee = Number(lines.fee);
 
        // Determine tax rate based on taxClassificationCode
        switch (lines.tax_classifiaction_code) {
          case 'FORD_TAX_RATE_12':
            taxRate = 12;
            break;
          case 'FORD_TAX_RATE_15':
            taxRate = 15;
            break;
        }
 
        // Calculate tax amount
        const taxAmount = Number((lines.fee * (taxRate / 100)).toFixed(2));
 
        lines.taxRate = taxRate;
        lines.taxAmount = taxAmount;
 
        totalAmount += Number((lines.fee + taxAmount).toFixed(2));
        totalTaxAmount += Number(taxAmount.toFixed(2));
 
      return {totalAmount, totalTaxAmount};
    }
    calculateInvoiceAmount(lines) {
 
      let totalAmount = 0;
      let totalTaxAmount = 0;
 
      lines.forEach(line => {
        let taxRate = null;
        line.LineAmount = Number(line.LineAmount);
 
        // Determine tax rate based on taxClassificationCode
        switch (line.TaxClassification) {
          case 'FORD_TAX_RATE_12':
            taxRate = 12;
            break;
          case 'FORD_TAX_RATE_15':
            taxRate = 15;
            break;
        }
 
        // Calculate tax amount
        const taxAmount = Number((line.LineAmount * (taxRate / 100)).toFixed(2));
 
        line.taxRate = taxRate;
        line.taxAmount = taxAmount;
 
        totalAmount += Number((line.LineAmount + taxAmount).toFixed(2));
        totalTaxAmount += Number(taxAmount.toFixed(2));
      });
 
      return {totalAmount, totalTaxAmount};
    }
  }
  PageModule.prototype.checkStrings = function(param1, param2, param3, param4, param5,param6) {
    const queryParts = [];
    const queryStrings = {
        contractNumber1: 'contractNumber=',
        contractType1: 'contractType=',
        leaseClass1: 'leaseClass=',
        customerNumber1: 'customerNumber=',
        name1: 'name=',
        site1: 'site=',

    };

    // Array to hold the params and their corresponding query string keys
    const params = [
        { param: param1, queryKey: queryStrings. contractNumber1},
        { param: param2, queryKey: queryStrings. contractType1 },
        { param: param3, queryKey: queryStrings.leaseClass1},
        { param: param4, queryKey: queryStrings.customerNumber1 },
        { param: param5, queryKey: queryStrings.name1},
        { param: param6, queryKey: queryStrings.site1}
    ];

    // Loop through each parameter and add the query part if it's not null or undefined
    params.forEach(({ param, queryKey }, index) => {
        if (param !== null && param !== undefined) {  // Check for null or undefined
            const condition = `${queryKey}'${param}'`;
            // If it's not the first query part, add ' AND '
            if (queryParts.length > 0) {
                queryParts.push(' AND ');
            }
            queryParts.push(condition);
        }
    });

    // Handling the special condition for param5 
   

    // If no valid parameters are provided, return null
    if (queryParts.length === 0) {
        return null;
    }

    // Join the query parts and return the final query string
    return queryParts.join(' ');


    
};

  return PageModule;
});
