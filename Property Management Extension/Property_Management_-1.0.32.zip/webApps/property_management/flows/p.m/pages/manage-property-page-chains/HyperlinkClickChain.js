define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class HyperlinkClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show
      const results3 = await Promise.all([
        async () => {

          const response = await Actions.callRest(context, {
            endpoint: 'businessObjects/getall_PropertyHeader',
            uriParams: {
              onlyData: true,
              limit: '1',
              q: "propertyHeaderId=" + current.row.propertyHeaderId,
            },
          });

          $flow.variables.current_property_header = response.body.items[0];

          $flow.variables.create_property.businessUnit = response.body.items[0].businessUnit;
          $flow.variables.create_property.address = response.body.items[0].address;
          $flow.variables.create_property.country = response.body.items[0].country;
          $flow.variables.create_property.propertyCode = response.body.items[0].propertyCode;
          $flow.variables.create_property.propertyName = response.body.items[0].propertyName;
          $flow.variables.create_property.region = response.body.items[0].region;
          $flow.variables.create_property.zone = response.body.items[0].zone;
          $flow.variables.create_property.fromDate = response.body.items[0].fromDate;
          $flow.variables.create_property.toDate = response.body.items[0].toDate;
          $flow.variables.create_property.uom = response.body.items[0].uom;
          $flow.variables.create_property.propertyType = response.body.items[0].propertyType;
          $flow.variables.create_property.tenure = response.body.items[0].tenure;
          $flow.variables.create_property.rentable = response.body.items[0].rentable;
          $flow.variables.create_property.class = response.body.items[0].class;
$flow.variables.create_property.status = response.body.items[0].status;
          $flow.variables.header_id = response.body.items[0].propertyHeaderId;
        },
        async () => {

          const response2 = await Actions.callRest(context, {
            endpoint: 'businessObjects/getall_PropertyLines',
            uriParams: {
              q: "propertyHeaderId=" + current.row.propertyHeaderId,
              onlyData: true,
            },
          });

          const results = await ActionUtils.forEach(response2.body.items, async (item, inde) => {

            $flow.variables.Var_floor[inde] = response2.body.items[inde];
          }, { mode: 'serial' });
        },
        async () => {
           const response3 = await Actions.callRest(context, {
             endpoint: 'businessObjects/getall_PropertyDetails',
             uriParams: {
               q: "propertyHeaderId=" + current.row.propertyHeaderId,
               onlyData: true,
             },
           });

          const results2 = await ActionUtils.forEach(response3.body.items, async (item, ind) => {

            $flow.variables.Var_office[ind] = response3.body.items[ind];
          }, { mode: 'serial' });
        },
      ].map(sequence => sequence()));

      const toPropertyPage = await Actions.navigateToPage(context, {
        page: 'create-property',
      });
 document.getElementById("loadingSpinner").style.display = 'none'; // Hide
      $flow.variables.ManagePropertyFlag = 'Y';
    }
  }

  return HyperlinkClickChain;
});
