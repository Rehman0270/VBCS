define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SearchButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show
      const checkStrings = await $functions.checkStrings($variables.property_name_var, $variables.Business_unit_var, $variables.country_name_var, $variables.property_code_var);

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_PropertyHeader',
        uriParams: {
          onlyData: true,
          q: checkStrings,
          orderBy: 'creationDate:desc',
        },
      });

      $variables.Prop_Adp.data = response.body.items;
       document.getElementById("loadingSpinner").style.display = 'none'; // Hide
    }
    
  }

  return SearchButtonActionChain;
});
