define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ClearButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.Business_unit_var',
    '$page.variables.country_name_var',
    '$page.variables.Prop_Adp',
  ],
      });

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.property_code_var',
    '$page.variables.property_name_var',
  ],
      });
    }
  }

  return ClearButtonActionChain;
});
