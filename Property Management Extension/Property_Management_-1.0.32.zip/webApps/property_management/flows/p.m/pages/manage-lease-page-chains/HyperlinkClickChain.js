define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class HyperlinkClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show


   

      const response = await Actions.callRest(context, {
        endpoint: 'GetLeaseHeader/getProperty_management_headers',
      uriParams: {
          onlyData: 'true',
          q: '{"contract_number":"' + $variables.Property_Header_Adp.data[index].contractNumber + '"}'
        },
      });

      const response2 = await Actions.callRest(context, {
        endpoint: 'GETLeaseLines/getProperty_management_lines',
        uriParams: {
          onlyData: 'true',
          q: '{"contract_number":"' + $variables.Property_Header_Adp.data[index].contractNumber + '"}'

        },
      });

      const results = await ActionUtils.forEach(response2.body.items, async (item, inde) => {

      

        $flow.variables.Var_LineEntries[inde] = response2.body.items[inde];
     
          


       
      }, { mode: 'serial' });
      // Get the array
let entries = $flow.variables.Var_LineEntries;

// Ensure it's not null or empty
if (entries && entries.length > 0) {
  // Sort by lseq_num ascending
  entries.sort((a, b) => a.line_number - b.line_number);

  // If you want descending:
  // entries.sort((a, b) => b.line_number - a.line_number);

  // Save the sorted array back
  $flow.variables.Var_LineEntries = entries;
}


      $flow.variables.propertyManagementHeadersORDS.commencement_date = response.body.items[0].commencement_date;
      $flow.variables.propertyManagementHeadersORDS.contract_number = response.body.items[0].contract_number;
      $flow.variables.propertyManagementHeadersORDS.contract_type = response.body.items[0].contract_type;
$flow.variables.propertyManagementHeadersORDS.customer_number = response.body.items[0].customer_number;
      $flow.variables.propertyManagementHeadersORDS.lease_class = response.body.items[0].lease_class;
      $flow.variables.propertyManagementHeadersORDS.name = response.body.items[0].name;
$flow.variables.propertyManagementHeadersORDS.hseq_num = response.body.items[0].hseq_num;
      $flow.variables.propertyManagementHeadersORDS.rent_fee_period = response.body.items[0].rent_fee_period;
      $flow.variables.propertyManagementHeadersORDS.site = response.body.items[0].site;
      $flow.variables.propertyManagementHeadersORDS.fusion_flag = response.body.items[0].fusion_flag;

      $flow.variables.propertyManagementHeadersORDS.termination_date = response.body.items[0].termination_date;

      $flow.variables.current_he = response.body.items[0];
      $flow.variables.ManageLeaseFlag = 'Y';
 document.getElementById("loadingSpinner").style.display = 'none'; // Hide
      const toMainStart = await Actions.navigateToPage(context, {
        page: 'create-lease',
      });
    }
  }

  return HyperlinkClickChain;
});
