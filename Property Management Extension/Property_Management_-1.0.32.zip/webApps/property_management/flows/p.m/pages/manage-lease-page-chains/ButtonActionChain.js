define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show
      const checkStrings = await $functions.checkStrings($variables.contract_number_input, $variables.contract_type_input, $variables.Lease_class_input, $variables.customer_number_input, $variables.customer_name_input, $variables.site_input);

      const response = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_PropertyManagementHe',
        uriParams: {
          q: checkStrings,
          onlyData: true,
          limit: 499,
          orderBy: 'creationDate:desc',
        },
      });

      $variables.Property_Header_Adp.data = response.body.items;
       document.getElementById("loadingSpinner").style.display = 'none'; // Hide
    }
  }

  return ButtonActionChain;
});
