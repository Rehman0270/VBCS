define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ClearButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.Property_Header_Adp',
    '$page.variables.contract_number_input',
    '$page.variables.contract_type_input',
    '$page.variables.customer_name_input',
    '$page.variables.customer_number_input',
    '$page.variables.Lease_class_input',
    '$page.variables.site_input',
    '$page.variables.var_lease_class_search',
    '$page.variables.var_trx_num_search',
  ],
      });

      $variables.var_trx_num_search = null;
    }
  }

  return ClearButtonActionChain;
});
