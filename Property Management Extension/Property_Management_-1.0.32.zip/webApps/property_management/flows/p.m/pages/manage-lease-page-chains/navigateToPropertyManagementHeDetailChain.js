define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToPropertyManagementHeDetailChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.propertyManagementHeId
     */
    async run(context, { propertyManagementHeId }) {
      const { $page, $flow, $application, $constants, $variables } = context;
    }
  }

  return navigateToPropertyManagementHeDetailChain;
});
