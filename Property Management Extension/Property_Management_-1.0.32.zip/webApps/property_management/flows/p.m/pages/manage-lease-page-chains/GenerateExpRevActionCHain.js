define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class GenerateExpRevActionCHain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;

document.getElementById('GenerateButton').disabled = true;
document.getElementById('GenerateButton').label = 'Generating...';

      const response = await Actions.callRest(context, {
        endpoint: 'GetLeaseHeader/getProperty_management_headers',
      uriParams: {
          onlyData: 'true',
          q: '{"contract_number":"' + $variables.var_contract_number_search + '"}'
        },
      });

      const response2 = await Actions.callRest(context, {
        endpoint: 'GETLeaseLines/getProperty_management_lines',
        uriParams: {
          onlyData: 'true',
          q: '{"contract_number":"' + $variables.var_contract_number_search + '"}'

        },
      });

      response2.body.items.forEach(item => {
        const linesObject = {
          LineNumber: item.line_number,
          LineAmount: item.fee,
          Description: 'Goods',
          LineType: 'Item',
          DistributionCombination: "10.100.5005.10000",
          TaxClassification: item.tax_classifiaction_code,
          TaxControlAmount: $page.functions.calculatelineAmount(item).totalTaxAmount,
        };
        $page.variables.line_var_any.push(linesObject)

      });

     const calculatedAmount = $page.functions.calculateInvoiceAmount($page.variables.line_var_any);

      if (response.body.items[0].lease_class === 'Expense') {


        $variables.APInvPOST_var.InvoiceDate = new Date(response.body.items[0].commencement_date).toISOString().split('T')[0];
        $variables.APInvPOST_var.InvoiceNumber = response.body.items[0].contract_number;
        $variables.APInvPOST_var.InvoiceCurrency = 'INR';
        $variables.APInvPOST_var.InvoiceAmount = Number(calculatedAmount.totalAmount);
        $variables.APInvPOST_var.BusinessUnit = 'FORD-INDIA BUSINESS UNIT';
        $variables.APInvPOST_var.PaymentMethod = 'Electronic';
        $variables.APInvPOST_var.Requester = null;
        $variables.APInvPOST_var.InvoiceGroup = 'E';
        $variables.APInvPOST_var.Description = 'test';
        $variables.APInvPOST_var.PaymentTerms = response2.body.items[0].payment_term;
        $variables.APInvPOST_var.Supplier = response.body.items[0].name;
        $variables.APInvPOST_var.SupplierSite = response.body.items[0].site;

/*$page.variables.line_var_any = response2.body.items;

     await   $page.functions.calculateInvoiceAmount($page.variables.line_var_any);
*/
     
        /*const results = await ActionUtils.forEach(response2.body.items, async (item, index) => {
        

        
const lineObject = {
  LineNumber: response2.body.items[index].line_number,
  LineAmount: response2.body.items[index].fee,
  Description: 'Goods',
  LineType: 'Item',
  DistributionCombination: "10.100.5005.10000",
  TaxClassification: response2.body.items[index].tax_classifiaction_code,
  TaxControlAmount: 12,
};

        $variables.APInvPOST_var.invoiceLines.push(lineObject);
        }, { mode: 'serial' });*/

        $variables.APInvPOST_var.invoiceLines = $page.variables.line_var_any;

        const APINV_RESPONCE = await Actions.callRest(context, {
          endpoint: 'APInvPOST/postFscmRestApiResources11_13_18_05Invoices',
          body: $variables.APInvPOST_var,
        });

        if (!APINV_RESPONCE.ok) {
          await Actions.fireNotificationEvent(context, {
            message: JSON.stringify(APINV_RESPONCE.body),
            summary: 'ERROR WHILE CREATING AP INVOICE.',
            type: 'error',
          });
        
          return;
        }

        if (APINV_RESPONCE.ok === true) {

delete response.body.items[0].links;

          response.body.items[0].customer_trx_id = APINV_RESPONCE.body.InvoiceId;
       response.body.items[0].trx_number = APINV_RESPONCE.body.InvoiceNumber;
          response.body.items[0].fusion_flag = 'Y';

await Actions.callRest(context, {
  endpoint: 'UpdateLeaseHeader/putProperty_management_headersHseq_no',
  uriParams: {
    'Hseq_no': response.body.items[0].hseq_num,
  },
  body: response.body.items[0],
});
        }

        

      } else if (response.body.items[0].lease_class === 'Revenue') {
        
        $variables.ARInvPOST_var.TransactionDate = new Date(response.body.items[0].commencement_date).toISOString().split('T')[0];
        $variables.ARInvPOST_var.DueDate = new Date(response.body.items[0].commencement_date).toISOString().split('T')[0];
        $variables.ARInvPOST_var.InvoiceCurrencyCode = 'INR';
        $variables.ARInvPOST_var.BusinessUnit = 'FORD-INDIA BUSINESS UNIT';
        $variables.ARInvPOST_var.TransactionType = 'FORD-INDIA INVOICE';
        $variables.ARInvPOST_var.TransactionSource = 'FORD-INDIA TS';
 if (response2.body.items[0].payment_term === 'Immediate') {

        $variables.ARInvPOST_var.PaymentTerms = 'IMMEDIATE';}
        else {

        $variables.ARInvPOST_var.PaymentTerms = response2.body.items[0].payment_term;  
        }
        $variables.ARInvPOST_var.BillToCustomerNumber = response.body.items[0].customer_number;
      
        const results = await ActionUtils.forEach(response2.body.items, async (item, inde) => {
          const lineObject = {
          LineNumber : response2.body.items[inde].line_number,
          UnitSellingPrice :response2.body.items[inde].fee,
          Description : 'Goods',
          TaxClassificationCode: response2.body.items[0].tax_classifiaction_code,
          Quantity :1
};

$variables.ARInvPOST_var.receivablesInvoiceLines.push(lineObject);

        }, { mode: 'serial' });
      

      
        await Actions.fireNotificationEvent(context, {
          summary: JSON.stringify($variables.ARInvPOST_var),
        });
      
        const ARINV_RESPONCE = await Actions.callRest(context, {
          endpoint: 'ARInvPOST/postFscmRestApiResources11_13_18_05ReceivablesInvoices',
          body: $variables.ARInvPOST_var,
        });

        if (!ARINV_RESPONCE.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: 'ERROR WHILE CREATING AR INVOICE.',
            message: JSON.stringify(ARINV_RESPONCE.body),
            type: 'error',
          });
        
          return;
        }


        if (ARINV_RESPONCE.ok === true) {

      delete response.body.items[0].links;

          response.body.items[0].customer_trx_id = ARINV_RESPONCE.body.CustomerTransactionId;
       response.body.items[0].trx_number = ARINV_RESPONCE.body.TransactionNumber;
          response.body.items[0].fusion_flag = 'Y';

await Actions.callRest(context, {
  endpoint: 'UpdateLeaseHeader/putProperty_management_headersHseq_no',
  uriParams: {
    'Hseq_no': response.body.items[0].hseq_num,
  },
  body: response.body.items[0],
});
        }

        

      }
document.getElementById('GenerateButton').label = 'Generate '+response.body.items[0].lease_class;
document.getElementById('GenerateButton').disabled = false;
    }
  }

  return GenerateExpRevActionCHain;
});
