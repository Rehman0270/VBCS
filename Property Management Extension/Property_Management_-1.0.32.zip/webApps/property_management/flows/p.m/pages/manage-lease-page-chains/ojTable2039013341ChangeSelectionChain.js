define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable2039013341ChangeSelectionChain extends ActionChain {

    /**
     * Sets the page variable to the selected item ID.
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.propertyManagementHeId 
     * @param {any} params.contractNum 
     */
    async run(context, { propertyManagementHeId, contractNum ,trxNumber,leaseClass }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $page.variables.oj_table_203901334_1SelectedId = propertyManagementHeId;
      $page.variables.var_contract_number_search = contractNum;
      $page.variables.var_trx_num_search = trxNumber;
      $page.variables.var_lease_class_search = leaseClass;
    }
  }

  return ojTable2039013341ChangeSelectionChain;
});
