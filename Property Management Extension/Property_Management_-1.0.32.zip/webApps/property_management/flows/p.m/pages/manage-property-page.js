define([], () => {
  'use strict';

  class PageModule {
  }
   PageModule.prototype.checkStrings = function(param1, param2, param3, param4) {
    const queryParts = [];
    const queryStrings = {
        propertyName1: 'propertyType=',
        businessUnit1: 'businessUnit=',
        country1: 'country=',
        propertyCode1: 'propertyCode=',
       

    };

    // Array to hold the params and their corresponding query string keys
    const params = [
        { param: param1, queryKey: queryStrings. propertyName1},
        { param: param2, queryKey: queryStrings. businessUnit1 },
        { param: param3, queryKey: queryStrings. country1},
        { param: param4, queryKey: queryStrings.propertyCode1 }
        
    ];

    // Loop through each parameter and add the query part if it's not null or undefined
    params.forEach(({ param, queryKey }, index) => {
        if (param !== null && param !== undefined) {  // Check for null or undefined
            const condition = `${queryKey}'${param}'`;
            // If it's not the first query part, add ' AND '
            if (queryParts.length > 0) {
                queryParts.push(' AND ');
            }
            queryParts.push(condition);
        }
    });

    // Handling the special condition for param5 
   

    // If no valid parameters are provided, return null
    if (queryParts.length === 0) {
        return null;
    }

    // Join the query parts and return the final query string
    return queryParts.join(' ');
};
  return PageModule;
});
