define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain3 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.indx 
     */
    async run(context, { indx }) {
      const { $page, $flow, $application, $constants, $variables, $functions, $context } = context;

      await $flow.functions.deleteLineExpense(context, indx);

      await Actions.fireNotificationEvent(context, {
        summary: 'Notification',
        type: 'confirmation',
        message: 'Deleted',
      });
    }
  }

  return ButtonActionChain3;
});
