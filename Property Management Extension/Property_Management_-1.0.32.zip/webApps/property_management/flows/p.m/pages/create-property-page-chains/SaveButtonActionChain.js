define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SaveButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      document.getElementById("loadingSpinner").style.display = 'flex'; // Show
const floorTotal = ($flow.variables.Var_floor || []).reduce(
  (sum, item) => sum + (item.rentable || 0),
  0
);
const officeTotal = ($flow.variables.Var_office || []).reduce(
  (sum, item) => sum + (item.rentable || 0),
  0
);
$flow.variables.create_property.rentable = floorTotal ;//+ officeTotal
      if ($flow.variables.ManagePropertyFlag === 'Y' || $flow.variables.ManagePropertyFlag === 'YY') {

        if ($flow.variables.ManagePropertyFlag === 'Y') {


          $flow.variables.create_property.propertyHeaderId = $flow.variables.current_property_header.propertyHeaderId;
               const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/update_PropertyHeader',
          uriParams: {
            'PropertyHeader_Id': $flow.variables.create_property.propertyHeaderId,
          },
          body: $flow.variables.create_property,
        });

          if (response.ok === true) {
            await Actions.fireNotificationEvent(context, {
              summary: 'Success',
              message: 'Record Updated Successfully',
              type: 'confirmation',
            });
          }
        }
        const results2 = await ActionUtils.forEach($flow.variables.Var_floor, async (item1, inde) => {
          if ($flow.variables.Var_floor[inde].propertyLineId !== undefined) {
            const response3 = await Actions.callRest(context, {
              endpoint: 'businessObjects/update_PropertyLines',
              uriParams: {
                'PropertyLines_Id': $flow.variables.Var_floor[inde].propertyLineId,
              },
              body: $flow.variables.Var_floor[inde],
            });
          }
 else {
          $flow.variables.Var_floor[inde].propertyCode = $flow.variables.create_property.propertyCode;

          $variables.var_PropertyLines = $flow.variables.Var_floor[inde];
          $variables.var_PropertyLines.propertyHeaderId = $flow.variables.create_property.propertyHeaderId;
          const createFloorResposne = await Actions.callRest(context, {
            endpoint: 'businessObjects/create_PropertyLines',
            body: $variables.var_PropertyLines,
          });

        //  floorCount += 1;
  
 }


        }, { mode: 'serial' });

        const results = await ActionUtils.forEach($flow.variables.Var_office, async (item, index) => {
          if ( $flow.variables.Var_office[index].propertyDetailId !== undefined) {
            const response2 = await Actions.callRest(context, {
              endpoint: 'businessObjects/update_PropertyDetails',
              uriParams: {
                'PropertyDetails_Id': $flow.variables.Var_office[index].propertyDetailId,
              },
              body: $flow.variables.Var_office[index],
            });
          }
          else {
  $flow.variables.Var_office[index].propertyCode = $flow.variables.create_property.propertyCode;

          $variables.var_PropertyDetails = $flow.variables.Var_office[index];
          $variables.var_PropertyDetails.propertyHeaderId =  $flow.variables.create_property.propertyHeaderId;
          const createOfficeResposne = await Actions.callRest(context, {
            endpoint: 'businessObjects/create_PropertyDetails',
            body: $variables.var_PropertyDetails,
          });

        //  officeCount += 1;

          }
        }, { mode: 'serial' });

        $flow.variables.ManagePropertyFlag = 'YY';
        
      }
     else{
        $variables.Var_PropertyHeader = {
          business_unit: $flow.variables.create_property.businessUnit,
          property_name: $flow.variables.create_property.propertyName,
          property_code: $flow.variables.create_property.propertyCode,
          property_type: $flow.variables.create_property.propertyType,
          region: $flow.variables.create_property.region,
          zone: $flow.variables.create_property.zone,
          status: $flow.variables.create_property.status,
          country: $flow.variables.create_property.country,
          address: $flow.variables.create_property.address,
          tenure: $flow.variables.create_property.tenure,
          class: $flow.variables.create_property.class,
          from_date: $page.functions.convertToISO($flow.variables.create_property.fromDate),
          to_date: $page.functions.convertToISO($flow.variables.create_property.toDate),
          uom: $flow.variables.create_property.uom,
          rentable: $flow.variables.create_property.rentable,
          created_by: "bTranz",
          creation_date: $page.functions.getCurrentISODate(),
          last_updated_by: "bTranz",
          last_updated_date: $page.functions.getCurrentISODate(),
          version_number: 1
        };
      const createHeaderResponse = await Actions.callRest(context, {
        endpoint: 'createPropertyHeader/postProperty_header',
        body: $variables.Var_PropertyHeader,
      });

        $variables.Var_PropertyHeader.property_header_id = createHeaderResponse.body.property_header_id;
        $flow.variables.create_property.propertyHeaderId = createHeaderResponse.body.property_header_id;
      if (createHeaderResponse.body.property_header_id !== null && createHeaderResponse.body.property_header_id !== undefined){
        let floorCount = 0;
        let officeCount = 0;

        const results = await ActionUtils.forEach($flow.variables.Var_floor, async (item, index) => {

          $flow.variables.Var_floor[index].propertyCode = $flow.variables.create_property.propertyCode;

          $variables.var_PropertyLines = $flow.variables.Var_floor[index];
          $variables.var_PropertyLines.propertyHeaderId = createHeaderResponse.body.property_header_id;
          const createFloorResposne = await Actions.callRest(context, {
            endpoint: 'businessObjects/create_PropertyLines',
            body: $variables.var_PropertyLines,
          });

          floorCount += 1;

        }, { mode: 'serial' });

        const results2 = await ActionUtils.forEach($flow.variables.Var_office, async (item, index) => {

          $flow.variables.Var_office[index].propertyCode = $flow.variables.create_property.propertyCode;

          $variables.var_PropertyDetails = $flow.variables.Var_office[index];
          $variables.var_PropertyDetails.propertyHeaderId = createHeaderResponse.body.property_header_id;
          const createOfficeResposne = await Actions.callRest(context, {
            endpoint: 'businessObjects/create_PropertyDetails',
            body: $variables.var_PropertyDetails,
          });

          officeCount += 1;

        }, { mode: 'serial' });

        if(floorCount === $variables.var_PropertyLines.length && officeCount === $variables.var_PropertyDetails.length){
          await Actions.fireNotificationEvent(context,{
            summary: 'Uploaded Successfully!',
            type: 'confirmation',
            displayMode: 'transient',
          });
        }

      }
    }
      document.getElementById("loadingSpinner").style.display = 'none'; // Hide
  }
         
  }

  return SaveButtonActionChain;
});
