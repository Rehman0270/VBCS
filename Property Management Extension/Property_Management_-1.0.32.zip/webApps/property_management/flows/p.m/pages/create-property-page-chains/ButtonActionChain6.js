define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain6 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const results = await ActionUtils.forEach($variables.Var_office, async (item, index) => {

        const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_PropertyDetails',
          body: $variables.Var_office[index],
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'Success',
          message: 'Office details created successfully',
          type: 'confirmation',
        });
      }, { mode: 'serial' });
    }
  }

  return ButtonActionChain6;
});
