define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class BackButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show

      await Actions.callChain(context, {
        chain: 'clear_ButtonActionChain7',
      });

      await Actions.navigateBack(context, {
      });
       document.getElementById("loadingSpinner").style.display = 'none'; // Hide
      $flow.variables.ManagePropertyFlag = 'N';
    }
  }

  return BackButtonActionChain;
});
