define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain4 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response3 = await Actions.callRest(context, {
        endpoint: 'businessObjects/create_PropertyHeader',
        body: $flow.variables.create_property,
      });

      const results = await ActionUtils.forEach($variables.Var_floor, async (item, index) => {

        const response = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_PropertyLines',
          body: $variables.Var_floor[index],
        });
      }, { mode: 'serial' });

      const results2 = await ActionUtils.forEach($variables.Var_office, async (item, index) => {

        const response2 = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_PropertyDetails',
          body: $variables.Var_office[index],
        });
      }, { mode: 'serial' });

      await Actions.fireNotificationEvent(context, {
        summary: 'Success',
        message: 'Floor and office details created successfully',
        type: 'confirmation',
      });
    }
  }

  return ButtonActionChain4;
});
