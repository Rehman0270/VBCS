define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain5 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.index 
     */
    async run(context, { index }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $functions.deleteLineoffice(context, index);

      await Actions.fireNotificationEvent(context, {
        summary: 'Notification',
        message: 'Deleted',
        type: 'confirmation',
      });
    }
  }

  return ButtonActionChain5;
});
