define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class clear_ButtonActionChain7 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show


      await Actions.resetVariables(context, {
        variables: [
     '$flow.variables.create_property',
    '$page.variables.Var_floor',
    '$page.variables.Var_office',
    '$flow.variables.Var_floor',
    '$flow.variables.Var_office',
     '$flow.variables.current_property_header',
     '$page.variables.var_PropertyLines',
     '$page.variables.var_PropertyDetails'
  ],
      });

      $flow.variables.ManagePropertyFlag = 'N';
             document.getElementById("loadingSpinner").style.display = 'none'; // Hide
    }
  }

  return clear_ButtonActionChain7;
});
