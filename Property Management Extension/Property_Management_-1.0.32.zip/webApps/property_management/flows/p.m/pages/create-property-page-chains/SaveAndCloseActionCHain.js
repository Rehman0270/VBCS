define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SaveAndCloseActionCHain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
document.getElementById("loadingSpinner").style.display = 'flex'; // Show
      await Actions.callChain(context, {
        chain: 'SaveButtonActionChain',
      });

      await Actions.callChain(context, {
        chain: 'clear_ButtonActionChain7',
      });

      const toMainDashboard = await Actions.navigateToPage(context, {
        page: 'dashboard',
      });
      document.getElementById("loadingSpinner").style.display = 'none'; // Hide
    }
  }

  return SaveAndCloseActionCHain;
});
