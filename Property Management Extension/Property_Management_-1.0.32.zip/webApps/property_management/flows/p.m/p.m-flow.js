define([], () => {
  'use strict';

  class FlowModule {
     addLineRevenue(context) {
      const lines = context.$flow.variables.Var_floor;

      if (!Array.isArray(lines)) {
        console.error("var_floor is not an array");
        return;
      }

      const newRow = {
      
        floor: "",
        alias: "",
        locationCode: "",
        rentable: null,
        common: null ,
        fromDate: "",
        toDate: "",
        occupancy: "",
        employeeAssignable: "",
        costCenterAssignable: "",
        customerAssignable: "",
        propertyCode:null
        
      };

      lines.push(newRow);
    }

    deleteLineRevenue(context, index) {
      const lines = context.$flow.variables.Var_floor;

      if (!Array.isArray(lines) || index < 0 || index >= lines.length) {
        console.error("Invalid index or Var_floor is not an array");
        return;
      }

      lines.splice(index, 1);
      context.$flow.variables.Var_floor = [...lines];

      lines.forEach((line, i) => {
        line.propertyLineId = i + 1;
      });
    }

     deleteLineExpense(context, index) {
      const lines = context.$flow.variables.Var_floor;

      if (!Array.isArray(lines) || index < 0 || index >= lines.length) {
        console.error("Invalid index or Var_LineEntries is not an array");
        return;
      }

      lines.splice(index, 1);
      context.$flow.variables.Var_floor = [...lines];

      lines.forEach((line, i) => {
        line.propertyLineId = i + 1;
      });
    }

    addofficeline(context) {
      const lines = context.$flow.variables.Var_office;

      if (!Array.isArray(lines)) {
        console.error("var_floor is not an array");
        return;
      }

      const newRow = {
      
        office: "",
        alias: "",
        locationCode: "",
        rentable: null,
        fromDate: "",
        toDate: "",
        occupancy: "",
        assignable: null,
        propertyCode: null
        
      };

      lines.push(newRow);
    }
    deleteLineoffice(context, index) {
      const lines = context.$flow.variables.Var_office;

      if (!Array.isArray(lines) || index < 0 || index >= lines.length) {
        console.error("Invalid index or Var_LineEntries is not an array");
        return;
      }

      lines.splice(index, 1);
      context.$flow.variables.Var_office = [...lines];

      lines.forEach((line, i) => {
        line.propertyDetailId = i + 1;
      });
    }
  
  addLineExpense(context) {
      const lines = context.$flow.variables.Var_LineEntries;

      if (!Array.isArray(lines)) {
        console.error("Var_LineEntries is not an array");
        return;
      }

      const newRow = {
        line_number: lines.length + 1,
        location_type: "",
        location_code: "",
        usage_type: "",
        primary_checkbox: "",
        estimated_occupancy_date: context.$flow.variables.propertyManagementHeadersORDS.commencement_date,
        rent_start_date: context.$flow.variables.propertyManagementHeadersORDS.commencement_date,
        rent_end_date: context.$flow.variables.propertyManagementHeadersORDS.termination_date,
        hseq_num:0,
        fee_element_type: "",
        fee_element: "",
        fee: null,
        tax_classifiaction_code: "",
        fee_basis: "",
        billing_cycle: "",
        payment_term: "",
        contract_number: "",
        lseq_num:null,
      };

      lines.push(newRow);
    }
    deleteLineExpensee(context, index) {
      const lines = context.$flow.variables.Var_LineEntries;

      if (!Array.isArray(lines) || index < 0 || index >= lines.length) {
        console.error("Invalid index or Var_LineEntries is not an array");
        return;
      }

      lines.splice(index, 1);
      context.$flow.variables.Var_LineEntries = [...lines];

      lines.forEach((line, i) => {
        line.lineNumber = i + 1;
      });
    }
  addLineRevenuee(context) {
      const lines = context.$flow.variables.Var_LineEntries;

      if (!Array.isArray(lines)) {
        console.error("Var_LineEntries is not an array");
        return;
      }

      const newRow = {
        line_number: lines.length + 1,
        location_type: "",
        location_code: "",
        usage_type: "",
        primary_checkbox: "",
        estimated_occupancy_date: context.$flow.variables.propertyManagementHeadersORDS.commencement_date,
        rent_start_date: context.$flow.variables.propertyManagementHeadersORDS.commencement_date,
        rent_end_date: context.$flow.variables.propertyManagementHeadersORDS.termination_date,
        hseq_num:0,
        fee_element_type: "",
        fee_element: "",
        fee: null,
        tax_classifiaction_code: "",
        fee_basis: "",
        billing_cycle: "",
        payment_term: "",
        contract_number: "",
        lseq_num:null,
      };

      lines.push(newRow);
    }
  }
  
  return FlowModule;
});
