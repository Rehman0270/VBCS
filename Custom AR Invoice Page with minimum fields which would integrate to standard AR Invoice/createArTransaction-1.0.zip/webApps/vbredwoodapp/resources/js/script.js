define([], () => {
  'use strict';

  class Script {
    connected() {
      const addLineBtn = document.getElementById('addLineBtn');
      const linesTableBody = document.querySelector('#linesTable tbody');

      addLineBtn.addEventListener('click', function() {
        const row = document.createElement('tr');

        row.innerHTML = `
          <td><input type="text" placeholder="Line Number"></td>
          <td><input type="text" placeholder="Item"></td>
          <td><input type="number" placeholder="Unit Price"></td>
          <td><input type="text" placeholder="Tax Code"></td>
          <td><button class="remove-btn">Remove</button></td>
        `;

        linesTableBody.appendChild(row);

        // Attach event listener for remove button
        row.querySelector('.remove-btn').addEventListener('click', function() {
          row.remove();
        });
      });
    }
  }
  
  return Script;
});
