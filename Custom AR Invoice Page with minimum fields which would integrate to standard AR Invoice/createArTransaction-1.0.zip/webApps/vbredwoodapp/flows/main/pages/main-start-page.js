define([], function() {
  'use strict';

  // let LineNumber = 0;
  class PageModule {
    addLine(context) {
      const lines = context.$page.variables.Var_LineEntries;

      const newRow = {
        lineNumber: lines.length + 1, // auto-increment
        lineDescription: "",
        uom: "",
        quantity: null,
        unitSellingPrice: null,
        lineExtensionAmount: null,
        taxClassificationCode: ""
      };

      lines.push(newRow); // push into array
    }


    calculateTransactionAmounts(context, indx) {
      const lines = context.$page.variables.Var_LineEntries[indx];
      const taxClassificationCode = lines.taxClassificationCode;
      const qty = parseFloat(lines.quantity) || 0;
      const price = parseFloat(lines.unitSellingPrice) || 0;
      const lineExtensionAmount = qty * price;

      let totalAmount = context.$page.variables.TotalTransactionAmountValue || 0;
      let transactionAmount = context.$page.variables.TransactionAmountValue || 0;
      let taxAmount = context.$page.variables.TaxAmountValue || 0;
      let taxRate = 0;

      if (taxClassificationCode?.includes('VAT15')) {
        taxRate = 0.15;
      } else if (taxClassificationCode?.includes('VAT5')) {
        taxRate = 0.05;
      }
      
      if (typeof taxAmount === 'undefined' || taxAmount === null) {
        taxAmount = 0;
      }

      transactionAmount += lineExtensionAmount;
      taxAmount += (lineExtensionAmount * taxRate);
      totalAmount = transactionAmount + taxAmount;

      context.$page.variables.TotalTransactionAmountValue = totalAmount;
      context.$page.variables.TransactionAmountValue = transactionAmount;
      context.$page.variables.TaxAmountValue = taxAmount;
    }

    recalculateAmount(row) {
      const qty = parseFloat(row.quantity) || 0;
      const price = parseFloat(row.unitSellingPrice) || 0;
      row.lineExtensionAmount = qty * price;
    }

    deleteLine(context, index) {
      let lines = context.$page.variables.Var_LineEntries;

      if (Array.isArray(lines) && index >= 0 && index < lines.length) {
        lines.splice(index, 1);
        // Reassign to force UI update
        context.$page.variables.Var_LineEntries = [...lines];

        // Optional renumber
        context.$page.variables.Var_LineEntries.forEach((line, i) => {
          line.lineNumber = i + 1;
        });
      }
    }

    filterTransactionSourcesByType(dataArray) {
      const keywords = ["inv", "credit memo", "debit memo"];

      return dataArray.filter(item => {
        const name = (item.Name || "").toLowerCase();
        return keywords.some(keyword => name.includes(keyword));
      });
    }


    getUnique(arrayData, field) {
      if (!Array.isArray(arrayData) || typeof field !== 'string') return [];

      const seen = new Set();
      const result = [];

      arrayData.forEach(item => {
        const value = item[field];
        if (value !== undefined && !seen.has(value)) {
          seen.add(value);
          result.push({ [field]: value });  // key is dynamically set to field name
        }
      });

      return result;
    }

    filterAccountsRevenue(dataArray) {
      const keywords = ["11501"];

      const filtered = dataArray.filter(item => {
        const accountValue = (item.account || "").toLowerCase();
        // Only keep those that match the keyword
        return keywords.some(keyword => accountValue.includes(keyword.toLowerCase()));
      });

      // Now map filtered items into segment strings
      const concatSegments = this.concatenateAccountSegments(
        filtered,
        'entity', 'branch', 'division', 'department', 'project',
        'account', 'intercompany', 'future1', 'future2'
      );

      console.log(concatSegments);

      return concatSegments;
    }

    generateTransactionNumber(prefix = "Osaimi") {
      const now = new Date();

      // Format date as YYYYMMDD
      const datePart = now.toISOString().slice(0,10).replace(/-/g, '');

      // Add a random 4-digit number for uniqueness
      const randomPart = Math.floor(1000 + Math.random() * 9000);

      // Combine all parts
      return `${prefix}${datePart}${randomPart}`;
    }

  }

  return PageModule;
});
