define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class selectDistributionsButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const distributionsDialogBoxOpen = await Actions.callComponentMethod(context, {
        selector: '#distributionsDialogBox',
        method: 'open',
      });
    }
  }

  return selectDistributionsButtonActionChain;
});
