define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createTransactionButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.transactionNumberValue = $page.functions.generateTransactionNumber();

      let lines = [];

      $variables.Var_LineEntries.forEach(line => {
        lines.push({
          LineNumber: line.lineNumber,
          Description: line.lineDescription,
          UnitOfMeasure: line.uom,
          Quantity: parseFloat(line.quantity) || 0,
          UnitSellingPrice: parseFloat(line.unitSellingPrice) || 0,
          LineAmount: parseFloat(line.lineExtensionAmount) || 0,
          TaxClassificationCode: line.taxClassificationCode
        });
      });

      let payload = {	
          BusinessUnit: $variables.businessUnit,
          TransactionSource: $variables.transactionSource,
          TransactionType: $variables.transactionTypeValue,
          TransactionNumber: $variables.transactionNumberValue,
          BillingDate: $variables.transactionDateValue,
          TransactionDate: $variables.transactionDateValue,
          AccountingDate: $variables.accountingDateValue,
          InvoiceCurrencyCode: $variables.transactionCurrencyValue,
          BillToCustomerNumber: $variables.billToNumberValue,
          BillToCustomerName: $variables.billToNameValue,
          PaymentTerms: $variables.paymentTermsValue,
          receivablesInvoiceLines: lines
      };

      const transactionCreationResponse = await Actions.callRest(context, {
        endpoint: 'createTransaction/postReceivablesInvoices',
        body: payload,
      });

      if (transactionCreationResponse.ok) {
        await Actions.fireNotificationEvent(context, {
        summary: 'Status',
        message: "Transaction Created Successfully",
        type: 'info',
        displayMode: 'transient',
      });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Status',
          message: "Error while creating the transaction: " + transactionCreationResponse.statusText,
          type: 'error',
          displayMode: 'persist',
        });
      }
      

      

    }
  }

  return createTransactionButtonActionChain;
});
