define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const results = await Promise.all([
        async () => {

          const response = await Actions.callRest(context, {
            endpoint: 'getBusinessUnits/getHcmBusinessUnitsLOV',
            uriParams: {
              onlyData: 'true',
            },
          });
           $variables.Var_BusinessUnits.data = response.body.items;
        },
        async () => {

          const currenciesResponse = await Actions.callRest(context, {
            endpoint: 'getCurrencies/CurrenciesLOV',
            uriParams: {
              q: 'EnabledFlag=Y',
              onlyData: 'true',
              fields: 'CurrencyCode',
              limit: '10000',
            },
          });

          $variables.Var_Currencies.data = currenciesResponse.body.items;
        },
        async () => {

          const transactionSourceResponse = await Actions.callRest(context, {
            endpoint: 'getTransactionSource/getTransactionSourcesLOV',
            uriParams: {
              onlyData: 'true',
            },
          });

          $variables.Var_TransactionSource.data = $page.functions.filterTransactionSourcesByType(transactionSourceResponse.body.items);
        },
        async () => {
           const transactionTypeResponse = await Actions.callRest(context, {
             endpoint: 'getTransactionTypes/getTransactionTypesLOV',
             uriParams: {
               onlyData: 'true',
             },
           });

          $variables.Var_TransactionType.data = $page.functions.filterTransactionSourcesByType(transactionTypeResponse.body.items) ;
        },
        async () => {
          const accountCombinationResponse = await Actions.callRest(context, {
            endpoint: 'getAccountCombinationsLOV/getAccountCombinationsLOV',
            uriParams: {
              onlyData: 'true',
            },
          });
          const items = accountCombinationResponse.body.items || [];
          $variables.Var_ReceivableDistributionAccounts.data = items;
          $variables.Var_RevenueDistributionAccounts.data = items;
          $variables.Var_EntityList = $page.functions.getUnique (items, 'entity');
          $variables.Var_BranchList = $page.functions.getUnique (items, 'branch');
          $variables.Var_DivisionList = $page.functions.getUnique (items, 'division');
          $variables.Var_DepartmentList = $page.functions.getUnique (items, 'department');
          $variables.Var_ProjectList = $page.functions.getUnique (items, 'project');
          $variables.Var_AccountList = $page.functions.getUnique (items, 'account');
          $variables.Var_IntercompanyList = $page.functions.getUnique (items, 'intercompany');
          $variables.Var_FutureOneList = $page.functions.getUnique (items, 'future1');
          $variables.Var_FutureTwoList = $page.functions.getUnique (items, 'future2');
        },
        async () => {
          const paymentTermsResponse = await Actions.callRest(context, {
            endpoint: 'getPaymentTerms/getPaymentTermsLOV',
            uriParams: {
              onlyData: 'true',
            },
          });

          $variables.Var_PaymentTerms.data = paymentTermsResponse.body.items;
        },
        async () => {
          const taxClassificationResponse = await Actions.callRest(context, {
            endpoint: 'getTaxClassifications/getTaxClassifications',
            uriParams: {
              onlyData: 'true',
            },
          });

          $variables.Var_TaxClassification.data = taxClassificationResponse.body.items;
        },
        async () => {
          const getCustomerDetails = await Actions.callRest(context, {
            endpoint: 'getCustomerDetails/getCustomerDetails',
            uriParams: {
              onlyData: 'true',
              limit: '5000',
            },
          });

          $variables.Var_CustomerDetails.data = getCustomerDetails.body.items;
        },
        async () => {
          const getUOM = await Actions.callRest(context, {
            endpoint: 'getUOM/getUnitsOfMeasure',
            uriParams: {
              onlyData: 'true',
            },
          });

          $variables.Var_UOM.data = getUOM.body.items;
        },
      ].map(sequence => sequence()));


    }
  }

  return PageVbEnterChain;
});
