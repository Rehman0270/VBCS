define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class DeleteLineActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.Index 
     */
    async run(context, { Index }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      await Actions.fireNotificationEvent(context, {
        summary: 'Test',
        message: JSON.stringify($variables.Var_LineEntries[Index]),
      });

      await $functions.deleteLine(context, Index);
    }
  }

  return DeleteLineActionChain;
});
