define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class BillToNumberValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.billToNumberValue = value;

      const matched = $variables.Var_CustomerDetails.data.find(cust => 
      cust.AccountNumber === $variables.billToNumberValue
      );

      const allRecords = $variables.Var_CustomerDetails.data.items || [];
      const matchedSites = allRecords.filter(site =>
        site.AccountNumber === $variables.billToNumberValue
      );

      if (matched) {
        $variables.billToNameValue = matched.CustomerName
        $variables.billToSiteValue = matched.BillToSiteNumber;
        
      }

      if (matchedSites.length > 0) {
        $variables.billToSiteValue = matchedSites[0].BillToSiteNumber;
        $variables.Var_CustomerSite.data = matchedSites;
      }
    }

  }

  return BillToNumberValueChangeChain;
});
