/* Copyright (c) 2024, Oracle and/or its affiliates */

define(["ojs/ojarraydataprovider"],(ArrayDataProvider) => {
  'use strict';

  class PageModule {
    
    /*addLine(context) {
      const lines = context.$page.variables.Var_LineEntries;
      const getNextLineNumber = () => {
        if (!lines || lines.length === 0) return 1; // start from 1 if empty
        const maxLineNumber = Math.max(...lines.map(item => item.lineNumber || 0));
        return maxLineNumber + 1;
      };
      const newRow = {
        lineNumber: getNextLineNumber(),
        lineDescription: '',
        lineAmount: null,
        costCenter: '',
        expenseAccount:'',
        purchaseOrderLineNumber: null,
        receiptNo: "",
        taxClassificationCode: "",
        taxAmount: null,
        taxRate: null,
        invoiceLineIdAtp: null,
        invoiceIdAtp: null
      };

      lines.push(newRow);
    }*/

    addLine(context) {
      const lines = context.$page.variables.Var_LineEntries;

      // Separate existing (ATP) lines and new lines
      const existingLines = lines.filter(line => line.invoiceLineIdAtp !== null);
      const newLines = lines.filter(line => line.invoiceLineIdAtp === null);

      // Find the highest existing lineNumber (from ATP data)
      const maxExistingLineNumber = existingLines.length > 0 
        ? Math.max(...existingLines.map(line => line.lineNumber)) 
        : 0;

      // The new line number should be maxExistingLineNumber + count of new lines + 1
      const newLineNumber = maxExistingLineNumber + newLines.length + 1;

      const newRow = {
        lineNumber: newLineNumber,
        lineDescription: '',
        lineAmount: null,
        costCenter: '',
        expenseAccount: '',
        purchaseOrderLineNumber: null,
        receiptNo: "",
        taxClassificationCode: "KFUPM_RECOVERABLE_15%",
        taxAmount: null,
        taxRate: 15,
        invoiceLineIdAtp: null,
        invoiceIdAtp: null,
        invoiceLineIdFusion: null,
        invoiceIdFusion: null,
        importedToFusion: null,
        attributeCategory:null,
        attribute1: null,
        attribute2: null,
        attribute3: null,
        attribute4: null,
        attribute5: null,
        attribute6: null,
        attribute7: null,
        attribute8: null,
        attribute9: null,
        attribute10: null,
        attribute11: null,
        attribute12: null,
        attribute13: null,
        attribute14: null,
        attribute15: null,
        creationDate: null,
        createdBy: null,
        lastUpdatedDate: null,
        lastUpdatedBy: null,
        versionNumber: null
      };

      lines.push(newRow);
      context.$page.variables.Var_LineEntries = [...lines]; // refresh to trigger VBCS binding
    }


    calculateInvoiceAmount(lines) {

      let totalAmount = 0;
      let totalTaxAmount = 0;

      lines.forEach(line => {
        let taxRate = null;
        line.lineAmount = Number(line.lineAmount);

        // Determine tax rate based on taxClassificationCode
        switch (line.taxClassificationCode) {
          case 'KFUPM_NON_RECOVERABLE_15%':
            taxRate = 15;
            break;
          case 'KFUPM_RECOVERABLE_15%':
            taxRate = 15;
            break;
          case 'KFUPM_NON_RECOVERABLE_5%':
            taxRate = 5;
            break;
          case 'KFUPM_RECOVERABLE_5%':
            taxRate = 5;
            break;
          case 'KFUPM_ZERO':
            taxRate = 0;
            break;
          case 'KFUPM_EXEMPT':
            taxRate = 0;
            break;
          case 'KFUPM_VAT_NOT APPLICABLE':
            taxRate = 0;
            break;
        }

        // Calculate tax amount
        const taxAmount = Number((line.lineAmount * (taxRate / 100)).toFixed(2));

        line.taxRate = taxRate;
        line.taxAmount = taxAmount;

        totalAmount += Number((line.lineAmount + taxAmount).toFixed(2));
        totalTaxAmount += Number(taxAmount.toFixed(2));
      });

      return {totalAmount, totalTaxAmount};
    }

    lineDistributions(context, index) {
      let lines = context.$page.variables.Var_LineEntries;

      lines[index].distributionCombination = context.$page.variables.Var_DistributionConcatenatedSegments;

    }

    /*deleteLine(context, index) {
      let lines = context.$page.variables.Var_LineEntries;

      if (Array.isArray(lines) && index.length >= 0 && index.length < lines.length) {
        index.forEach(indx => {
            lines.splice(indx, 1);
            // Reassign to force UI update
            context.$page.variables.Var_LineEntries = [...lines];
          }
        );
      }
    }*/
    /*deleteLine(context, index) {
      let lines = context.$page.variables.Var_LineEntries;

      if (Array.isArray(lines) && Array.isArray(index)) {
        const sortedIndexes = [...index].sort((a, b) => b - a);

        sortedIndexes.forEach(indx => {
          if (indx >= 0 && indx < lines.length) {
            lines.splice(indx, 1);
          }
        });

        context.$page.variables.Var_LineEntries = [...lines];
        context.$page.variables.Var_LineEntries.forEach((line, i) => {
          line.lineNumber = i + 1;
        });
      }
    }*/

    /*deleteLine(context, index) {
      let lines = context.$page.variables.Var_LineEntries;

      if (Array.isArray(lines) && Array.isArray(index)) {
        const sortedIndexes = [...index].sort((a, b) => b - a);

        sortedIndexes.forEach(indx => {
          if (indx >= 0 && indx < lines.length) {
            lines.splice(indx, 1);
          }
        });

        // After deletion, re-number the 'new lines' only:
        const existingLines = lines.filter(line => line.invoiceLineIdAtp !== null);
        const newLines = lines.filter(line => line.invoiceLineIdAtp === null);

        const maxExistingLineNumber = existingLines.length > 0 
          ? Math.max(...existingLines.map(line => line.lineNumber)) 
          : 0;

        newLines.forEach((line, idx) => {
          line.lineNumber = maxExistingLineNumber + idx + 1;
        });

        context.$page.variables.Var_LineEntries = [...existingLines, ...newLines];
      }
    }*/

    deleteLine(context, index) {
      let lines = context.$page.variables.Var_LineEntries;

      if (Array.isArray(lines) && Array.isArray(index)) {
        const sortedIndexes = [...index].sort((a, b) => b - a);

        sortedIndexes.forEach(indx => {
          if (indx >= 0 && indx < lines.length) {
            lines.splice(indx, 1);
          }
        });

        // Now renumber new lines only without breaking original order:
        let maxExistingLineNumber = 0;

        // First pass: find max existing lineNumber
        lines.forEach(line => {
          if (line.invoiceLineIdAtp !== null) {
            maxExistingLineNumber = Math.max(maxExistingLineNumber, line.lineNumber);
          }
        });

        // Second pass: assign new line numbers to new lines in order
        let newLineCounter = 1;
        lines.forEach(line => {
          if (line.invoiceLineIdAtp === null) {
            line.lineNumber = maxExistingLineNumber + newLineCounter;
            newLineCounter++;
          }
        });

        context.$page.variables.Var_LineEntries = [...lines]; // important for VBCS refresh
      }
    }


    getUnique(arrayData, field) {
      if (!Array.isArray(arrayData) || typeof field !== 'string') return [];

      const seen = new Set();
      const result = [];

      arrayData.forEach(item => {
        const value = item[field];
        if (value !== undefined && !seen.has(value)) {
          seen.add(value);
          result.push({ [field]: value });  // key is dynamically set to field name
        }
      });

      return result;
    }

    getCurrentDateTimeISO() {
      return new Date().toISOString();
    }

    highlight(selectedItem) {
      document.querySelectorAll('.box').forEach(div => {
        div.classList.remove('highlighted');
      });
      selectedItem.element.classList.add('highlighted');
    }

    /*diffRecords(originalData, modifiedData) {
      const originalMap = new Map(originalData.map(item => [item.invoiceLineIdAtp, item]));
      const modifiedMap = new Map(modifiedData.map(item => [item.invoiceLineIdAtp, item]));

      const added = [];
      const updated = [];
      const deleted = [];

      // Detect added (new records have invoiceLineIdAtp as null or undefined)
      modifiedData.forEach(item => {
        const id = item.invoiceLineIdAtp;
        if (id === null || id === undefined) {
          added.push(item);
        } else if (originalMap.has(id)) {
          // Possible update, compare fields
          const originalItem = originalMap.get(id);
          const keys = Object.keys(item).filter(k => k !== 'invoiceLineIdAtp' && k !== 'invoiceIdAtp'); // skip keys
          const hasChanged = keys.some(k => item[k] !== originalItem[k]);
          if (hasChanged) {
            updated.push(item);
          }
        }
      });

      // Detect deleted (those present in original but missing in modified)
      originalData.forEach(item => {
        const id = item.invoiceLineIdAtp;
        if (!modifiedMap.has(id)) {
          deleted.push(item);
        }
      });

      return { added, updated, deleted };
    }*/

    /*compareFileData(originalData, modifiedData) {
      function getKey(item) {
        return item.attachment_id_atp;
      }

      // Convert arrays into maps for quick lookup
      const originalMap = new Map();
      originalData.forEach(item => {
        originalMap.set(getKey(item), item);
      });

      const modifiedMap = new Map();
      modifiedData.forEach(item => {
        modifiedMap.set(getKey(item), item);
      });

      const added = [];
      const deleted = [];

      // Detect added and updated items
      modifiedMap.forEach((newItem, key) => {
        if (!originalMap.has(key)) {
          added.push(newItem);
        }
      });

      // Detect deleted items
      originalMap.forEach((oldItem, key) => {
        if (!modifiedMap.has(key)) {
          const deletedObject = {
            attachment_id_atp: oldItem.attachment_id_atp
          };
          deleted.push(deletedObject);
        }
      });

      return { added, deleted };
    }*/

    compareFileData(originalData, modifiedData) {
      const added = [];
      const deleted = [];

      // Detect added: no attachment_id_atp means it's new
      modifiedData.forEach(item => {
        if (item.attachment_id_atp === undefined || item.attachment_id_atp === null) {
          added.push(item);
        }
      });

      // Build a map of existing IDs
      const modifiedIDs = new Set(
        modifiedData
          .filter(item => item.attachment_id_atp !== undefined && item.attachment_id_atp !== null)
          .map(item => item.attachment_id_atp)
      );

      originalData.forEach(item => {
        if (!modifiedIDs.has(item.attachment_id_atp)) {
          deleted.push({ attachment_id_atp: item.attachment_id_atp });
        }
      });

      return { added, deleted };
    }



    /*compareFileData(originalData, modifiedData) {
      function getKey(item) {
        return `${item.invoice_id_atp}`;
      }

      const originalMap = new Map();
      originalData.forEach(item => {
        originalMap.set(getKey(item), item);
      });

      const modifiedMap = new Map();
      modifiedData.forEach(item => {
        modifiedMap.set(getKey(item), item);
      });

      const added = [];
      const deleted = [];

      // Detect added items
      modifiedMap.forEach((item, key) => {
        if (!originalMap.has(key)) {
          added.push(item);
        }
      });

      // Detect deleted items
      originalMap.forEach((item, key) => {
        if (!modifiedMap.has(key)) {
          deleted.push(item);
        }
      });

      return { added, deleted };
    }*/



    diffRecords(originalData, modifiedData) {
      const originalMap = new Map(originalData.map(item => [item.invoiceLineIdAtp, item]));
      const modifiedMap = new Map(modifiedData.map(item => [item.invoiceLineIdAtp, item]));

      const added = [];
      const updated = [];
      const deleted = [];

      const round = (num) => typeof num === 'number' ? parseFloat(num.toFixed(2)) : num;

      modifiedData.forEach(item => {
        const id = item.invoiceLineIdAtp;
        if (id === null || id === undefined) {
          added.push(item);
        } else if (originalMap.has(id)) {

          const originalItem = originalMap.get(id);
          const keys = Object.keys(item).filter(k => k !== 'invoiceLineIdAtp' && k !== 'invoiceIdAtp'); // skip keys
          
          const hasChanged = keys.some(k => {
            const originalVal = originalItem[k];
            const modifiedVal = item[k];

            if (typeof originalVal === 'number' && typeof modifiedVal === 'number') {
              return round(originalVal) !== round(modifiedVal);
            }
            return originalVal !== modifiedVal; // compare non-numeric directly
          });

          if (hasChanged) {
            updated.push(item);
          }
        }
      });

      originalData.forEach(item => {
        const id = item.invoiceLineIdAtp;
        if (!modifiedMap.has(id)) {
          deleted.push(item);
        }
      });

      return { added, updated, deleted };
    }

    returnParsedReportData(soapResponse, context) {
      const parseXML = (xmlStr) => {
          const parser = new DOMParser();
          return parser.parseFromString(xmlStr, "text/xml");
      };

      const parseGroups = (xmlStr, groups) => {
          const report = parseXML(xmlStr);
          const result = {};
          groups.forEach(group => {
              result[group] = Array.from(report.getElementsByTagName(group)).map(node => {
                  const obj = {};
                  Array.from(node.children).forEach(child => {
                      obj[child.nodeName] = child.textContent.trim();
                  });
                  return obj;
              });
          });
          return result;
      };

      const response = parseXML(soapResponse);
      const reportBytesNode = response.querySelector("reportBytes").textContent;
      if (!reportBytesNode) throw new Error("reportBytes not found in SOAP response");

      const decodedXML = atob(reportBytesNode);
      const groups = ["SUPPLIERDETAILS","SUPPLIERSITEDETAILS", "PAYMENTTERMS", "CURRENCY", "EXPENSE", "COSTCENTER"];
      const data = parseGroups(decodedXML, groups);

      const createADP = (data, keys) => new ArrayDataProvider(data, { keyAttributes: keys });

      context.$page.variables.Var_SuppliersADP = createADP(data.SUPPLIERDETAILS, ['SUPPLIER_ID']);
      context.$page.variables.Var_SupplierSitesADP = createADP(data.SUPPLIERSITEDETAILS, ['SUPPLIER_SITE_ID']);
      context.$page.variables.Var_CurrenciesADP = createADP(data.CURRENCY, ['CURRENCY_CODE', 'CURRENCY_NAME']);
      context.$page.variables.Var_PaymentTermsADP = createADP(data.PAYMENTTERMS, ['PAYMENT_NAME']);
      context.$page.variables.Var_CostCentersADP = createADP(data.COSTCENTER, ['COST_CENTER', 'DESCRIPTION']);
      context.$page.variables.Var_ExpenseAccountsADP = createADP(data.EXPENSE, ['EXPENSE_ACCOUNT', 'DESCRIPTION']);
      
      return {
          supplierADP: createADP(data.SUPPLIERDETAILS, ['SUPPLIER_ID']),
          supplierSitesADP: createADP(data.SUPPLIERSITEDETAILS, ['SUPPLIER_SITE_ID']),
          paymentTermsADP: createADP(data.PAYMENTTERMS, ['PAYMENT_NAME']),
          currencyADP: createADP(data.CURRENCY, ['CURRENCY_CODE']),
          expenseAccountsADP: createADP(data.EXPENSE, ['EXPENSE_ACCOUNT', 'DESCRIPTION']),
          costCenterADP: createADP(data.COSTCENTER, ['COST_CENTER', 'DESCRIPTION'])
      };
    }

    reportDataXMLbody() {
        let body=null;
       body = `<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
				        <soap:Header/>
				          <soap:Body>
					          <pub:runReport>
						          <pub:reportRequest>
							          <pub:byPassCache>true</pub:byPassCache>
							          <pub:reportAbsolutePath>/Custom/APINVOICECUSTOM_EXTENSION/Supplier Details.xdo</pub:reportAbsolutePath>
							          <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>
						          </pub:reportRequest>
					          </pub:runReport>
				          </soap:Body>
				       </soap:Envelope>`;
      return body;
    }

    getCostCenter(context){
      /*return context.data.COST_CENTER;*/
      return context.data.DESCRIPTION;
    }

    getExpenseAccount(context){
      /*return context.data.EXPENSE_ACCOUNT;*/
      return context.data.DESCRIPTION;
    }

    getSupplierName(context){
        return context.data.SUPPLIER_NAME;
    }

    getCurrency(context){
      return context.data.CURRENCY_CODE;
    }

    wait(ms) {
      return new Promise(resolve => {
        setTimeout(resolve, ms);
      });
    }

    areLinesValid(lines) {

      const requiredKeys = ['lineDescription', 'lineAmount', 'costCenter', 'expenseAccount'];
      // Guard against null / non‑arrays
      if (!Array.isArray(lines) || lines.length === 0) {
        return false;
      }

      // Every line must have every required field filled
      return lines.every(line =>
        requiredKeys.every(key => {
          const v = line[key];
          if (v !== null && v !== undefined && v !== ''){
            return true;
          }
          else { 
            return false;
          }
        })
      );
    }

  }

  return PageModule;
});
