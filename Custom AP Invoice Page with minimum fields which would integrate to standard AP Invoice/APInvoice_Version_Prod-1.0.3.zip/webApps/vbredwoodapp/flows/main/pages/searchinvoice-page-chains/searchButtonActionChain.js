define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class searchButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $flow.functions.showloading();

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.Get_All_Invoice_Headers',
  ],
      });

      const checkStrings = await $functions.checkStrings($variables.SupplierNameSearch_Var, $variables.InvoiceNumberSearch_Var, $variables.SupplierNumberSearch_Var, $variables.PONumberSearch_Var, $variables.InvoiceDateSearch_Var, $flow.variables.userName);

      const response = await Actions.callRest(context, {
        endpoint: 'Get_All_Invoices_Header/getAp_invoices_all',
        uriParams: {
          q: checkStrings,
        },
      });

      $variables.Get_All_Invoice_Headers.data = response.body.items;

      const unique = await $functions.unique(response.body.items);
      
      $variables.InvoiceNumber_Var_LOV = unique.invoice_number;
      $variables.PONumber_Var_LOV = unique.po_number;
      $variables.Supplier_Name_VAR_LOV = unique.supplier_name;
      $variables.SupplierNumber_Var_LOV = unique.supplier_number;

      const invoice_id_fusion = unique.invoice_id_fusion;

      // const reportParameter = $variables.Get_All_Invoice_Headers.data
      // .filter(header => header.fusion_vouchernumber === null)
      // .filter(header => 
      //   invoice_id_fusion.some(id => id.fusion_invoice_id === header.invoice_id_fusion)
      // )
      // .map(header => header.invoice_id_fusion)
      // .join(',');
       const reportParameter = invoice_id_fusion.map(id => id.fusion_invoice_id).join(',');


      const reportResponse = await Actions.callRest(context, {
        endpoint: 'getReportData/postXmlpserverServicesExternalReportWSSService',
        body: $functions.reportDataXMLbody(reportParameter),
      });

      const soapResponse = reportResponse?.response?.body || reportResponse?.body || reportResponse;

      $variables.parsedReportData = $functions.returnParsedReportData(soapResponse);

      const updatedHeaders = $variables.Get_All_Invoice_Headers.data.map(header => {
        const match = $variables.parsedReportData.reportADP.data.find(
          record => String(record.INVOICE_ID) === String(header.invoice_id_fusion)
        );

        return {
          ...header,
          fusion_approval_status: match ? match.APPROVAL_STATUS : header.fusion_approval_status,
          fusion_payment_status: match ? match.PAID_STATUS : header.fusion_payment_status,
          fusion_payment_date: match ? match.PAYMENT_DATE : header.fusion_payment_date,
          fusion_vouchernumber: match ? match.VOUCHER_NUMBER : header.fusion_vouchernumber,
          attribute14: match ? match.VALIDATION_STATUS : header.attribute14,
        };
      });

      $variables.Get_All_Invoice_Headers.data = updatedHeaders;

      const updatedRecords = $variables.Get_All_Invoice_Headers.data
        .filter(header => header.fusion_approval_status !== null);


      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.SupplierNameSearch_Var',
          '$page.variables.SupplierNumberSearch_Var',
          '$page.variables.InvoiceDateSearch_Var',
          '$page.variables.InvoiceNumberSearch_Var',
          '$page.variables.PONumberSearch_Var',
        ],
      });

      await $flow.functions.hideloading();

      for (let record of updatedRecords){
        await Actions.callRest(context, {
          endpoint: 'UpdateInvoiceHeader/updateInvoiceHeader',
          uriParams: {
            id: record.invoice_id_atp,
          },
          body: JSON.stringify(record)
        });
        /*await Actions.fireNotificationEvent(context,{
          summary: JSON.stringify(record),
        });*/
      }
      
    }
  }

  return searchButtonActionChain;
});
