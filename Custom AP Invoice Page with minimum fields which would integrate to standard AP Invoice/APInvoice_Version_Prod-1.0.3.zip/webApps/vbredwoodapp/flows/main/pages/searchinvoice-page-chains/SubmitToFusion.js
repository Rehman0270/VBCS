define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SubmitToFusion extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $flow.functions.showloading();

      const results = await Promise.all([
        async () => {

          const response = await Actions.callRest(context, {
            endpoint: 'Get_Invoice_Lines_All/getAp_invoice_lines_all',
            uriParams: {
              q: '{"invoice_id_atp":'+$flow.variables.Get_One_Header_Var.invoice_id_atp +'}',
              limit: '499',
            },
          });
            const linespayload2 = await $functions.linespayload(response.body.items);

          $flow.variables.LinesSubmitPayload_Var.data = linespayload2;
        },
        async () => {

          const response2 = await Actions.callRest(context, {
            endpoint: 'Get_attachments_ATP/getFun_attachments',
            uriParams: {
              q: '{"source_id":'+$flow.variables.Get_One_Header_Var.invoice_id_atp +'}',
              limit: '499',
            },
          });

          const attachmentspayload = await $functions.attachmentspayload(response2.body.items);

          $flow.variables.Submit_Fusion_Attach_Payload_Var.data = attachmentspayload;
        },
      ].map(sequence => sequence()));



      $flow.variables.FusionPayload.InvoiceNumber = $flow.variables.Get_One_Header_Var.invoice_number;
      $flow.variables.FusionPayload.InvoiceCurrency = $flow.variables.Get_One_Header_Var.invoice_currency;
      $flow.variables.FusionPayload.InvoiceAmount = $flow.variables.Get_One_Header_Var.invoice_amount;
      $flow.variables.FusionPayload.Supplier = $flow.variables.Get_One_Header_Var.supplier_name;
      $flow.variables.FusionPayload.SupplierSite = $flow.variables.Get_One_Header_Var.supplier_site;
      $flow.variables.FusionPayload.PaymentMethod = $flow.variables.Get_One_Header_Var?.payment_method || 'Check';
      $flow.variables.FusionPayload.InvoiceDate = $flow.variables.Get_One_Header_Var.invoice_date;
       /*$flow.variables.FusionPayload.SupplierNumber = $flow.variables.Get_One_Header_Var.supplier_number;*/

       if($flow.variables.Get_One_Header_Var.po_number!==null)
       {
      $flow.variables.FusionPayload.PurchaseOrderNumber = $flow.variables.Get_One_Header_Var.po_number;
       }
      $flow.variables.FusionPayload.PaymentTerms = $flow.variables.Get_One_Header_Var.payment_terms;
       $flow.variables.FusionPayload.Description = $flow.variables.Get_One_Header_Var.invoice_description+$flow.variables.Get_One_Header_Var.justification;
      $flow.variables.FusionPayload.invoiceLines = $flow.variables.LinesSubmitPayload_Var.data;
      $flow.variables.FusionPayload.attachments = $flow.variables.Submit_Fusion_Attach_Payload_Var.data;
      $flow.variables.FusionPayload.BusinessUnit = 'KFUPM BU';

      const dffpayload = await $functions.dffpayload('KFUPM_INVOICE_DATE_AUDIT', $flow.variables.Get_One_Header_Var.invoice_date);

      $flow.variables.FusionPayload.invoiceDff = dffpayload;

      /*await Actions.fireNotificationEvent(context,{
        summary: JSON.stringify($flow.variables.FusionPayload),
      });*/

      /*const response3 = await Actions.callRest(context, {
        endpoint: 'SubmitInvoiceToFusion/postFscmRestApiResources11_13_18_05Invoices',
        body: $flow.variables.FusionPayload,
      });

      if (response3.ok) {

        await Actions.fireNotificationEvent(context, {
          summary: 'Submitted To Fusion',
          type: 'confirmation',
          displayMode: 'transient',
        });

        $flow.variables.Get_One_Header_Var.imported_to_fusion = 'Y';
        $flow.variables.Get_One_Header_Var.invoice_id_fusion = response3.body.InvoiceId;
        $flow.variables.Integration_Payload_Var.invoice_id_fusion = response3.body.InvoiceId;
        $flow.variables.Integration_Payload_Var.invoice_id_atp = $flow.variables.Get_One_Header_Var.invoice_id_atp;

        const response4 = await Actions.callRest(context, {
          endpoint: 'UpdateInvoiceHeader/updateInvoiceHeader',
          uriParams: {
            id: $flow.variables.Get_One_Header_Var.invoice_id_atp,
          },
          body: $flow.variables.Get_One_Header_Var,
        });
        if (response4.ok) {
          const response5 = await Actions.callRest(context, {
            endpoint: 'OICIntegrationToUpdateATPRecords/post1_0',
            body: $flow.variables.Integration_Payload_Var,
          });

          if (response5.body.Status === 'Success') {
            await Actions.fireNotificationEvent(context, {
              summary: 'Completed',
              type: 'confirmation',
              displayMode: 'transient',
            });
          }
          else
          {
              await Actions.fireNotificationEvent(context, {
              summary: 'Failed',
            });
          }
        }
      }
      else{
        await Actions.fireNotificationEvent(context, {
          summary: 'Failed TO Submit',
        });
      }*/

      await $functions.hideloading();
    }
  }

  return SubmitToFusion;
});
