define(["ojs/ojarraydataprovider"],(ArrayDataProvider) => {
  'use strict';

  class PageModule {

    generateldid(prefix = "INV") {
      const now = new Date();

      // Format date as YYYYMMDD
      const datePart = now.toISOString().slice(0, 10).replace(/-/g, '');

      // Add a random 4-digit number for uniqueness
      const randomPart = Math.floor(1000 + Math.random() * 9000);

      // Combine all parts
      return `${prefix}${datePart}${randomPart}`;
    }
    checkStrings(
      supplier_name,
      invoice_number,
      supplier_number,
      po_number,
      invoice_date,
      userName
    ) {
      // Check if all parameters are null or undefined

      /*if (person_id === null) {
        return JSON.stringify({ Person_ID: '999999' });
      }*/

      if (
        supplier_name === null &&
        invoice_number === null &&
        supplier_number === null &&
        po_number === null &&
        invoice_date === null &&
        userName === null
      ) {
        return '{}';
      }

      // Array of parameters and their corresponding keys
      const params = [
        { key: 'supplier_name', value: supplier_name },
        { key: 'invoice_number', value: invoice_number },
        { key: 'supplier_number', value: supplier_number },
        { key: 'po_number', value: po_number },
        { key: 'invoice_date', value: invoice_date },
        { key: 'created_by', value: userName }
      ];

      const queryObject = {};

      // Build the object using only non-null parameters
      params.forEach(({ key, value }) => {
        if (value !== null && value !== undefined) {
          queryObject[key] = value;
        }
      });

      return JSON.stringify(queryObject);
    }

    returnParsedReportData(soapResponse) {
      const parseXML = (xmlStr) => {
          const parser = new DOMParser();
          return parser.parseFromString(xmlStr, "text/xml");
      };

      const parseGroups = (xmlStr, groups) => {
          const report = parseXML(xmlStr);
          const result = {};
          groups.forEach(group => {
              result[group] = Array.from(report.getElementsByTagName(group)).map(node => {
                  const obj = {};
                  Array.from(node.children).forEach(child => {
                      obj[child.nodeName] = child.textContent.trim();
                  });
                  return obj;
              });
          });
          return result;
      };

      const response = parseXML(soapResponse);
      const reportBytesNode = response.querySelector("reportBytes").textContent;
      if (!reportBytesNode) throw new Error("reportBytes not found in SOAP response");

      const decodedXML = atob(reportBytesNode);
      const groups = ["APPROVAL_VALIDATION"];
      const data = parseGroups(decodedXML, groups);

      const createADP = (data, keys) => new ArrayDataProvider(data, { keyAttributes: keys });
      
      return {
          reportADP: createADP(data.APPROVAL_VALIDATION, ['INVOICE_ID'])
      };
    }
    
    reportDataXMLbody(invoice_id_fusion) {
        let body=null;
       body = `<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
				        <soap:Header/>
				          <soap:Body>
					          <pub:runReport>
						          <pub:reportRequest>
							          <pub:byPassCache>true</pub:byPassCache>
                        <pub:parameterNameValues>
                          <pub:item><pub:name>invoice_id</pub:name><pub:values><pub:item>${invoice_id_fusion}</pub:item></pub:values></pub:item>
                        </pub:parameterNameValues>
							          <pub:reportAbsolutePath>/Custom/APINVOICECUSTOM_EXTENSION/InvoiceApprovalAndValidationStatus_Report.xdo</pub:reportAbsolutePath>
							          <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>
						          </pub:reportRequest>
					          </pub:runReport>
				          </soap:Body>
				       </soap:Envelope>`;
      return body;
    }
  }
  PageModule.prototype.unique = function (result) {
    let unique_po_number = {};
    let final_po_number = [];

    let unique_supplier_number = {};
    let final_supplier_number = [];

    let unique_invoice_number = {};
    let final_invoice_number = [];

    let unique_supplier_name = {};
    let final_supplier_name = [];

    let unique_fusion_invoice_id = {};
    let final_fusion_invoice_id = [];

    if (result && result.length > 0) {
      for (let i = 0; i < result.length; i++) {
        const item = result[i];

        if (item.po_number && !unique_po_number[item.po_number]) {
          final_po_number.push({ po_number: item.po_number });
          unique_po_number[item.po_number] = true;
        }

        if (item.supplier_number && !unique_supplier_number[item.supplier_number]) {
          final_supplier_number.push({ supplier_number: item.supplier_number });
          unique_supplier_number[item.supplier_number] = true;
        }

        if (item.invoice_number && !unique_invoice_number[item.invoice_number]) {
          final_invoice_number.push({ invoice_number: item.invoice_number });
          unique_invoice_number[item.invoice_number] = true;
        }

        if (item.supplier_name && !unique_supplier_name[item.supplier_name]) {
          final_supplier_name.push({ supplier_name: item.supplier_name });
          unique_supplier_name[item.supplier_name] = true;
        }

        if (item.invoice_id_fusion && !unique_fusion_invoice_id[item.invoice_id_fusion]) {
          final_fusion_invoice_id.push({ fusion_invoice_id: item.invoice_id_fusion });
          unique_fusion_invoice_id[item.invoice_id_fusion] = true;
        }
      }
    }

    return {
      po_number: final_po_number,
      supplier_number: final_supplier_number,
      invoice_number: final_invoice_number,
      supplier_name: final_supplier_name,
      invoice_id_fusion: final_fusion_invoice_id
    };
  };
  PageModule.prototype.linespayload = function (payload) {
    if (!payload || !Array.isArray(payload)) {
      console.log("Invalid or missing payload");
      return [];
    }

    let resultArray = [];

    for (let i = 0; i < payload.length; i++) {
      const item = payload[i];
      let obj = {};

      if (item.line_number !== null) obj.LineNumber = item.line_number;
      if (item.line_description !== null) obj.Description = item.line_description;
      if (item.attribute1 !== null) obj.LiabilityDistribution = item.attribute1;
      if (item.po_line_no !== null) obj.PurchaseOrderLineNumber = item.po_line_no;
      if (item.tax_classification_code !== null) obj.TaxClassification = item.tax_classification_code;
      if (item.receipt_no !== null) obj.ReceiptNumber = item.receipt_no;
      if (item.line_amount !== null) obj.LineAmount = item.line_amount;
      if (item.tax_amount !== null) obj.TaxControlAmount = item.tax_amount;
      if (item.attribute10 !== null) obj.DistributionCombination = item.attribute10;

      resultArray.push(obj);
    }

    return resultArray;
  };


  PageModule.prototype.attachmentspayload = function (payload) {
    if (!payload || !Array.isArray(payload)) {
      console.log("Invalid or missing attachment payload");
      return [];
    }

    let attachmentsArray = [];

    for (let i = 0; i < payload.length; i++) {
      const item = payload[i];
      let obj = {};

      if (item.attachment_type !== null) obj.Type = 'File';
      if (item.attachment_name !== null) obj.FileName = item.attachment_name;
      if (item.attribute3 !== null) obj.Title = item.attribute3;
      if (item.attachment_description !== null) obj.Description = item.attachment_description;
      if (item.attribute4 !== null) obj.Category = item.attribute4;
      if (item.attachment_content !== null) obj.FileContents = item.attachment_content;

      attachmentsArray.push(obj);
    }

    return attachmentsArray;
  };
  PageModule.prototype.showloading = function () {
    document.getElementById("appLoader").style.display = "block";
  };

  PageModule.prototype.hideloading = function () {
    document.getElementById("appLoader").style.display = "none";
  };

  PageModule.prototype.dffpayload = function createDffPayload(contextValue, dateOfTransactionSigned) {
    return [
      {
        "__FLEX_Context": contextValue,
        "dateOfTransactionSigned": dateOfTransactionSigned
      }
    ];
  }
  return PageModule;
});
