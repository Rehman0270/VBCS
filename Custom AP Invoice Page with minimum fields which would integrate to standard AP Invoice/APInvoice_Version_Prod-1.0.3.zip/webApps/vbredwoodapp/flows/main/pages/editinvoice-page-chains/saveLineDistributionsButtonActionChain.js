define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveLineDistributionsButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      let Indx = $page.variables.linesIndx;

      await $functions.lineDistributions(context, Indx);
      

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.entityDistiributionValue',
          '$page.variables.branchDistiributionValue',
          '$page.variables.divisionDistiributionValue',
          '$page.variables.departmentDistiributionValue',
          '$page.variables.projectDistiributionValue',
          '$page.variables.accountDistiributionValue',
          '$page.variables.intercompanyDistiributionValue',
          '$page.variables.future1DistiributionValue',
          '$page.variables.future2DistiributionValue',
          '$page.variables.Var_DistributionConcatenatedSegments',
        ],
      });
      

      await Actions.callComponentMethod(context, {
        selector: '#distributionCombinationDialogBox',
        method: 'close'
      });
      
        
    }
  }

  return saveLineDistributionsButtonActionChain;
});
