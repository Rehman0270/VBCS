define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveDistributionsButtonAction extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const distributionsDialogBoxClose = await Actions.callComponentMethod(context, {
        selector: '#distributionsDialogBox',
        method: 'close',
      });
    }
  }

  return saveDistributionsButtonAction;
});
