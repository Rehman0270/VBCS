define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class futureOneLiabilityValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.future1Value = value;
      $variables.Var_ConcatenatedSegments = $variables.Var_ConcatenatedSegments + "." + value;
    }
  }

  return futureOneLiabilityValueChangeChain;
});
