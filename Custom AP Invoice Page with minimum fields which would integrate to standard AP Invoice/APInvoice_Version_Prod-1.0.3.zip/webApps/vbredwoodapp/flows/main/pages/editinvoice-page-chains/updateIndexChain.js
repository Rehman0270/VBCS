define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class updateIndexChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context, { Indx }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.linesIndx = Indx;

      const distributionCombinationDialogBoxOpen = await Actions.callComponentMethod(context, {
        selector: '#distributionCombinationDialogBox',
        method: 'open',
      });
    }
  }

  return updateIndexChain;
});
