define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class poNumberClickChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      if (!$variables.poNumberPopulated){
        $flow.variables.Get_One_Header_Var.po_number = null;
        $variables.poNumberPopulated = 'false';
        $flow.variables.Get_One_Header_Var.supplier_name = null;
        $flow.variables.Get_One_Header_Var.supplier_id = null;
        $flow.variables.Get_One_Header_Var.supplier_site = null;
        $flow.variables.Get_One_Header_Var.supplier_site_id = null;
        $flow.variables.Get_One_Header_Var.invoice_currency = null;
        $flow.variables.Get_One_Header_Var.payment_terms = null;
        $flow.variables.Get_One_Header_Var.payment_terms_id = null;
        $flow.variables.Get_One_Header_Var.supplier_number = null;
        $variables.Var_LineEntries = [];
      }
    }
  }

  return poNumberClickChain;
});
