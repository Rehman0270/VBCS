define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class purchaseOrderLineNumberValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     * @param {any} params.currData 
     */
    async run(context, { value, currData }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      const matched = $page.variables.Var_PurchaseOrderReceipts.data.find(receipts => receipts.LineNumber === value);

      if (matched){
        $variables.Var_LineEntries[currData].lineDescription = matched.LineDescription;
        $variables.Var_LineEntries[currData].lineAmount = matched.OpenToInvoiceAmount;
        $variables.Var_LineEntries[currData].receiptNo = matched.Receipt;
        /*$variables.Var_LineEntries[currData].taxClassificationCode = matched.Receipt;*/
      }
    }
  }

  return purchaseOrderLineNumberValueChangeChain;
});
