define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain6 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (Array.isArray($variables.filesADP?.data)) {
        let tempArray = [...$variables.filesADP.data];
        tempArray.splice(index, 1);

        $variables.fileData = {
          data: tempArray
        };
      } else {
        await Actions.fireNotificationEvent(context,{
          summary: "Not an ARRAY",
        });
      }
    }
  }

  return ButtonActionChain6;
});
