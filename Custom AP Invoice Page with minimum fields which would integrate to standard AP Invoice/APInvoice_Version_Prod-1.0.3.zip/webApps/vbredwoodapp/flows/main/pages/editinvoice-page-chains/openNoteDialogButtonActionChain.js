define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class openNoteDialogButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const noteDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#noteDialog',
        method: 'open',
      });
    }
  }

  return openNoteDialogButtonActionChain;
});
