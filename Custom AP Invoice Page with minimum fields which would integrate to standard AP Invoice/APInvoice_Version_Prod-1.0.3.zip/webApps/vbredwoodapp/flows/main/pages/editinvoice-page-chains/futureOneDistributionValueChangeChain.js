define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class futureOneDistributionValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.future1DistiributionValue = value;
      $variables.Var_DistributionConcatenatedSegments = $variables.Var_DistributionConcatenatedSegments + "." + value;
    }
  }

  return futureOneDistributionValueChangeChain;
});
