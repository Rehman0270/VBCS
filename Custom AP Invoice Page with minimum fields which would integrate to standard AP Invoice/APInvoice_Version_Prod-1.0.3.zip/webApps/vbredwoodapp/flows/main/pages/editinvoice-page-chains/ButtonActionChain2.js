define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain2 extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $flow.variables.Get_One_Header_Var.atp_header_id = $flow.variables.Unique_Invoice_ID;
      $flow.variables.Get_One_Header_Var.supplier_number = $variables.supplierNumberValue;
      $flow.variables.Get_One_Header_Var.invoice_amount = $variables.invoiceTotalAmountValue;

      const response = await Actions.callRest(context, {
        endpoint: 'CreateAPInvoice_header/postApinvoice_header',
        body: $flow.variables.Get_One_Header_Var,
      });

      if (response.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Successfully Saved',
          type: 'confirmation',
          displayMode: 'transient',
        });

        const toSearchinvoice = await Actions.navigateToPage(context, {
          page: 'searchinvoice',
        });
      }
      else{
         await Actions.fireNotificationEvent(context, {
           summary: 'Failed To Save',
           displayMode: 'transient',
         });
      }
    }
  }

  return ButtonActionChain2;
});
