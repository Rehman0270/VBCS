define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class poNumberValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.Var_PurchaseOrderLines.data = [];

      $variables.purchaseOrderNumberValue = value;

      const matched = $variables.Var_PurchaseOrders.data.find(order => order.OrderNumber === value);

      if (matched) {
        $variables.poNumberPopulated = 'true';
        $flow.variables.Get_One_Header_Var.supplier_name = matched.Supplier;
        $flow.variables.Get_One_Header_Var.supplier_id = matched.SupplierId;
        $flow.variables.Get_One_Header_Var.supplier_site = matched.SupplierSite;
        $flow.variables.Get_One_Header_Var.supplier_site_id = matched.SupplierSiteId;
        $flow.variables.Get_One_Header_Var.invoice_currency = matched.CurrencyCode;
        $flow.variables.Get_One_Header_Var.payment_terms = matched.PaymentTerms;
        $flow.variables.Get_One_Header_Var.payment_terms_id = matched.PaymentTermsId;

        const getPurchaseOrderLinesResponse = await Actions.callRest(context, {
          endpoint: 'getPurchaseOrderDetails/getPurchaseOrderLines',
          uriParams: {
            purchaseOrdersUniqID: matched.POHeaderId,
            onlyData: 'true',
          },
        });
        await Actions.fireNotificationEvent(context,{
            summary: 'Page Enter',
            message: JSON.stringify($variables.Var_PurchaseOrderLines.data),
          });
        $variables.Var_PurchaseOrderLines.data = getPurchaseOrderLinesResponse.body.items;

        const getPurchaseOrderReceiptResponse = await Actions.callRest(context, {
          endpoint: 'getPoReceiptNumbers/getReceipts',
          uriParams: {
            POHeaderId: matched.POHeaderId,
            onlyData: 'true',
          }
        });
        await Actions.fireNotificationEvent(context,{
            summary: 'Page Enter',
            message: JSON.stringify($variables.Var_PurchaseOrderReceipts.data),
          });
        $variables.Var_PurchaseOrderReceipts.data = getPurchaseOrderReceiptResponse.body.items;
      }
    }
  }

  return poNumberValueChangeChain;
});
