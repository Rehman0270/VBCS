/* Copyright (c) 2024, Oracle and/or its affiliates */

define(["ojs/ojarraydataprovider"],(ArrayDataProvider) => {
  'use strict';

  class PageModule {

    addLine(context) {
      /*const lines = context.$page.variables.Var_LineEntries;*/

      const newRow = {
        lineNumber: context.$page.variables.Var_LineEntries.length + 1, // auto-increment
        lineDescription: '',
        lineAmount: null,
        costCenter: '',
        expenseAccount:'',
        taxClassificationCode: context.$page.variables.taxClassificationCode,
        taxAmount: null,
        taxRate: 15
      };

      /*lines.push(newRow);*/
      context.$page.variables.Var_LineEntries.push(newRow);
    }

    calculateInvoiceAmount(lines) {

      let totalAmount = 0;
      let totalTaxAmount = 0;

      lines.forEach(line => {
        let taxRate = null;
        line.lineAmount = Number(line.lineAmount);

        // Determine tax rate based on taxClassificationCode
        switch (line.taxClassificationCode) {
          case 'KFUPM_NON_RECOVERABLE_15%':
            taxRate = 15;
            break;
          case 'KFUPM_RECOVERABLE_15%':
            taxRate = 15;
            break;
          case 'KFUPM_NON_RECOVERABLE_5%':
            taxRate = 5;
            break;
          case 'KFUPM_RECOVERABLE_5%':
            taxRate = 5;
            break;
          case 'KFUPM_ZERO':
            taxRate = 0;
            break;
          case 'KFUPM_EXEMPT':
            taxRate = 0;
            break;
          case 'KFUPM_VAT_NOT APPLICABLE':
            taxRate = 0;
            break;
        }

        // Calculate tax amount
        const taxAmount = Number((line.lineAmount * (taxRate / 100)).toFixed(2));

        line.taxRate = taxRate;
        line.taxAmount = taxAmount;

        totalAmount += Number((line.lineAmount + taxAmount).toFixed(2));
        totalTaxAmount += Number(taxAmount.toFixed(2));
      });

      return {totalAmount, totalTaxAmount};
    }

    lineDistributions(context, index) {
      let lines = context.$page.variables.Var_LineEntries;

      lines[index].distributionCombination = context.$page.variables.Var_DistributionConcatenatedSegments;

    }

    /*deleteLine(context, index) {
      let lines = context.$page.variables.Var_LineEntries;

      if (Array.isArray(lines) && index.length >= 0 && index.length < lines.length) {
        index.forEach(indx => {
            lines.splice(indx, 1);
            // Reassign to force UI update
            context.$page.variables.Var_LineEntries = [...lines];
          }
        );
      }
    }*/
    deleteLine(context, index) {
      let lines = context.$page.variables.Var_LineEntries;

      if (Array.isArray(lines) && Array.isArray(index)) {
        const sortedIndexes = [...index].sort((a, b) => b - a);

        sortedIndexes.forEach(indx => {
          if (indx >= 0 && indx < lines.length) {
            lines.splice(indx, 1);
          }
        });

        context.$page.variables.Var_LineEntries = [...lines];
        context.$page.variables.Var_LineEntries.forEach((line, i) => {
          line.lineNumber = i + 1;
        });
      }
    }


    getUnique(arrayData, field) {
      if (!Array.isArray(arrayData) || typeof field !== 'string') return [];

      const seen = new Set();
      const result = [];

      arrayData.forEach(item => {
        const value = item[field];
        if (value !== undefined && !seen.has(value)) {
          seen.add(value);
          result.push({ [field]: value });  // key is dynamically set to field name
        }
      });

      return result;
    }

    getCurrentDateTimeISO() {
      return new Date().toISOString();
    }

    /*returnParsedReportData(soapResponse) {
      const parseXML = (xmlStr) => {
          const parser = new DOMParser();
          return parser.parseFromString(xmlStr, "text/xml");
      };

      const parseGroups = (xmlStr, groups) => {
          const report = parseXML(xmlStr);
          const result = {};
          groups.forEach(group => {
              result[group] = Array.from(report.getElementsByTagName(group)).map(node => {
                  const obj = {};
                  Array.from(node.children).forEach(child => {
                      obj[child.nodeName] = child.textContent.trim();
                  });
                  return obj;
              });
          });
          return result;
      };

      const response = parseXML(soapResponse);
      const reportBytesNode = response.querySelector("reportBytes").textContent;
      if (!reportBytesNode) throw new Error("reportBytes not found in SOAP response");

      const decodedXML = atob(reportBytesNode);
      const groups = ["SUPPLIERDETAILS", "PAYMENTTERMS", "CURRENCY", "EXPENSE", "COSTCENTER"];
      const data = parseGroups(decodedXML, groups);

      const createADP = (data, keys) => new ArrayDataProvider(data, { keyAttributes: keys });

      return {
          supplierADP: createADP(data.SUPPLIERDETAILS, ['SUPPLIER_ID']),
          supplierSitesADP: createADP(data.SUPPLIERDETAILS, ['SUPPLIER_SITE_ID']),
          paymentTermsADP: createADP(data.PAYMENTTERMS, ['PAYMENT_NAME']),
          currencyADP: createADP(data.CURRENCY, ['CURRENCY_CODE']),
          expenseAccountsADP: createADP(data.EXPENSE, ['EXPENSE_ACCOUNT', 'DESCRIPTION']),
          costCenterADP: createADP(data.COSTCENTER, ['COST_CENTER', 'DESCRIPTION'])
      };
    }*/


    returnParsedReportData(soapResponse, context) {
      const parseXML = (xmlStr) => {
          const parser = new DOMParser();
          return parser.parseFromString(xmlStr, "text/xml");
      };

      const parseGroups = (xmlStr, groups) => {
          const report = parseXML(xmlStr);
          const result = {};
          groups.forEach(group => {
              result[group] = Array.from(report.getElementsByTagName(group)).map(node => {
                  const obj = {};
                  Array.from(node.children).forEach(child => {
                      obj[child.nodeName] = child.textContent.trim();
                  });
                  return obj;
              });
          });
          return result;
      };

      const response = parseXML(soapResponse);
      const reportBytesNode = response.querySelector("reportBytes").textContent;
      if (!reportBytesNode) throw new Error("reportBytes not found in SOAP response");

      const decodeBase64UTF8 = (base64Str) => {
        const binaryString = atob(base64Str);
        const byteArray = Uint8Array.from(binaryString, char => char.charCodeAt(0));
        return new TextDecoder('utf-8').decode(byteArray);
      };

      const decodedXML = decodeBase64UTF8(reportBytesNode);

      /*const decodedXML = atob(reportBytesNode);*/
      const groups = ["SUPPLIERDETAILS","SUPPLIERSITEDETAILS", "PAYMENTTERMS", "CURRENCY", "EXPENSE", "COSTCENTER"];
      const data = parseGroups(decodedXML, groups);

      const createADP = (data, keys) => new ArrayDataProvider(data, { keyAttributes: keys });

      context.$page.variables.Var_SuppliersADP = createADP(data.SUPPLIERDETAILS, ['SUPPLIER_ID']);
      context.$page.variables.Var_SupplierSitesADP = createADP(data.SUPPLIERSITEDETAILS, ['SUPPLIER_SITE_ID']);
      context.$page.variables.Var_CurrenciesADP = createADP(data.CURRENCY, ['CURRENCY_CODE', 'CURRENCY_NAME']);
      context.$page.variables.Var_PaymentTermsADP = createADP(data.PAYMENTTERMS, ['PAYMENT_NAME']);
      context.$page.variables.Var_CostCentersADP = createADP(data.COSTCENTER, ['COST_CENTER', 'DESCRIPTION']);
      context.$page.variables.Var_ExpenseAccountsADP = createADP(data.EXPENSE, ['EXPENSE_ACCOUNT', 'DESCRIPTION']);
      
      return {
          supplierADP: createADP(data.SUPPLIERDETAILS, ['SUPPLIER_ID']),
          supplierSitesADP: createADP(data.SUPPLIERSITEDETAILS, ['SUPPLIER_SITE_ID']),
          paymentTermsADP: createADP(data.PAYMENTTERMS, ['PAYMENT_NAME']),
          currencyADP: createADP(data.CURRENCY, ['CURRENCY_CODE']),
          expenseAccountsADP: createADP(data.EXPENSE, ['EXPENSE_ACCOUNT', 'DESCRIPTION']),
          costCenterADP: createADP(data.COSTCENTER, ['COST_CENTER', 'DESCRIPTION'])
      };
    }

    /*returnParsedReportData(soapResponse, context) {
      const parseXML = (xmlStr) => {
        const parser = new DOMParser();
        return parser.parseFromString(xmlStr, "text/xml");
      };

      const parseGroups = (xmlStr, groups) => {
        const report = parseXML(xmlStr);
        const result = {};
        groups.forEach(group => {
          result[group] = Array.from(report.getElementsByTagName(group)).map(node => {
            const obj = {};
            Array.from(node.children).forEach(child => {
              obj[child.nodeName] = child.textContent.trim();
            });
            return obj;
          });
        });
        return result;
      };

      const response = parseXML(soapResponse);
      const reportBytesNode = response.querySelector("reportBytes")?.textContent;
      if (!reportBytesNode) throw new Error("reportBytes not found in SOAP response");

      const decodedXML = atob(reportBytesNode);
      const groups = ["SUPPLIERDETAILS", "PAYMENTTERMS", "CURRENCY", "EXPENSE", "COSTCENTER"];
      const data = parseGroups(decodedXML, groups);

      // Assign directly to page variables via context
      context.$page.variables.Var_SuppliersADP.data = data.SUPPLIERDETAILS;
      context.$page.variables.Var_PaymentTerms.data = data.PAYMENTTERMS;
      context.$page.variables.Var_CurrencyList.data = data.CURRENCY;
      context.$page.variables.Var_ExpenseAccounts.data = data.EXPENSE;
      context.$page.variables.Var_CostCenters.data = data.COSTCENTER;

      // Optionally return ADPs if still needed
      const createADP = (data, keys) => new ArrayDataProvider(data, { keyAttributes: keys });

      return {
        supplierADP: createADP(data.SUPPLIERDETAILS, ['SUPPLIER_NAME', 'SUPPLIER_NUMBER', 'SUPPLIER_SITE_NAME', 'SUPPLIER_ID', 'SUPPLIER_SITE_ID']),
        paymentTermsADP: createADP(data.PAYMENTTERMS, ['PAYMENT_NAME']),
        currencyADP: createADP(data.CURRENCY, ['CURRENCY_CODE', 'CURRENCY_NAME']),
        expenseAccountsADP: createADP(data.EXPENSE, ['EXPENSE_ACCOUNT', 'DESCRIPTION']),
        costCenterADP: createADP(data.COSTCENTER, ['COST_CENTER', 'DESCRIPTION'])
      };
    }*/

    /*returnParsedReportData(soapResponse, context) {
      const parseXML = (xmlStr) => {
        const parser = new DOMParser();
        return parser.parseFromString(xmlStr, "text/xml");
      };

      const parseGroups = (xmlStr, groups) => {
        const report = parseXML(xmlStr);
        const result = {};
        const numericFields = [
          "SUPPLIER_ID", "SUPPLIER_SITE_ID", "SUPPLIER_NUMBER"
        ];

        groups.forEach(group => {
          result[group] = Array.from(report.getElementsByTagName(group)).map(node => {
            const obj = {};
            Array.from(node.children).forEach(child => {
              const value = child.textContent.trim();
              obj[child.nodeName] = numericFields.includes(child.nodeName) ? Number(value) : value;
            });
            return obj;
          });
        });

        return result;
      };

      const response = parseXML(soapResponse);
      const reportBytesNode = response.querySelector("reportBytes")?.textContent;
      if (!reportBytesNode) throw new Error("reportBytes not found in SOAP response");

      const decodedXML = atob(reportBytesNode);
      const groups = ["SUPPLIERDETAILS", "PAYMENTTERMS", "CURRENCY", "EXPENSE", "COSTCENTER"];
      const data = parseGroups(decodedXML, groups);

      context.$page.variables.Var_SuppliersADP = new ArrayDataProvider(data.SUPPLIERDETAILS, {
        keyAttributes: ['SUPPLIER_NAME', 'SUPPLIER_ID', 'SUPPLIER_NUMBER']
      });

      context.$page.variables.Var_SupplierSitesADP = new ArrayDataProvider(data.SUPPLIERDETAILS, {
        keyAttributes: ['SUPPLIER_SITE_NAME', 'SUPPLIER_SITE_ID']
      });

      context.$page.variables.Var_PaymentTermsADP = new ArrayDataProvider(data.PAYMENTTERMS, {
        keyAttributes: 'PAYMENT_NAME'
      });

      context.$page.variables.Var_CurrenciesADP = new ArrayDataProvider(data.CURRENCY, {
        keyAttributes: ['CURRENCY', 'CURRENCY_NAME']
      });

      context.$page.variables.Var_ExpenseAccountsADP = new ArrayDataProvider(data.EXPENSE, {
        keyAttributes: ['EXPENSE_ACCOUNT', 'DESCRIPTION']
      });

      context.$page.variables.Var_CostCentersADP = new ArrayDataProvider(data.COSTCENTER, {
        keyAttributes: ['COST_CENTER', 'DESCRIPTION']
      });
    }*/



    reportDataXMLbody() {
        let body=null;
       body = `<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
				        <soap:Header/>
				          <soap:Body>
					          <pub:runReport>
						          <pub:reportRequest>
							          <pub:byPassCache>true</pub:byPassCache>
							          <pub:reportAbsolutePath>/Custom/APINVOICECUSTOM_EXTENSION/Supplier Details.xdo</pub:reportAbsolutePath>
							          <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>
						          </pub:reportRequest>
					          </pub:runReport>
				          </soap:Body>
				       </soap:Envelope>`;
      return body;
    }

    getCostCenter(context){
      /*return context.data.COST_CENTER;*/
      return context.data.DESCRIPTION;
    }

    getExpenseAccount(context){
      /*return context.data.EXPENSE_ACCOUNT;*/
      return context.data.DESCRIPTION;
    }

    getSupplierName(context){
      return context.data.SUPPLIER_NAME;
    }

    getCurrency(context){
      return context.data.CURRENCY_CODE;
    }

    areLinesValid(lines) {

      const requiredKeys = ['lineDescription', 'lineAmount', 'costCenter', 'expenseAccount'];
      // Guard against null / non‑arrays
      if (!Array.isArray(lines) || lines.length === 0) {
        return false;
      }

      // Every line must have every required field filled
      return lines.every(line =>
        requiredKeys.every(key => {
          const v = line[key];
          if (v !== null && v !== undefined && v !== ''){
            return true;
          }
          else { 
            return false;
          }
        })
      );
    }
    dffPayload(contextValue, dateOfTransactionSigned) {
      return [
        {
          "__FLEX_Context": contextValue,
          "dateOfTransactionSigned": dateOfTransactionSigned
        }
      ];
    }
  }
 

  return PageModule;
});
