define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class openUploadAttachmentDialog extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $page.variables.uADialogHideShow = "show";

      await Actions.callComponentMethod(context, {
        selector: '#FileUploadDilaogbox',
        method: 'open',
      });

    }
  }

  return openUploadAttachmentDialog;
});
