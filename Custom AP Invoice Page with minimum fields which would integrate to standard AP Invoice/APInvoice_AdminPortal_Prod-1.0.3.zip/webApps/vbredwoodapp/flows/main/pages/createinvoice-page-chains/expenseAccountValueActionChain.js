define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class expenseAccountValueActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.current 
     * @param {any} params.currentData 
     * @param {string} params.currentAccount 
     */
    async run(context, { current, currentData, currentAccount }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.Var_LineEntries[current].expenseAccount = currentData;
      $variables.Var_LineEntries[current].expenseAccountNumber = currentAccount;

      const ok = $page.functions.areLinesValid($variables.Var_LineEntries);

      if (ok){
        $variables.linesValid = false;
      }
    }
  }

  return expenseAccountValueActionChain;
});
