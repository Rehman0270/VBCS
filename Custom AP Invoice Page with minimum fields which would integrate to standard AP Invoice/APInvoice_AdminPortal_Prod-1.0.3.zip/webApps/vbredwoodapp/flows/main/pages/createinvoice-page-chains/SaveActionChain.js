define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SaveActionChain extends ActionChain {

    /**
     * @param {Object} context
    */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      await $flow.functions.showloading();

      let uploadToFusionPayload = {};
      let linesPayload = [];
      let attachmentsPayload = [];

      const checkDuplicateResponse = await Actions.callRest(context, {
        endpoint: 'Get_All_Invoices_Header/getAp_invoices_all',
        uriParams: {
          q: '{"supplier_id": ' + $flow.variables.Get_One_Header_Var.supplier_id + ', "invoice_number": "' + $flow.variables.Get_One_Header_Var.invoice_number + '"}',
        },
      });

      if (checkDuplicateResponse.body.count >= 1) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Duplicate Invoice Number',
          message: 'Please Change Invoice Number',
          displayMode: 'persist',
        });
        
      }
      else{
      const calculatedAmounts = $page.functions.calculateInvoiceAmount($page.variables.Var_LineEntries);
      $variables.invoiceTotalAmountValue = Number(calculatedAmounts.totalAmount);
      $flow.variables.Get_One_Header_Var.invoice_amount = $variables.invoiceTotalAmountValue;
      $flow.variables.Get_One_Header_Var.tax_amount = Number(calculatedAmounts.totalTaxAmount);
      $flow.variables.Get_One_Header_Var.created_by = $flow.variables.userName||'bTranz';
      $flow.variables.Get_One_Header_Var.last_updated_by = $flow.variables.userName||'bTranz';
      $flow.variables.Get_One_Header_Var.business_unit = 'KFUPM BU';
      $flow.variables.Get_One_Header_Var.business_unit_id = 300000003347133;
      $flow.variables.Get_One_Header_Var.person_id = $flow.variables.Person_ID;
      $flow.variables.Get_One_Header_Var.payment_terms = 'Net 30';
      $flow.variables.Get_One_Header_Var.creation_date = $functions.getCurrentDateTimeISO();
      $flow.variables.Get_One_Header_Var.last_updated_date = $functions.getCurrentDateTimeISO();
      $flow.variables.Get_One_Header_Var.version_number = 1;
      $flow.variables.Get_One_Header_Var.imported_to_fusion = 'N';

      const createHeaderResponse = await Actions.callRest(context, {
        endpoint: 'createInvoiceHeader/postAp_invoices_all2',
        body: $flow.variables.Get_One_Header_Var,
      });

      $flow.variables.Create_Invoice_Lines_ATP_VAR.invoice_id_atp = createHeaderResponse.body.invoice_id_atp;
      $flow.variables.Create_Attachments_VAR.source_id = createHeaderResponse.body.invoice_id_atp;
      $flow.variables.Create_Attachments_VAR.attribute1 = createHeaderResponse.body.invoice_number;
      let files = [];
      let linesOk = false;
      let attachmentsOk = false;
      if (createHeaderResponse.status === 201) {
        $flow.variables.Get_One_Header_Var = createHeaderResponse.body;
        $variables.filesADP.data.forEach(file => {
          const fileObject = {
            attachment_source: 'AP Invoice',
            source_id: createHeaderResponse.body.invoice_id_atp,
            attribute1: createHeaderResponse.body.invoice_number,
            attachment_name: file.FileName,
            attachment_content: file.FileContents,
            attachment_size: file.Size,
            attachment_type: file.UploadedFileContentType,
            imported_to_fusion: 'N',
            creation_date: $functions.getCurrentDateTimeISO(),
            created_by: $flow.variables.userName||'bTranz',
            last_updated_date: $functions.getCurrentDateTimeISO(),
            last_updated_by: $flow.variables.userName||'bTranz',
            version_number: 1
          };
          const filePayloadObject = {
            FileContents: file.FileContents,
            FileName: file.FileName,
            Type: "File"
          };
          files.push(fileObject);
          attachmentsPayload.push(filePayloadObject);
        });

        let attchementCount = 0;
        for (const fileObject of files) {
          const createAttachmentsResponse = await Actions.callRest(context, {
            endpoint: 'Create_Attachments/postFun_attachments',
            body: fileObject,
          });
          if (createAttachmentsResponse.status === 201){
            attchementCount += 1;
            attachmentsOk = true;
          }
          else {
            const deleteInvoiceHeaderResponse = await Actions.callRest(context, {
              endpoint: 'deleteInvoiceHeader/deleteInvoice',
              uriParams: {
                id: createHeaderResponse.body.invoice_id_atp,
              },
            });
            await Actions.fireNotificationEvent(context, {
                summary: "Failed To Save Invoice, please try again!",
                message: "Note: You can use same invoice number",
              });
            return;
          }
        }
        const results = await ActionUtils.forEach($variables.Var_LineEntries, async (item, index) => {
            $flow.variables.Create_Invoice_Lines_ATP_VAR.line_number = item.lineNumber;
            $flow.variables.Create_Invoice_Lines_ATP_VAR.line_description = item.lineDescription;
            $flow.variables.Create_Invoice_Lines_ATP_VAR.line_amount = item.lineAmount;
            $flow.variables.Create_Invoice_Lines_ATP_VAR.cost_center = item.costCenter;
            $flow.variables.Create_Invoice_Lines_ATP_VAR.expense_account = item.expenseAccount;
            $flow.variables.Create_Invoice_Lines_ATP_VAR.po_line_no = item.purchaseOrderLineNumber;
            $flow.variables.Create_Invoice_Lines_ATP_VAR.receipt_no = item.receiptNo;
            $flow.variables.Create_Invoice_Lines_ATP_VAR.tax_classification_code = item.taxClassificationCode;
            $flow.variables.Create_Invoice_Lines_ATP_VAR.tax_amount = item.taxAmount;
            $flow.variables.Create_Invoice_Lines_ATP_VAR.tax_rate = item.taxRate;
            $flow.variables.Create_Invoice_Lines_ATP_VAR.created_by = $flow.variables.userName||'bTranz';
            $flow.variables.Create_Invoice_Lines_ATP_VAR.last_updated_by = $flow.variables.userName||'bTranz';
            $flow.variables.Create_Invoice_Lines_ATP_VAR.attribute10 = '01-'+item.costCenterAccount+'-'+item.expenseAccountNumber+'-00-0000000-00-000000-000000';
            $flow.variables.Create_Invoice_Lines_ATP_VAR.creation_date = $functions.getCurrentDateTimeISO();
            $flow.variables.Create_Invoice_Lines_ATP_VAR.last_updated_date = $functions.getCurrentDateTimeISO();
            $flow.variables.Create_Invoice_Lines_ATP_VAR.version_number = 1;
            $flow.variables.Create_Invoice_Lines_ATP_VAR.imported_to_fusion = 'N';

            const linesPayloadObject = {
              Description: item.lineDescription,
              DistributionCombination: '01-'+item.costCenterAccount+'-'+item.expenseAccountNumber+'-00-0000000-00-000000-000000',
              LineAmount: item.lineAmount,
              LineNumber: item.lineNumber,
              TaxClassification: item.taxClassificationCode,
              TaxControlAmount: item.taxAmount
            };

            linesPayload.push(linesPayloadObject);


            const createLinesResponse = await Actions.callRest(context, {
              endpoint: 'Create_INvoice_Lines/postAp_invoice_lines_all',
              body: $flow.variables.Create_Invoice_Lines_ATP_VAR,
            });

            if (createLinesResponse.status === 201) {
              linesOk = true;
            }
            else {
              await Actions.callRest(context, {
                endpoint: 'deleteInvoiceHeader/deleteInvoice',
                uriParams: {
                  id: createHeaderResponse.body.invoice_id_atp,
                },
              });
              const getAttachmentsToDeleteResponse = await Actions.callRest(context, {
                endpoint: 'Get_attachments_ATP/getFun_attachments',
                uriParams: {
                  q: JSON.stringify({ source_id: createHeaderResponse.body.invoice_id_atp }),
                  onlyData: true,
                },
              });
              for (const deleteAttachment of getAttachmentsToDeleteResponse.body){
                await Actions.callRest(context,{
                  endpoint: 'deleteAttachments/deleteAttachments',
                  uriParams: {
                    id: deleteAttachment.attachment_id_atp,
                  },
                });
              }
              await Actions.fireNotificationEvent(context, {
                  summary: "Failed To Save Invoice, please try again!",
                  message: "Note: You can use same Invoice Number",
                });
              return;
            }
          }, { mode: 'serial' });
          if (linesOk && attachmentsOk){
            const dffPayload = $page.functions.dffPayload('KFUPM_INVOICE_DATE_AUDIT', createHeaderResponse.body.invoice_date);
            let descriptionPayload;
            const invDescription = createHeaderResponse.body.invoice_description;
            const invJustification =  createHeaderResponse.body.justification;
            if(invDescription !== null && invDescription !== undefined && invDescription !== '' && invJustification !== null && invJustification !== undefined && invJustification !== ''){
              descriptionPayload = invDescription + ' ' + invJustification;
            } else if (invDescription !== null && invDescription !== undefined && invDescription !== ''){
              descriptionPayload = invDescription;
            } else if (invJustification !== null && invJustification !== undefined && invJustification !== ''){
              descriptionPayload = invJustification;
            } else {
              descriptionPayload = undefined;
            }
            uploadToFusionPayload = {
              BusinessUnit: createHeaderResponse.body.business_unit,
              Description: descriptionPayload,
              InvoiceAmount: createHeaderResponse.body.invoice_amount,
              InvoiceCurrency: createHeaderResponse.body.invoice_currency,
              InvoiceDate: createHeaderResponse.body.invoice_date,
              InvoiceNumber: createHeaderResponse.body.invoice_number,
              PaymentMethod: createHeaderResponse.body.payment_method,
              PaymentTerms: createHeaderResponse.body.payment_terms,
              Supplier: createHeaderResponse.body.supplier_name,
              SupplierSite: createHeaderResponse.body.supplier_site,
              InvoiceSource:"KFUPM Invoice Portal",
              invoiceDff: dffPayload,
              invoiceLines: linesPayload,
              attachments: attachmentsPayload
            };

            const submitToFusionResponse = await Actions.callRest(context, {
              endpoint: 'SubmitInvoiceToFusion/postFscmRestApiResources11_13_18_05Invoices',
              body: JSON.stringify(uploadToFusionPayload),
            });

            if (submitToFusionResponse.status === 201) {

              $flow.variables.Integration_Payload_Var.invoice_id_fusion = submitToFusionResponse.body.InvoiceId;
              // $flow.variables.Get_One_Header_Var.invoice_id_atp = createHeaderResponse.body.invoice_id_atp;
              $flow.variables.Get_One_Header_Var.invoice_id_fusion = submitToFusionResponse.body.InvoiceId;
              $flow.variables.Get_One_Header_Var.imported_to_fusion = 'Y';
              $flow.variables.Integration_Payload_Var.invoice_id_atp = $flow.variables.Get_One_Header_Var.invoice_id_atp;

              const updateHeadersResponse = await Actions.callRest(context, {
                endpoint: 'UpdateInvoiceHeader/updateInvoiceHeader',
                uriParams: {
                  id: $flow.variables.Get_One_Header_Var.invoice_id_atp,
                },
                body: $flow.variables.Get_One_Header_Var,
              });
              if (updateHeadersResponse.ok) {
                const callIntegrationResponse = await Actions.callRest(context, {
                  endpoint: 'OICIntegrationToUpdateATPRecords/post1_0',
                  body: $flow.variables.Integration_Payload_Var,
                });
                if (callIntegrationResponse.body.Status === 'Success'){
                  await Actions.fireNotificationEvent(context,{
                    summary: "Success",
                    message: "Submitted to fusion successfully",
                    displayMode: "transient",
                    type: "confirmation"
                  });
                } else if(callIntegrationResponse.status === 401){// for authorization error
                   const errorLogPayload = {
                    atp_invoice_id: createHeaderResponse.body.invoice_id_atp,
                    fusion_invoice_id: $flow.variables.Get_One_Header_Var.invoice_id_fusion,
                    error_message: 'Authorization Error while calling  Integration, please rerun the integration(UPDATE_AP_INVOICE_ATP_FLAG) using the atp_invoice_id and fusion_invoice_id as parameters',
                    invoice_number: createHeaderResponse.body.invoice_number,
                    attribute1: callIntegrationResponse.body.Instance_ID
                  }
                  let updateErrorLogTableResponse = await Actions.callRest(context, {
                    endpoint: 'Write_Error_Log/postAp_invoice_error_log',
                    body: JSON.stringify(errorLogPayload),
                  });
                } else{
                  const errorLogPayload = {
                    atp_invoice_id: createHeaderResponse.body.invoice_id_atp,
                    fusion_invoice_id: $flow.variables.Get_One_Header_Var.invoice_id_fusion,
                    error_message: 'Error in the update ATP records Integration, please check Integration using the instance id stored in attribute1',
                    invoice_number: createHeaderResponse.body.invoice_number,
                    attribute1: callIntegrationResponse.body.Instance_ID
                  }
                  let updateErrorLogTableResponse = await Actions.callRest(context, {
                    endpoint: 'Write_Error_Log/postAp_invoice_error_log',
                    body: JSON.stringify(errorLogPayload),
                  });

                  const maxAttempts = 3;
                  let attempt = 1;

                  while (![200, 201].includes(updateErrorLogTableResponse?.status) && attempt <= maxAttempts) {
                    const status = updateErrorLogTableResponse?.status;
                    if (status && status >= 400 && status < 500) {
                      break;
                    }

                    const baseDelay = 500; 
                    const backoff = Math.min(2000, baseDelay * Math.pow(2, attempt - 1)); 
                    const jitter = Math.random() * 100; 
                    const delay = backoff + jitter;

                    await new Promise(res => setTimeout(res, delay));

                    updateErrorLogTableResponse = await Actions.callRest(context, {
                      endpoint: 'Write_Error_Log/postAp_invoice_error_log',
                      body: JSON.stringify(errorLogPayload),
                    });

                    attempt++;
                  }

                  if (![200, 201].includes(updateErrorLogTableResponse?.status)) {
                      await Actions.fireNotificationEvent(context,{
                        summary: "Error",
                        message: "Error while inserting the Error records",
                        type: 'error',
                        displayMode: 'persist',
                      });
                  } else {
                      await Actions.fireNotificationEvent(context,{
                        summary: "Submitted to fusion successfully",
                        message: `Error while updating the ATP records, please check the AP_INVOICE_ERROR_LOG. Use the follwing query: 
                                    SELECT * FROM AP_INVOICE_ERROR_LOG WHERE ATP_INVOICE_ID = `+createHeaderResponse.body.invoice_id_atp,
                        type: 'error',
                        displayMode: 'persist',
                      });
                  }
                 
                }
              }
            } else {
              const errorLogPayload = {
                    atp_invoice_id: createHeaderResponse.body.invoice_id_atp,
                    error_message: JSON.stringify(submitToFusionResponse.body),
                    invoice_number: createHeaderResponse.body.invoice_number
                  }

              let updateErrorLogTableResponse = await Actions.callRest(context, {
                    endpoint: 'Write_Error_Log/postAp_invoice_error_log',
                    body: JSON.stringify(errorLogPayload),
                  });

                  const maxAttempts = 3;
                  let attempt = 1;

                  while (![200, 201].includes(updateErrorLogTableResponse?.status) && attempt <= maxAttempts) {
                    const status = updateErrorLogTableResponse?.status;
                    if (status && status >= 400 && status < 500) {
                      break;
                    }

                    const baseDelay = 500; 
                    const backoff = Math.min(2000, baseDelay * Math.pow(2, attempt - 1)); 
                    const jitter = Math.random() * 100; 
                    const delay = backoff + jitter;

                    await new Promise(res => setTimeout(res, delay));

                    // retry attempt
                    updateErrorLogTableResponse = await Actions.callRest(context, {
                      endpoint: 'Write_Error_Log/postAp_invoice_error_log',
                      body: JSON.stringify(errorLogPayload),
                    });

                    attempt++;
                  }

                  if (![200, 201].includes(updateErrorLogTableResponse?.status)) {
                      await Actions.fireNotificationEvent(context,{
                        summary: "Error",
                        message: "Error while inserting the Error records",
                        type: 'error',
                        displayMode: 'persist',
                      });
                  } else {
                      await Actions.fireNotificationEvent(context,{
                        summary: "Error while submitting to fusion",
                        message: `Please check the AP_INVOICE_ERROR_LOG. Use the follwing query: 
                                    SELECT * FROM AP_INVOICE_ERROR_LOG WHERE ATP_INVOICE_ID = `+createHeaderResponse.body.invoice_id_atp,
                        type: 'error',
                        displayMode: 'persist',
                      });
                  }
            }

            /*await Actions.fireNotificationEvent(context, {
              summary: JSON.stringify(uploadToFusionPayload),
              type: 'info',
            });*/

          } else {
            await Actions.fireNotificationEvent(context, {
              summary: 'Failed To Save',
              type: 'error',
            }); 
          }
      }
        else{
            await Actions.fireNotificationEvent(context, {
              summary: 'Failed To Save',
              type: 'error',
            });
          
        }
        await Actions.navigateToPage(context, {
              page: 'searchinvoice',
            });

      }

      await $flow.functions.hideloading();
    
    }
  }

  return SaveActionChain;
});
