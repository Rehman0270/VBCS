define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageEnterChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $flow.functions.showloading();
      
      const now = new Date();
      const month = now.toLocaleString('en-US', { month: 'short' });
      const year = now.getFullYear().toString().slice(-2);

      const formatted = `${month}-${year}`;
      $variables.Period_Date = formatted;
      const PeriodStatus = await Actions.callRest(context, {
        endpoint: 'Get_Period_Open_Status/getFscmRestApiResources11_13_18_05AccountingPeriodStatusLOV',
        uriParams: {
          q: 'ClosingStatus=O;ApplicationId=200;PeriodNameId=' + formatted,
        },
      });

      if (PeriodStatus.body.count < 1) {
        await $flow.functions.hideloading();
        const accountPeriodStatusOpen2 = await Actions.callComponentMethod(context, {
          selector: '#accountPeriodStatus',
          method: 'open',
        });
      }

      let currentDate = await $flow.functions.getCurrentDate();

      $flow.variables.Get_One_Header_Var.invoice_date = currentDate;

      await Actions.resetVariables(context, {
        variables: [
          '$flow.variables.Attachment_validation_Flag',
        ],
      });
      const results = await Promise.all([
        async () => {
          const getTaxClassificationCodeResponse = await Actions.callRest(context, {
            endpoint: 'getTaxClassificationCodes/getTaxClassificationCodes',
            uriParams: {
              onlyData: 'true',
            },
          });

          $variables.Var_TaxClassification.data = getTaxClassificationCodeResponse.body.items;
        },
        async () => {
          const bipReportResponse = await Actions.callRest(context, {
            endpoint: 'getReportData/postXmlpserverServicesExternalReportWSSService',
            body: $page.functions.reportDataXMLbody(),
          });

          const soapResponse = bipReportResponse?.response?.body || bipReportResponse?.body || bipReportResponse;
          const parsedData = $page.functions.returnParsedReportData(soapResponse, context);
        },
      ].map(sequence => sequence()));

      await $flow.functions.hideloading();

    }
  }

  return PageEnterChain;
});
