define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableFirstSelectedRowChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.rowKey 
     * @param {any} params.rowData 
     */
    async run(context, { rowKey, rowData }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.TEMP_DOWN_FILE_VAR.FileContents = rowData.FileContents;
      $variables.TEMP_DOWN_FILE_VAR.FileName = rowData.FileName;
    }
  }

  return TableFirstSelectedRowChangeChain;
});
