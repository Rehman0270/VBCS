define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SupplierSiteValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.supplierSiteValue = value;
      const matched = $page.variables.Var_SupplierSites.data.find(supplierSites => supplierSites.SupplierSite === value);

      if (matched) {
        $variables.supplierSiteIdValue = matched.SupplierSiteId;
        $flow.variables.Get_One_Header_Var.supplier_site_id = matched.SupplierSiteId;
      }
    }
  }

  return SupplierSiteValueChangeChain;
});
