define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FilePickerSelectChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.detail 
     */
    async run(context, { detail }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      $variables.fileData =  {
        "FileName": detail.files[0].name,
        "Size": detail.files[0].size,
        "File": detail.files[0]
      };

      const base64FromFile = await new Promise((resolve, reject) => {
        let reader = new FileReader();
          reader.readAsDataURL($page.variables.fileData.File);
          reader.onload = function () {
            let index = reader.result.indexOf(";base64,");
            let result = {
              base64: reader.result.slice(index + 8),
              contentType: reader.result.slice(5, index),
            };
            resolve(result);
          };
          reader.onerror = function (error) {
            reject(error);
          };
      });

      $variables.fileData.FileContents = base64FromFile.base64;
      $variables.fileData.UploadedFileContentType = base64FromFile.contentType;
      /*const fileObject = {
        "FileName": detail.files[0].name,
        "Size": detail.files[0].size,
        "File": detail.files[0]
      };

      const base64FromFile = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(fileObject.File);
        reader.onload = function () {
          const index = reader.result.indexOf(";base64,");
          const result = {
            base64: reader.result.slice(index + 8),
            contentType: reader.result.slice(5, index)
          };
          resolve(result);
        };
        reader.onerror = reject;
      });

      fileObject.FileContents = base64FromFile.base64;
      fileObject.UploadedFileContentType = base64FromFile.contentType;

      // Set as array for ArrayDataProvider
      $variables.fileData.data = [{
        FileName: detail.files[0].name,
        Size: detail.files[0].size,
        File: detail.files[0],
        FileContents: base64FromFile.base64,
        UploadedFileContentType: base64FromFile.contentType
      }];*/


      $variables.attachmentPayload = {
        attachment_content: $variables.fileData.FileContents,
        attachment_name: $variables.fileData.FileName,
        attachment_size: $variables.fileData.Size,
        attachment_type: $variables.fileData.UploadedFileContentType,
        imported_to_fusion: "N",
        creation_date: $functions.getCurrentDateTimeISO(),
        created_by: "bTranz",
        last_updated_date: $functions.getCurrentDateTimeISO(),
        last_updated_by: "bTranz",
        version_number: 1
      };

      $variables.filesADP.data.push($variables.fileData);
      if (!$variables.filesADP?.data || $variables.filesADP.data.length === 0) {
        $variables.attachmentName = "None";
      } else if ($variables.filesADP.data.length === 1) {
        $variables.attachmentName = $variables.filesADP.data[0].FileName;
      } else {
        let lastFile = $variables.filesADP.data[$variables.filesADP.data.length - 1].FileName;
        let count = $variables.filesADP.data.length - 1;
        $variables.attachmentName = `${lastFile} +${count} more`;
      }
      /*const firstFile = $variables.fileData.data[0];

      $variables.attachmentPayload = {
        attachment_content: firstFile.FileContents,
        attachment_name: firstFile.FileName,
        attachment_size: firstFile.Size,
        attachment_type: firstFile.UploadedFileContentType,
        imported_to_fusion: "N",
        creation_date: $functions.getCurrentDateTimeISO(),
        created_by: "bTranz",
        last_updated_date: $functions.getCurrentDateTimeISO(),
        last_updated_by: "bTranz",
        version_number: 1
      };*/

      
      /*const postAttachmentResponse = await Actions.callRest(context, {
        endpoint: 'postAttachments/Fun_attachments',
        body: JSON.stringify($variables.attachmentPayload)
      });

      if (postAttachmentResponse.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Success',
          message: 'Attachment Uploaded Successfully',
          type: 'info',
          displayMode: 'transient',
        });
      }*/

    }
  }

  return FilePickerSelectChain;
});
