define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class DeleteLineActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {number[]} params.Indx 
     */
    async run(context, { Indx }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $functions.deleteLine(context, Indx);

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.selectedLines',
  ],
      });

      if ($variables.Var_LineEntries.length === 0){
          $variables.linesValid = true;
        }
    }
  }

  return DeleteLineActionChain;
});
