define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SupplierNameValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $flow.variables.Get_One_Header_Var.supplier_site_id = null;
      $flow.variables.Get_One_Header_Var.supplier_site = null;
      $variables.supplierNameValue = value;
      $flow.variables.Get_One_Header_Var.supplier_name = $variables.supplierNameValue;

      const matched = $page.variables.Var_SuppliersADP.data.find(supplier => supplier.SUPPLIER_NAME === value);

      /*if (matched) {
        $flow.variables.Get_One_Header_Var.supplier_number = matched.SUPPLIER_NUMBER;
      }*/
      if (matched) {
        $flow.variables.Get_One_Header_Var.supplier_number = matched.SUPPLIER_NUMBER;
        $flow.variables.Get_One_Header_Var.supplier_id = matched.SUPPLIER_ID;

        const flag = matched?.LOCAL_FLAG?.trim().toUpperCase();

        if(flag === 'Y'){
          $page.variables.taxClassificationCode = "KFUPM_RECOVERABLE_15%";
        } else if(flag === 'N'){
          $page.variables.taxClassificationCode = "KFUPM_EXEMPT";
        } else {
          await Actions.fireNotificationEvent(context,{
            summary: "Supplier Classification Error",
            message: "Supplier isn't local or foreign",
            displayMode: "persist",
            notificationType: "error",
          });
          $flow.variables.Get_One_Header_Var.supplier_name = null;
          $flow.variables.Get_One_Header_Var.supplier_number = null;
          $flow.variables.Get_One_Header_Var.supplier_id = null;
        }

        /*const sites = $page.variables.Var_SupplierSitesADP.data.find(site => site.SUPPLIER_ID === matched.SUPPLIER_ID);

        if (sites) {
          $flow.variables.Get_One_Header_Var.supplier_site = sites.SUPPLIER_SITE_NAME;
          $flow.variables.Get_One_Header_Var.supplier_site_id = sites.SUPPLIER_SITE_ID;
        }*/
        /*await Actions.fireNotificationEvent(context,{
          summary: JSON.stringify($flow.variables.Get_One_Header_Var),
        });*/
      }


      

      if ($flow.variables.Get_One_Header_Var.supplier_id !== null && $flow.variables.Get_One_Header_Var.supplier_id !== undefined) {
      const getSupplierSitesResponse = await Actions.callRest(context, {
        endpoint: 'getSupplierSites/getSuppliersSites',
        uriParams: {
          SupplierId: $flow.variables.Get_One_Header_Var.supplier_id,
          onlyData: true,
          q: "Status=ACTIVE",
          limit: 1,
        },
      });

      /*await Actions.fireNotificationEvent(context,{
        summary: JSON.stringify(getSupplierSitesResponse),
      });*/

      $flow.variables.Get_One_Header_Var.supplier_site = getSupplierSitesResponse.body.items[0].SupplierSite;
      $flow.variables.Get_One_Header_Var.supplier_site_id = getSupplierSitesResponse.body.items[0].SupplierSiteId;

      /*await Actions.fireNotificationEvent(context,{
        summary: JSON.stringify($flow.variables.Get_One_Header_Var.supplier_site),
        message: JSON.stringify($flow.variables.Get_One_Header_Var.supplier_site_id),
      });*/
      /*comment below line when the if condition is uncommented*/
      /*$variables.Var_SupplierSites.data = getSupplierSitesResponse.body.items;*/
      
      /*if (getSupplierSitesResponse.count > 1 && $flow.variables.Get_One_Header_Var.po_number !== null){
      $variables.Var_SupplierSites.data = getSupplierSitesResponse.body.items;
      } else if (getSupplierSitesResponse.count === 1 && $flow.variables.Get_One_Header_Var.po_number !== null) {
      $flow.variables.Get_One_Header_Var.supplier_site = getSupplierSitesResponse.body.items[0].SupplierSite;
      } else {
        $flow.variables.Get_One_Header_Var.supplier_site = null;
      }*/
      }
    }
  }

  return SupplierNameValueChangeChain;
});
