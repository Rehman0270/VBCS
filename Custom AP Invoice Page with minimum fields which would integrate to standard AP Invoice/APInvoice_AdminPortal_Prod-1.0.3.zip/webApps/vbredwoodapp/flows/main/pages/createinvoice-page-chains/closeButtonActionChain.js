define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class closeButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await $flow.functions.showloading();

      const toSearchinvoice = await Actions.navigateToPage(context, {
        page: 'searchinvoice',
      });

      await $flow.functions.hideloading();
    }
  }

  return closeButtonActionChain;
});
