define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class HyperlinkClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await $flow.functions.base64ToFileDownload($variables.TEMP_ATTACH_VAR.FileContents, $variables.TEMP_ATTACH_VAR.FileName);

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.TEMP_ATTACH_VAR',
  ],
      });
    }
  }

  return HyperlinkClickChain;
});
