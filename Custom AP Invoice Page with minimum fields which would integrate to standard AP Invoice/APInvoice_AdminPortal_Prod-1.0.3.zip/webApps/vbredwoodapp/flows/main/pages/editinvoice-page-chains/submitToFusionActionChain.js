define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SaveActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.p_invoice_id_atp 
     */
    async run(context, { p_invoice_id_atp }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      let uploadToFusionPayload = {};
      //let linesPayload = {};
      //let attachmentsPayload = {};

      const getHeadersResponse = await Actions.callRest(context, {
        endpoint: 'Get_All_Invoices_Header/getAp_invoices_all',
        uriParams: {
          q: JSON.stringify({ invoice_id_atp: p_invoice_id_atp })
        },
      });

       $flow.variables.Get_One_Header_Var = getHeadersResponse.body.items[0];

      const getLinesResponse = await Actions.callRest(context, {
        endpoint: 'Get_Invoice_Lines_All/getAp_invoice_lines_all',
        uriParams: {
          q: JSON.stringify({ invoice_id_atp: p_invoice_id_atp })
        },
      });
      
      const getAttachmentResponse = await Actions.callRest(context, {
        endpoint: 'Get_attachments_ATP/getFun_attachments',
        uriParams: {
          q: JSON.stringify({ source_id: p_invoice_id_atp })
        },
      });

      const linesPayload = getLinesResponse.body.items.map(item => ({
        Description: item.line_description,
        DistributionCombination: item.attribute10,
        LineAmount: item.line_amount,
        LineNumber: item.line_number,
        TaxClassification: item.tax_classification_code,
        TaxControlAmount: item.tax_amount
      }));

      /*await Actions.fireNotificationEvent(context,{
        summary: JSON.stringify(linesPayload),
      });*/

      const attachmentsPayload = getAttachmentResponse.body.items.map(file => ({
        FileContents: file.attachment_content,
        FileName: file.attachment_name,
        Type: "File"
      }));
     
      //linesPayload.push(linesPayloadObject);
      //attachmentsPayload.push(attachmentPayloadObject);

      const dffPayload = $page.functions.dffPayload('KFUPM_INVOICE_DATE_AUDIT', getHeadersResponse.body.items[0].invoice_date);
      let descriptionPayload;
      const invDescription = getHeadersResponse.body.items[0].invoice_description;
      const invJustification = getHeadersResponse.body.items[0].justification;
      if (invDescription !== null && invDescription !== undefined && invDescription !== '' && invJustification !== null && invJustification !== undefined && invJustification !== '') {
        descriptionPayload = invDescription + ' ' + invJustification;
      } else if (invDescription !== null && invDescription !== undefined && invDescription !== '') {
        descriptionPayload = invDescription;
      } else if (invJustification !== null && invJustification !== undefined && invJustification !== '') {
        descriptionPayload = invJustification;
      } else {
        descriptionPayload = undefined;
      }
      uploadToFusionPayload = {
        BusinessUnit: getHeadersResponse.body.items[0].business_unit,
        Description: descriptionPayload,
        InvoiceAmount: getHeadersResponse.body.items[0].invoice_amount,
        InvoiceCurrency: getHeadersResponse.body.items[0].invoice_currency,
        InvoiceDate: getHeadersResponse.body.items[0].invoice_date,
        InvoiceNumber: getHeadersResponse.body.items[0].invoice_number,
        PaymentMethod: getHeadersResponse.body.items[0].payment_method,
        PaymentTerms: getHeadersResponse.body.items[0].payment_terms,
        Supplier: getHeadersResponse.body.items[0].supplier_name,
        SupplierSite: getHeadersResponse.body.items[0].supplier_site,
        InvoiceSource: "KFUPM Invoice Portal",
        invoiceDff: dffPayload,
        invoiceLines: linesPayload,
        attachments: attachmentsPayload
      };

      const submitToFusionResponse = await Actions.callRest(context, {
        endpoint: 'SubmitInvoiceToFusion/postFscmRestApiResources11_13_18_05Invoices',
        body: JSON.stringify(uploadToFusionPayload),
      });

      if (submitToFusionResponse.status === 201) {

        $flow.variables.Integration_Payload_Var.invoice_id_fusion = submitToFusionResponse.body.InvoiceId;
        // $flow.variables.Get_One_Header_Var.invoice_id_atp = getHeadersResponse.body.invoice_id_atp;
        $flow.variables.Get_One_Header_Var.invoice_id_fusion = submitToFusionResponse.body.InvoiceId;
        $flow.variables.Get_One_Header_Var.imported_to_fusion = 'Y';
        $flow.variables.Get_One_Header_Var.attribute15 = 'Success';
        $flow.variables.Integration_Payload_Var.invoice_id_atp = $flow.variables.Get_One_Header_Var.invoice_id_atp;

        const updateHeadersResponse = await Actions.callRest(context, {
          endpoint: 'UpdateInvoiceHeader/updateInvoiceHeader',
          uriParams: {
            id: $flow.variables.Get_One_Header_Var.invoice_id_atp,
          },
          body: $flow.variables.Get_One_Header_Var,
        });
        if (updateHeadersResponse.ok) {
          const callIntegrationResponse = await Actions.callRest(context, {
            endpoint: 'OICIntegrationToUpdateATPRecords/post1_0',
            body: $flow.variables.Integration_Payload_Var,
          });
          if (callIntegrationResponse.body.Status === 'Success') {
            const deleteErrorLogResponse = await Actions.callRest(context,{
              endpoint: 'deleteErrorLogs/delete',
              body: JSON.stringify({invoice_id_atp: $flow.variables.Get_One_Header_Var.invoice_id_atp}),
            });
            await Actions.fireNotificationEvent(context, {
              summary: "Success",
              message: "Submitted to fusion successfully",
              displayMode: "transient",
              type: "confirmation"
            });
          } else if (callIntegrationResponse.status === 401) {// for authorization error
            $flow.variables.Get_One_Header_Var.attribute15 = 'Portal Update Failed';
            await Actions.callRest(context, {
              endpoint: 'UpdateInvoiceHeader/updateInvoiceHeader',
              uriParams: {
                id: $flow.variables.Get_One_Header_Var.invoice_id_atp,
              },
              body: $flow.variables.Get_One_Header_Var,
            });
            const errorLogPayload = {
              atp_invoice_id: getHeadersResponse.body.items[0].invoice_id_atp,
              fusion_invoice_id: $flow.variables.Get_One_Header_Var.invoice_id_fusion,
              error_message: 'Authorization Error while calling  Integration, please rerun the integration(UPDATE_AP_INVOICE_ATP_FLAG) using the atp_invoice_id and fusion_invoice_id as parameters',
              invoice_number: getHeadersResponse.body.items[0].invoice_number,
              attribute1: callIntegrationResponse.body.Instance_ID
            }
            let updateErrorLogTableResponse = await Actions.callRest(context, {
              endpoint: 'Write_Error_Log/postAp_invoice_error_log',
              body: JSON.stringify(errorLogPayload),
            });
          } else {
            $flow.variables.Get_One_Header_Var.attribute15 = 'Portal Update Failed';
            await Actions.callRest(context, {
              endpoint: 'UpdateInvoiceHeader/updateInvoiceHeader',
              uriParams: {
                id: $flow.variables.Get_One_Header_Var.invoice_id_atp,
              },
              body: $flow.variables.Get_One_Header_Var,
            });
            const errorLogPayload = {
              atp_invoice_id: getHeadersResponse.body.items[0].invoice_id_atp,
              fusion_invoice_id: $flow.variables.Get_One_Header_Var.invoice_id_fusion,
              error_message: 'Error in the update ATP records Integration, please check Integration using the instance id stored in attribute1',
              invoice_number: getHeadersResponse.body.items[0].invoice_number,
              attribute1: callIntegrationResponse.body.Instance_ID
            }
            let updateErrorLogTableResponse = await Actions.callRest(context, {
              endpoint: 'Write_Error_Log/postAp_invoice_error_log',
              body: JSON.stringify(errorLogPayload),
            });

            const maxAttempts = 3;
            let attempt = 1;

            while (![200, 201].includes(updateErrorLogTableResponse?.status) && attempt <= maxAttempts) {
              const status = updateErrorLogTableResponse?.status;
              if (status && status >= 400 && status < 500) {
                break;
              }

              const baseDelay = 500;
              const backoff = Math.min(2000, baseDelay * Math.pow(2, attempt - 1));
              const jitter = Math.random() * 100;
              const delay = backoff + jitter;

              await new Promise(res => setTimeout(res, delay));

              updateErrorLogTableResponse = await Actions.callRest(context, {
                endpoint: 'Write_Error_Log/postAp_invoice_error_log',
                body: JSON.stringify(errorLogPayload),
              });

              attempt++;
            }

            if (![200, 201].includes(updateErrorLogTableResponse?.status)) {
              await Actions.fireNotificationEvent(context, {
                summary: "Error",
                message: "Error while inserting the Error records",
                type: 'error',
                displayMode: 'persist',
              });
            } else {
              $flow.variables.Get_One_Header_Var.attribute15 = 'Portal Update Failed';
              await Actions.callRest(context, {
                endpoint: 'UpdateInvoiceHeader/updateInvoiceHeader',
                uriParams: {
                  id: $flow.variables.Get_One_Header_Var.invoice_id_atp,
                },
                body: $flow.variables.Get_One_Header_Var,
              });
              await Actions.fireNotificationEvent(context, {
                summary: "Submitted to fusion successfully",
                message: `Error while updating the ATP records, please contact Administrator`,
                type: 'error',
                displayMode: 'persist',
              });
            }

          }
        }
      } else {
        $flow.variables.Get_One_Header_Var.attribute15 = 'Import Failed';
                    await Actions.callRest(context, {
                      endpoint: 'UpdateInvoiceHeader/updateInvoiceHeader',
                      uriParams: {
                        id: $flow.variables.Get_One_Header_Var.invoice_id_atp,
                      },
                      body: $flow.variables.Get_One_Header_Var,
                    });
        const errorLogPayload = {
          atp_invoice_id: getHeadersResponse.body.items[0].invoice_id_atp,
          error_message: JSON.stringify(submitToFusionResponse.body),
          invoice_number: getHeadersResponse.body.items[0].invoice_number
        };

        let updateErrorLogTableResponse = await Actions.callRest(context, {
          endpoint: 'Write_Error_Log/postAp_invoice_error_log',
          body: JSON.stringify(errorLogPayload),
        });

        const maxAttempts = 3;
        let attempt = 1;

        while (![200, 201].includes(updateErrorLogTableResponse?.status) && attempt <= maxAttempts) {
          const status = updateErrorLogTableResponse?.status;
          if (status && status >= 400 && status < 500) {
            break;
          }

          const baseDelay = 500;
          const backoff = Math.min(2000, baseDelay * Math.pow(2, attempt - 1));
          const jitter = Math.random() * 100;
          const delay = backoff + jitter;

          await new Promise(res => setTimeout(res, delay));

          // retry attempt
          updateErrorLogTableResponse = await Actions.callRest(context, {
            endpoint: 'Write_Error_Log/postAp_invoice_error_log',
            body: JSON.stringify(errorLogPayload),
          });

          attempt++;
        }

        if (![200, 201].includes(updateErrorLogTableResponse?.status)) {
          await Actions.fireNotificationEvent(context, {
            summary: "Error",
            message: "Error while inserting the Error records",
            type: 'error',
            displayMode: 'persist',
          });
        } else {
          await Actions.fireNotificationEvent(context, {
            summary: "Error while submitting to fusion",
            message: JSON.stringify(submitToFusionResponse.body),
            type: 'error',
            displayMode: 'persist',
          });
        }
      }

      /*await Actions.fireNotificationEvent(context, {
        summary: JSON.stringify(uploadToFusionPayload),
        type: 'info',
      });*/


      await Actions.navigateToPage(context, {
        page: 'searchinvoice',
      });

      await $flow.functions.hideloading();

    }
  }

  return SaveActionChain;
});
