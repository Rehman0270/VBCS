define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class closeAttachmentDialogButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.callComponentMethod(context, {
        selector: '#FileUploadDilaogbox',
        method: 'close',
      });

      $variables.changedFileData = $page.functions.compareFileData($variables.filesDataADP_Orignal.data,$variables.filesADP.data);

      /*const fileData = $variables.changedFileData.deleted;

      for (let file of fileData){
        await Actions.fireNotificationEvent(context,{
          summary: JSON.stringify(file),
        });
      }*/
        

      if (!$variables.filesADP?.data || $variables.filesADP.data.length === 0) {
        $variables.attachmentName = "None";
         $flow.variables.Attachment_validation_Flag='false';
      } else if ($variables.filesADP.data.length === 1) {
        $variables.attachmentName = $variables.filesADP.data[0].FileName;
         $flow.variables.Attachment_validation_Flag='true';
      } else {
        let lastFile = $variables.filesADP.data[$variables.filesADP.data.length - 1].FileName;
        let count = $variables.filesADP.data.length - 1;
        $variables.attachmentName = `${lastFile} +${count} more`;
         $flow.variables.Attachment_validation_Flag='true';
      }
    }
  }

  return closeAttachmentDialogButtonActionChain;
});
