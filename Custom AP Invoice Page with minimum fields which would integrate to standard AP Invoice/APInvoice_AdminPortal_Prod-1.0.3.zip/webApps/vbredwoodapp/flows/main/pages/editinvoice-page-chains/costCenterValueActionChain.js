define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class costCenterValueActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.currentData 
     * @param {any} params.current 
     * @param {string} params.currentAccount 
     */
    async run(context, { currentData, current, currentAccount }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.Var_LineEntries[current].costCenter = currentData;
      $variables.Var_LineEntries[current].costCenterAccount = currentAccount;

      const ok = $page.functions.areLinesValid($variables.Var_LineEntries);

      if (ok){
        $variables.linesValid = false;
      }

    }
  }

  return costCenterValueActionChain;
});
