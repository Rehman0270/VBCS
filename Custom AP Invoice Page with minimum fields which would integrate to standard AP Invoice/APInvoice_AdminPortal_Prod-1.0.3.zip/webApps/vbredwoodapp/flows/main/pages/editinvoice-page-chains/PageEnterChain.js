define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageEnterChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await $flow.functions.showloading();

      $flow.variables.Attachment_validation_Flag = 'true';
      $variables.editValidationf1 = 'valid';
      $variables.editValidationf2 = 'valid';
      $variables.editValidationf3 = 'valid';
      $variables.linesValid = false;

      /*$flow.variables.Get_One_Header_Var = {};

      await $page.functions.wait(5000);*/
      
      const bipReportResponse = await Actions.callRest(context, {
            endpoint: 'getReportData/postXmlpserverServicesExternalReportWSSService',
            body: $page.functions.reportDataXMLbody(),
          });

          const soapResponse = bipReportResponse?.response?.body || bipReportResponse?.body || bipReportResponse;

          const parsedData = $page.functions.returnParsedReportData(soapResponse, context);

      /*await $page.functions.wait(5000);*/

      if (soapResponse !== null || soapResponse !== undefined){
        const results = await Promise.all([
          async () => {
            const getAPInvoiceHeaders = await Actions.callRest(context, {
              endpoint: 'Get_All_Invoices_Header/getAp_invoices_all',
              uriParams: {
                onlyData: 'true',
                q: '{"invoice_id_atp":' + $variables.invoiceHeaderIdAtp + '}',
              },
            });

            $variables.Var_EditPageHeader = getAPInvoiceHeaders.body.items[0];
            /*await Actions.fireNotificationEvent(context,{
              summary: JSON.stringify($variables.Var_EditPageHeader.supplier_name),
              message: JSON.stringify($variables.Var_EditPageHeader.invoice_currency),
            });*/
          },
          async () => {

            const getAPInvoiceLines = await Actions.callRest(context, {
              endpoint: 'Get_Invoice_Lines_All/getAp_invoice_lines_all',
              uriParams: {
                onlyData: 'true',
                q: '{"invoice_id_atp":' + $variables.invoiceHeaderIdAtp + '}',
              },
            });
            const invoiceLines = getAPInvoiceLines.body.items;
            invoiceLines.sort((a, b) => a.line_number - b.line_number);
            getAPInvoiceLines.body.items.forEach(item => {
              const lineObject = {
                lineNumber: item.line_number,
                lineDescription: item.line_description,
                lineAmount: item.line_amount,
                costCenter: item.cost_center,
                expenseAccount: item.expense_account,
                purchaseOrderLineNumber: item.po_line_no,
                receiptNo: item.receipt_no,
                taxClassificationCode: item.tax_classification_code,
                taxAmount: item.tax_amount,
                taxRate: item.tax_rate,
                invoiceLineIdAtp: item.invoice_line_id_atp,
                invoiceIdAtp: item.invoice_id_atp,
                invoiceLineIdFusion: item.invoice_line_id_fusion,
                invoiceIdFusion: item.invoice_id_fusion,
                importedToFusion: item.imported_to_fusion,
                attributeCategory: item.attribute_category,
                attribute1: item.attribute1,
                attribute2: item.attribute2,
                attribute3: item.attribute3,
                attribute4: item.attribute4,
                attribute5: item.attribute5,
                attribute6: item.attribute6,
                attribute7: item.attribute7,
                attribute8: item.attribute8,
                attribute9: item.attribute9,
                attribute10: item.attribute10,
                attribute11: item.attribute11,
                attribute12: item.attribute12,
                attribute13: item.attribute13,
                attribute14: item.attribute14,
                attribute15: item.attribute15,
                creationDate: item.creation_date,
                createdBy: item.created_by,
                lastUpdatedDate: item.last_updated_date,
                lastUpdatedBy: item.last_updated_by,
                versionNumber: item.version_number
              };
              $variables.Var_LineEntriesResponse.push(lineObject);
            });
            $variables.Var_LineEntries = $variables.Var_LineEntriesResponse;
          },
          async () => {

            const getAttachments = await Actions.callRest(context, {
              endpoint: 'getAttachments/getAttachments',
              uriParams: {
                onlyData: 'true',
                q: '{"source_id":' + $variables.invoiceHeaderIdAtp + '}'
              }
            });

            if (getAttachments.body.count > 0) {
              getAttachments.body.items.forEach(item => {
                const fileObject = {
                  attachment_id_atp: item.attachment_id_atp,
                  FileName: item.attachment_name,
                  Size: item.attachment_size,
                  UploadedFileContentType: item.attachment_type,
                  Description: item.attachment_description,
                  FileContents: item.attachment_content,
                  Title: item.attachment_name.includes(".")
                    ? item.attachment_name.substring(0, item.attachment_name.indexOf("."))
                    : item.attachment_name
                };
                $variables.filesDataADP_Orignal.data.push(fileObject);
              });
              $variables.filesADP.data = $variables.filesDataADP_Orignal.data;
              if (!$variables.filesADP?.data || $variables.filesADP.data.length === 0) {
                $variables.attachmentName = "None";
              } else if ($variables.filesADP.data.length === 1) {
                $variables.attachmentName = $variables.filesADP.data[0].FileName;
              } else {
                let lastFile = $variables.filesADP.data[$variables.filesADP.data.length - 1].FileName;
                let count = $variables.filesADP.data.length - 1;
                $variables.attachmentName = `${lastFile} +${count} more`;
              }
            }
          },
          async () => {
             const getTaxClassificationCodeResponse = await Actions.callRest(context, {
               endpoint: 'getTaxClassificationCodes/getTaxClassificationCodes',
               uriParams: {
                 onlyData: 'true',
               },
             });

            $variables.Var_TaxClassification.data = getTaxClassificationCodeResponse.body.items;
          },
        ].map(sequence => sequence()));
      }
      
      await $flow.functions.hideloading();
    }
  }

  return PageEnterChain;
});
