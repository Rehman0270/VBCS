define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SaveActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;
      await $flow.functions.showloading();

      $variables.saveEditedMode = 'false';
      $variables.savingInProgress = 'true';
      const calculatedAmounts = $page.functions.calculateInvoiceAmount($page.variables.Var_LineEntries);
      $variables.Var_EditPageHeader.invoice_amount = Number(calculatedAmounts.totalAmount);
      $variables.Var_EditPageHeader.tax_amount = Number(calculatedAmounts.totalTaxAmount);

      const header = {
        invoice_id_atp: $variables.Var_EditPageHeader.invoice_id_atp,
        invoice_number: $variables.Var_EditPageHeader.invoice_number,
        invoice_amount: $variables.Var_EditPageHeader.invoice_amount,
        invoice_description: $variables.Var_EditPageHeader.invoice_description,
        invoice_date: $variables.Var_EditPageHeader.invoice_date,
        invoice_currency: $variables.Var_EditPageHeader.invoice_currency,
        po_number: $variables.Var_EditPageHeader.po_number,
        supplier_id: $variables.Var_EditPageHeader.supplier_id,
        supplier_name: $variables.Var_EditPageHeader.supplier_name,
        supplier_number: $variables.Var_EditPageHeader.supplier_number,
        supplier_site_id: $variables.Var_EditPageHeader.supplier_site_id,
        supplier_site: $variables.Var_EditPageHeader.supplier_site,
        payment_terms_id: $variables.Var_EditPageHeader.payment_terms_id,
        payment_terms: $variables.Var_EditPageHeader.payment_terms,
        business_unit_id: 300000003347133,
        business_unit: "KFUPM BU",
        requester_id: $variables.Var_EditPageHeader.requester_id,
        requester_name: $variables.Var_EditPageHeader.requester_name,
        invoice_group: $variables.Var_EditPageHeader.invoice_group,
        invoice_validated: $variables.Var_EditPageHeader.invoice_validated,
        imported_to_fusion: $variables.Var_EditPageHeader.imported_to_fusion,
        attribute_category: $variables.Var_EditPageHeader.attributeCategory,
        attribute1: $variables.Var_EditPageHeader.attribute1,
        attribute2: $variables.Var_EditPageHeader.attribute2,
        attribute3: $variables.Var_EditPageHeader.attribute3,
        attribute4: $variables.Var_EditPageHeader.attribute4,
        attribute5: $variables.Var_EditPageHeader.attribute5,
        attribute6: $variables.Var_EditPageHeader.attribute6,
        attribute7: $variables.Var_EditPageHeader.attribute7,
        attribute8: $variables.Var_EditPageHeader.attribute8,
        attribute9: $variables.Var_EditPageHeader.attribute9,
        attribute10: $variables.Var_EditPageHeader.attribute10,
        attribute11: $variables.Var_EditPageHeader.attribute11,
        attribute12: $variables.Var_EditPageHeader.attribute12,
        attribute13: $variables.Var_EditPageHeader.attribute13,
        attribute14: $variables.Var_EditPageHeader.attribute14,
        attribute15: $variables.Var_EditPageHeader.attribute15,
        created_by: $variables.Var_EditPageHeader.created_by,
        creation_date: $variables.Var_EditPageHeader.creation_date,
        last_updated_by: $variables.Var_EditPageHeader.last_updated_by,
        last_updated_date: $functions.getCurrentDateTimeISO(),
        version_number: $variables.Var_EditPageHeader.version_number + 1,
        person_id: $variables.Var_EditPageHeader.person_id,
        payment_method: $variables.Var_EditPageHeader.payment_method,
        tax_amount: $variables.Var_EditPageHeader.tax_amount,
        justification:$variables.Var_EditPageHeader.justification
      };

      $variables.Var_EditPageHeader = header;

      const changedRecords = $functions.diffRecords($variables.Var_LineEntriesResponse, $variables.Var_LineEntries);

      let newLines = [];
      if (Array.isArray(changedRecords.added) && changedRecords.added.length > 0){
        changedRecords.added.forEach(item => {
          const newLineObject = {
            invoice_id_atp: $variables.Var_EditPageHeader.invoice_id_atp,
            line_number: item.lineNumber,
            line_description: item.lineDescription,
            line_amount: item.lineAmount,
            cost_center: item.costCenter,
            expense_account: item.expenseAccount,
            po_line_no: item.purchaseOrderLineNumber,
            receipt_no: item.receiptNo,
            tax_classification_code: item.taxClassificationCode,
            tax_amount: item.taxAmount,
            tax_rate: item.taxRate,
            created_by: $flow.variables.userName||'bTranz',
            last_updated_by: $flow.variables.userName||'bTranz',
            creation_date: $functions.getCurrentDateTimeISO(),
            last_updated_date: $functions.getCurrentDateTimeISO(),
            version_number: 1,
            imported_to_fusion: 'N',
            attribute10: '01-'+item.costCenterAccount+'-'+item.expenseAccountNumber+'-00-0000000-00-000000-000000'
          };
          newLines.push(newLineObject);
        });
      }

      let updatedLines = [];
      if (Array.isArray(changedRecords.updated) && changedRecords.updated.length > 0){
        changedRecords.updated.forEach(item => {
          const updatedLineObject = {
            invoice_id_atp: item.invoiceIdAtp,
            invoice_line_id_atp: item.invoiceLineIdAtp,
            invoice_fusion_id: item.invoiceFusionId,
            invoice_fusion_line_id: item.invoiceFusionLineId,
            line_number: item.lineNumber,
            line_description: item.lineDescription,
            line_amount: item.lineAmount,
            cost_center: item.costCenter,
            expense_account: item.expenseAccount,
            po_line_no: item.purchaseOrderLineNumber,
            receipt_no: item.receiptNo,
            tax_classification_code: item.taxClassificationCode,
            tax_amount: item.taxAmount,
            tax_rate: item.taxRate,
            attribute_category: item.attributeCategory,
            attribute1: item.attribute1,
            attribute2: item.attribute2,
            attribute3: item.attribute3,
            attribute4: item.attribute4,
            attribute5: item.attribute5,
            attribute6: item.attribute6,
            attribute7: item.attribute7,
            attribute8: item.attribute8,
            attribute9: item.attribute9,
            attribute10: '01-'+(item.costCenterAccount||item.attribute10.split("-")[1])+'-'+(item.expenseAccountNumber||item.attribute10.split("-")[2])+'-00-0000000-00-000000-000000',
            attribute11: item.attribute11,
            attribute12: item.attribute12,
            attribute13: item.attribute13,
            attribute14: item.attribute14,
            attribute15: item.attribute15,
            created_by: item.createdBy,
            last_updated_by: item.lastUpdatedBy,
            creation_date: item.creationDate,
            last_updated_date: $functions.getCurrentDateTimeISO(),
            version_number: item.versionNumber + 1,
            imported_to_fusion: item.importedToFusion,
            
          };
          updatedLines.push(updatedLineObject);
        });
      }
      
      let deletedLines = [];
      if (Array.isArray(changedRecords.deleted) && changedRecords.deleted.length > 0){
        changedRecords.deleted.forEach(item => {
          const deletedLineObject = {
            invoice_line_id_atp: item.invoiceLineIdAtp,
          };
          deletedLines.push(deletedLineObject);
        });
      }

      let newAttachments = [];
      if (Array.isArray($variables.changedFileData.added) && $variables.changedFileData.added.length > 0){
        $variables.changedFileData.added.forEach(file =>{
          const addedAttachmentObject = {
            attachment_source: 'AP Invoice',
            source_id: $variables.Var_EditPageHeader.invoice_id_atp,
            attribute1: $variables.Var_EditPageHeader.invoice_number,
            attachment_name: file.FileName,
            attachment_content: file.FileContents,
            attachment_size: file.Size,
            attachment_type: file.UploadedFileContentType,
            imported_to_fusion: 'N',
            creation_date: $functions.getCurrentDateTimeISO(),
            created_by: $flow.variables.userName||'bTranz',
            last_updated_date: $functions.getCurrentDateTimeISO(),
            last_updated_by: $flow.variables.userName||'bTranz',
            version_number: 1
          };
          newAttachments.push(addedAttachmentObject);
        });
      }

      let deletedAttachments = [];
      if (Array.isArray($variables.changedFileData.deleted) && $variables.changedFileData.deleted.length > 0){
        $variables.changedFileData.deleted.forEach(file => {
          const deletedAttachmentObject = {
            attachment_id_atp: file.attachment_id_atp,
          };
          deletedAttachments.push(deletedAttachmentObject);
        });
      }

      const results2 = await Promise.all([
        async () => {

          const updateInvoiceHeaderResponse = await Actions.callRest(context, {
            endpoint: 'UpdateInvoiceHeader/updateInvoiceHeader',
            uriParams: {
              id: header.invoice_id_atp,
            },
            body: JSON.stringify($variables.Var_EditPageHeader),
          });

        },
        async () => {

          let insertCount = 0;
          let updateCount = 0;
          let deleteCount = 0;
          if (newLines !== null && newLines !== undefined) {
            for (const line of newLines){
              const insertNewLinesResponse = await Actions.callRest(context, {
                endpoint: 'Create_INvoice_Lines/postAp_invoice_lines_all',
                body: JSON.stringify(line)
              });

              if (insertNewLinesResponse.ok){
                insertCount += 1;
              }
            }
          }

          if (updatedLines !== null && updatedLines !== undefined) {
            for (const line of updatedLines) {
              const updateLinesResponse = await Actions.callRest(context, {
                endpoint: 'updateInvoiceLines/updateInvoiceLines',
                uriParams: {
                  id: line.invoice_line_id_atp,
                },
                body: JSON.stringify(line),
              });

              if (updateLinesResponse.ok){
                updateCount += 1;
              }
            }
          }

          if (deletedLines !== null && deletedLines !== undefined) {
            for (const line of deletedLines){
              const deleteLinesResponse = await Actions.callRest(context, {
                endpoint: 'deleteInvoiceLines/deleteInvoiceLines',
                uriParams: {
                  id: line.invoice_line_id_atp,
                },
              });

              if (deleteLinesResponse.ok){
                deleteCount += 1;
              }
            }
          }

          if (newLines.length === insertCount && updatedLines.length === updateCount && deletedLines.length === deleteCount){
            await Actions.fireNotificationEvent(context, {
                summary: 'Success',
                type: 'info',
                displayMode: 'transient',
              });
          }
        },
        
        async () => {

          let insertCount = 0;
          let deleteCount = 0;
          if (newAttachments !== null && newAttachments !== undefined) {
            for (const file of newAttachments){
              const insertNewAttachmentResponse = await Actions.callRest(context, {
                endpoint: 'Create_Attachments/postFun_attachments',
                body: JSON.stringify(file)
              });

              if (insertNewAttachmentResponse.ok){
                insertCount += 1;
              }
            }
          }

          if (deletedAttachments !== null && deletedAttachments !== undefined) {
            for (const file of deletedAttachments){
              const deleteAttachmentResponse = await Actions.callRest(context, {
                endpoint: 'deleteAttachments/deleteAttachments',
                uriParams: {
                  id: file.attachment_id_atp,
                },
              });

              if (deleteAttachmentResponse.ok){
                deleteCount += 1;
              }
            }
          }

          if (newAttachments.length === insertCount && deletedAttachments.length === deleteCount){
            await Actions.fireNotificationEvent(context, {
                summary: 'Success',
                type: 'info',
                displayMode: 'transient',
              });
          }
        },
      ].map(sequence => sequence()));


      await Actions.callChain(context, {
        chain: 'submitToFusionActionChain',
        params: {
          'p_invoice_id_atp': header.invoice_id_atp,
        },
      });
      
      
      $variables.editInvoiceMode = 'true';
      $variables.savingInProgress = 'false';

      await $flow.functions.hideloading();
    }
    
  }

  return SaveActionChain;
});
