define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class invoiceCurrencyClickChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;
      $variables.invoiceCurrencyClicked = 'true';
      $variables.invoiceCurrencyNotClicked = 'false';
    }
  }

  return invoiceCurrencyClickChain;
});
