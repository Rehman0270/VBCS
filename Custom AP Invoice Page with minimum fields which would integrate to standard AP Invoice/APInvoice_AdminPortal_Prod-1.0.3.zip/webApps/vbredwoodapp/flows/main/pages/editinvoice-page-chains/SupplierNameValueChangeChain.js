define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SupplierNameValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;
      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.supplierSiteValue',
  ],
      });
      $variables.supplierNameValue = value;
      $variables.Var_EditPageHeader.supplier_name = $variables.supplierNameValue;

      const matched = $page.variables.Var_SuppliersADP.data.find(supplier => supplier.SUPPLIER_NAME === value);

      if (matched) {
        $variables.Var_EditPageHeader.supplier_number = matched.SUPPLIER_NUMBER;
        $variables.supplierIdValue = matched.SUPPLIER_ID;
      }
      if ($variables.supplierIdValue !== null || $variables.supplierIdValue !== undefined) {
      const getSupplierSitesResponse = await Actions.callRest(context, {
        endpoint: 'getSupplierSites/getSuppliersSites',
        uriParams: {
          SupplierId: $variables.supplierIdValue,
          onlyData: true,
        },
      });
      /*comment below line when the if condition is uncommented*/
      $variables.Var_SupplierSites.data = getSupplierSitesResponse.body.items;
      /*
      if (getSupplierSitesResponse.count > 1 && $flow.variables.Get_One_Header_Var.po_number !== null){
      $variables.Var_SupplierSites.data = getSupplierSitesResponse.body.items;
      } else if (getSupplierSitesResponse.count === 1 && $flow.variables.Get_One_Header_Var.po_number !== null) {
      $flow.variables.Get_One_Header_Var.supplier_site = getSupplierSitesResponse.body.items[0].SupplierSite;
      } else {
        $flow.variables.Get_One_Header_Var.supplier_site = null;
      }
      */
      }
    }
  }

  return SupplierNameValueChangeChain;
});
