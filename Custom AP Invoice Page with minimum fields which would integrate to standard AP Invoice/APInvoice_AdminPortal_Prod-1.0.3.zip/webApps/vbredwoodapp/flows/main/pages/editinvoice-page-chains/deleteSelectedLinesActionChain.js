define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class deleteSelectedLinesActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.value 
     * @param {object[]} params.selected 
     */
    async run(context, { value, selected }) {
      const { $page, $flow, $application, $constants, $variables } = context;

        if (Array.isArray(selected) && selected.includes("Y")) {
          $page.variables.selectedLines.push(value);
        } else {
          $page.variables.selectedLines.pop(value);
        }

    }
  }

  return deleteSelectedLinesActionChain;
});
