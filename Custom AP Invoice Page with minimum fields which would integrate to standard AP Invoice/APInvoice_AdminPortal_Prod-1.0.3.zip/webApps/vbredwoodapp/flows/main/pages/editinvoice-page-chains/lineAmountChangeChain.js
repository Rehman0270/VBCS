define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class lineAmountChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const ok = $page.functions.areLinesValid($variables.Var_LineEntries);

      if (ok){
        $variables.linesValid = false;
      }
    }
  }

  return lineAmountChangeChain;
});
