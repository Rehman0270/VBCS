define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class rerunIntegrationButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $functions.showloading();


      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.Get_All_Invoice_Headers',
  ],
      });
      

      const GetFusionID = await Actions.callRest(context, {
        endpoint: 'Get_All_Invoices_Header/getAp_invoices_all',
        uriParams: {
          q: JSON.stringify({invoice_id_atp:key }),
        },
      });

      $flow.variables.Get_One_Header_Var = GetFusionID.body.items[0];
      $flow.variables.Integration_Payload_Var.invoice_id_fusion = GetFusionID.body.items[0].invoice_id_fusion;
      $flow.variables.Integration_Payload_Var.invoice_id_atp=key;

      /*await Actions.fireNotificationEvent(context,{
        summary: JSON.stringify($flow.variables.Get_One_Header_Var),
      });*/

      const rerunIntegrationresponse = await Actions.callRest(context, {
        endpoint: 'OICIntegrationToUpdateATPRecords/post1_0',
        body: $flow.variables.Integration_Payload_Var,
      });

      if (rerunIntegrationresponse.body.Status === 'Success') {
        const deleteErrorLogResponse = await Actions.callRest(context,{
              endpoint: 'deleteErrorLogs/delete',
              body: JSON.stringify({invoice_id_atp: $flow.variables.Get_One_Header_Var.invoice_id_atp}),
            });
        
        $flow.variables.Get_One_Header_Var.attribute15 = 'Success';
        await Actions.callRest(context, {
              endpoint: 'UpdateInvoiceHeader/updateInvoiceHeader',
              uriParams: {
                id: $flow.variables.Get_One_Header_Var.invoice_id_atp,
              },
              body: JSON.stringify($flow.variables.Get_One_Header_Var),
            });
        await Actions.fireNotificationEvent(context, {
          summary: 'Portal Updated Successfully',
          type: 'confirmation',
          displayMode: 'transient',
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Failed to update portal',
          type: 'error',
          displayMode: 'persist',
        });
      }

      await Actions.callChain(context, {
        chain: 'PageVbEnterChain',
      });

      await $functions.hideloading();

      
    }
  }

  return rerunIntegrationButtonActionChain;
});
