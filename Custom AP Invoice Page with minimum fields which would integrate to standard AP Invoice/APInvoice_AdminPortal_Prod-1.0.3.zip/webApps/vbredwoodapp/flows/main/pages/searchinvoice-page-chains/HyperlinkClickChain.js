define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class HyperlinkClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $functions.showloading();

      $flow.variables.Unique_Invoice_ID = key;
      /*await Actions.fireNotificationEvent(context,{
        summary: $flow.variables.Unique_Invoice_ID,
      });*/

      const toEditinvoice = await Actions.navigateToPage(context, {
        page: 'editinvoice',
        params: {
          invoiceHeaderIdAtp: key,
        },
      });

      await $functions.hideloading();
    }
  }

  return HyperlinkClickChain;
});
