define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $functions.showloading();

      const UniqueINVOICEID = await $functions.generateldid();

      $flow.variables.Unique_Invoice_ID = UniqueINVOICEID;

      await Actions.resetVariables(context, {
        variables: [
    '$flow.variables.Get_One_Header_Var',
  ],
      });

      const toCreateinvoice = await Actions.navigateToPage(context, {
        page: 'createinvoice',
      });

      await $functions.hideloading();
    }
  }

  return ButtonActionChain;
});
