define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class searchButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $flow.functions.showloading();

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.Get_All_Invoice_Headers',
    '$page.variables.Var_SearchTable',
  ],
      });

      const checkStrings = await $functions.checkStrings($variables.SupplierNameSearch_Var, $variables.InvoiceNumberSearch_Var, $variables.SupplierNumberSearch_Var, $variables.PONumberSearch_Var, $variables.InvoiceDateSearch_Var, $flow.variables.userName, $variables.Imported_Status_Search_Var);

      const response = await Actions.callRest(context, {
        endpoint: 'Get_All_Invoices_Header/getAp_invoices_all',
        uriParams: {
          q: checkStrings,
          limit: '9000',
        },
      });

      $variables.Get_All_Invoice_Headers.data = response.body.items;

      const errorLogResponse = await Actions.callRest(context,{
        endpoint: 'getErrorLogs/logs',
      });
      const errors = errorLogResponse.body.items;
      const mergedData = $variables.Get_All_Invoice_Headers.data.map(header => {
        const matchingError = errors.find(err => err.atp_invoice_id === header.invoice_id_atp);

        /*let import_status = null;

        if (matchingError && header.attribute15 !== 'Portal Update Failed') {
          import_status = 'Import Failed';
        } else if (header.imported_to_fusion === 'Y') {
          import_status = 'Success';
        }*/

        return{
          invoice_id: header.invoice_id_atp,
          invoice_number: header.invoice_number,
          supplier_name: header.supplier_name,
          invoice_amount: header.invoice_amount,
          import_status: header.attribute15,
          invoice_id_fusion:header.invoice_id_fusion,
          invoice_Creted_By:header.created_by,
          error_message: matchingError ? matchingError.error_message : 'No Error'
        };
      });

      $variables.Var_SearchTable.data = mergedData;
      /*$variables.parsedReportData.reportADP.data.forEach(record => {
        const match = $variables.Get_All_Invoice_Headers.data.find(
          header => String(header.invoice_id_fusion) === String(record.INVOICE_ID)
        );
      
        if (match) {
          match.fusion_approval_status = record.APPROVAL_STATUS;
        }
      });*/
      
      /*const updatedHeaders = $variables.Get_All_Invoice_Headers.data.map(header => {
        const match = $variables.parsedReportData.reportADP.data.find(
          record => String(record.INVOICE_ID) === String(header.invoice_id_fusion)
        );
      
        return {
          ...header,
          fusion_approval_status: match ? match.APPROVAL_STATUS : null,
          fusion_payment_status: match ? match.PAID_STATUS : null,
          fusion_payment_date: match ? match.PAYMENT_DATE : null,
          fusion_vouchernumber: match ? match.VOUCHER_NUMBER : null,
        };
      });
      
      $variables.Get_All_Invoice_Headers.data = updatedHeaders;
      
      const updatedRecords = $variables.Get_All_Invoice_Headers.data
        .filter(header => header.fusion_approval_status !== null);*/
      
      /*await Actions.fireNotificationEvent(context,{
        summary: JSON.stringify($variables.parsedReportData),
      });*/



      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.SupplierNameSearch_Var',
    '$page.variables.SupplierNumberSearch_Var',
    '$page.variables.InvoiceDateSearch_Var',
    '$page.variables.InvoiceNumberSearch_Var',
    '$page.variables.PONumberSearch_Var',
    '$page.variables.Imported_Status_Search_Var',
  ],
      });

      await $flow.functions.hideloading();

      /*for (let record of updatedRecords){
        await Actions.callRest(context, {
          endpoint: 'UpdateInvoiceHeader/updateInvoiceHeader',
          uriParams: {
            id: record.invoice_id_atp,
          },
          body: JSON.stringify(record)
        });
        await Actions.fireNotificationEvent(context,{
          summary: JSON.stringify(record),
        });
      }*/
      
    }
  }

  return searchButtonActionChain;
});
