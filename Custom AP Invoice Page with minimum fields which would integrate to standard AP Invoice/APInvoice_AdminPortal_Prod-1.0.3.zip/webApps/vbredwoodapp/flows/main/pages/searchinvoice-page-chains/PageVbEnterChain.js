define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $functions.showloading();

      const response2 = await Actions.callRest(context, {
        endpoint: 'Get_All_Invoices_Header/getAp_invoices_all',
        uriParams: {
          limit: '9000',
        },
      });

      $variables.Get_All_Invoice_Headers.data = response2.body.items;

      const unique = await $functions.unique(response2.body.items);

      $variables.InvoiceNumber_Var_LOV = unique.invoice_number;
      $variables.PONumber_Var_LOV = unique.po_number;
      $variables.Supplier_Name_VAR_LOV = unique.supplier_name;
      $variables.SupplierNumber_Var_LOV = unique.supplier_number;

      const invoice_id_fusion = unique.invoice_id_fusion;

      const reportParameter = $variables.Get_All_Invoice_Headers.data
      .filter(header => header.fusion_vouchernumber === null)
      .filter(header => 
        invoice_id_fusion.some(id => id.fusion_invoice_id === header.invoice_id_fusion)
      )
      .map(header => header.invoice_id_fusion)
      .join(',');


      const reportResponse = await Actions.callRest(context, {
        endpoint: 'getReportData/postXmlpserverServicesExternalReportWSSService',
        body: $functions.reportDataXMLbody(reportParameter),
      });

      const soapResponse = reportResponse?.response?.body || reportResponse?.body || reportResponse;

      $variables.parsedReportData = $functions.returnParsedReportData(soapResponse);

      const updatedHeaders = $variables.Get_All_Invoice_Headers.data.map(header => {
        const match = $variables.parsedReportData.reportADP.data.find(
          record => String(record.INVOICE_ID) === String(header.invoice_id_fusion)
        );

        return {
          ...header,
          fusion_approval_status: match ? match.APPROVAL_STATUS : header.fusion_approval_status,
          fusion_payment_status: match ? match.PAID_STATUS : header.fusion_payment_status,
          fusion_payment_date: match ? match.PAYMENT_DATE : header.fusion_payment_date,
          fusion_vouchernumber: match ? match.VOUCHER_NUMBER : header.fusion_vouchernumber,
          attribute14: match ? match.VALIDATION_STATUS : header.attribute14,
        };
      });

      $variables.Get_All_Invoice_Headers.data = updatedHeaders;

      const errorLogResponse = await Actions.callRest(context,{
        endpoint: 'getErrorLogs/logs',
      });
      const errors = errorLogResponse.body.items;
      const mergedData = $variables.Get_All_Invoice_Headers.data.map(header => {
        const matchingError = errors.find(err => err.atp_invoice_id === header.invoice_id_atp);

        return{
          invoice_id: header.invoice_id_atp,
          invoice_number: header.invoice_number,
          supplier_name: header.supplier_name,
          invoice_amount: header.invoice_amount,
          import_status: header.attribute15,
          invoice_id_fusion:header.invoice_id_fusion,
          invoice_Creted_By:header.created_by,
          error_message: matchingError ? matchingError.error_message : 'No Error'
        };
      });

      $variables.Var_SearchTable.data = mergedData;

      const updatedRecords = $variables.Get_All_Invoice_Headers.data
        .filter(header => header.fusion_approval_status !== null);
      
      /*await Actions.fireNotificationEvent(context,{
        summary: JSON.stringify(parsedReportData),
      });*/
      

      await $functions.hideloading();
      for (let record of updatedRecords){
        await Actions.callRest(context, {
          endpoint: 'UpdateInvoiceHeader/updateInvoiceHeader',
          uriParams: {
            id: record.invoice_id_atp,
          },
          body: JSON.stringify(record)
        });
        /*await Actions.fireNotificationEvent(context,{
          summary: JSON.stringify(record),
        });*/
      }
    }
  }

  return PageVbEnterChain;
});
