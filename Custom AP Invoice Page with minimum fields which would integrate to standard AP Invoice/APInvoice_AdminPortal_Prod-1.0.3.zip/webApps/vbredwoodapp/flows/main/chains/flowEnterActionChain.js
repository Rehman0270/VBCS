define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class flowEnterActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $flow, $application, $constants, $variables } = context;
      const userDetailsResponse = await Actions.callRest(context, {
        endpoint: 'getUserDetails/getUserDetails',
        uriParams: {
          q: "Username='" + $variables.userName + "'",
        },
      });

      $variables.Person_ID = userDetailsResponse.body.items[0].PersonId;
    }
  }

  return flowEnterActionChain;
});
