/* Copyright (c) 2024, Oracle and/or its affiliates */

define([], function() {
  'use strict';

  class FlowModule {
  }
FlowModule.prototype.base64ToFileDownload = function (base64Data, fileName) {
  if (!base64Data || !fileName) {
    console.log("Missing base64 data or filename");
    return;
  }

  const binaryString = window.atob(base64Data);
  const byteArray = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    byteArray[i] = binaryString.charCodeAt(i);
  }

  const blob = new Blob([byteArray]); // No MIME type needed
  const fileURL = window.URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = fileURL;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  window.URL.revokeObjectURL(fileURL);
  link.remove();
};
FlowModule.prototype.showloading=function () {
  document.getElementById("appLoader").style.display = "block";
};

FlowModule.prototype.hideloading=function () {
  document.getElementById("appLoader").style.display = "none";
};
FlowModule.prototype.getCurrentDate=function() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    const day = String(today.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
}
  return FlowModule;
});
